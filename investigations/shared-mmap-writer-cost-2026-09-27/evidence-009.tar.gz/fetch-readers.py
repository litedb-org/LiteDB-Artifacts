import concurrent.futures,json,pathlib,subprocess,sys
run,output=sys.argv[1:];root=pathlib.Path(output)
response=json.loads(subprocess.check_output(['gh','api',f'repos/litedb-org/LiteDB/actions/runs/{run}/artifacts']))
def fetch(a):
 name=a['name']; target=root/name.removeprefix('shared-readers-').replace('-latest','')
 if (target/'readers.jsonl').exists():return name+' already retained'
 if not name.startswith('shared-readers-'):return name+' skipped'
 subprocess.run(['gh','run','download',run,'-n',name,'-D',str(target)],check=True)
 return name+' downloaded'
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(fetch,response['artifacts']):print(result)
root.mkdir(parents=True,exist_ok=True)
(root/'artifact-manifest.json').write_text(json.dumps(response,indent=2)+'\n')
