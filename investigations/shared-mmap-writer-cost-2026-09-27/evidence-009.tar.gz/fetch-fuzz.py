#!/usr/bin/env python3
import concurrent.futures,json,pathlib,subprocess,sys
run,output=sys.argv[1:];root=pathlib.Path(output);root.mkdir(exist_ok=True)
pages=json.loads(subprocess.check_output(['gh','api','--paginate','--slurp',f'repos/litedb-org/LiteDB/actions/runs/{run}/artifacts?per_page=100']))
items=[a for p in pages for a in p['artifacts']]
(root/'artifact-manifest.json').write_text(json.dumps({'run':run,'artifacts':items},indent=2)+'\n')
def fetch(item):
 target=root/item['name']
 if target.exists():return
 subprocess.run(['gh','run','download',run,'-n',item['name'],'-D',str(target)],check=True)
 print(item['name'],'downloaded',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(fetch,items))
reports=[]
for path in root.rglob('run.json'):
 r=json.loads(path.read_text());assert r['status']=='passed',path
 reports.append({'path':str(path.relative_to(root)),'status':r['status'],'head':r['gitSha'],'dirty':r['workingTreeDirty']})
(root/'fuzz-summary.json').write_text(json.dumps(reports,indent=2)+'\n')
print(len(reports),'passing reports',flush=True)
