using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using LiteDB;
const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
var library = typeof(LiteDatabase).Assembly;
var type = library.GetType("LiteDB.Client.Shared.SharedCoordinationPage", true)!;
var directory = Path.Combine(args[0], "coord-probe-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(directory);
try
{
 using var page = (IDisposable)type.GetMethod("Open", flags)!.Invoke(null, new object[] { Path.Combine(directory, "probe.db") })!;
 var commit = (Action<int>)type.GetMethod("Committed", flags)!.CreateDelegate(typeof(Action<int>), page);
 var begin = (Action)type.GetMethod("StructuralBegin", flags)!.CreateDelegate(typeof(Action), page);
 var end = (Action<int>)type.GetMethod("StructuralEnd", flags)!.CreateDelegate(typeof(Action<int>), page);
 var method = type.GetMethod("Opened", flags)!;
 var modern = method.GetParameters().Length == 2;
 var opened = modern ? null : (Action<int>)method.CreateDelegate(typeof(Action<int>), page);
 var finish = modern ? (Action<int,bool>)method.CreateDelegate(typeof(Action<int,bool>), page) : null;
 if (modern) finish!(0, false); else opened!(0);
 Action<int> op = args[1] switch
 {
  "commit" => commit,
  "open" => i => { begin(); if (modern) finish!(i, true); else { end(i); opened!(i); } },
  "read" => (Action<int>)typeof(ReadProbe).GetMethod("Create")!.MakeGenericMethod(library.GetType("LiteDB.Client.Shared.SharedCoordinationStatus", true)!).Invoke(null,new object[]{page})!,
  _ => throw new ArgumentException("mode")
 };
 var warm=Stopwatch.StartNew(); var iterations=0;
 while(warm.Elapsed.TotalSeconds<2) { op(++iterations); }
 if(args[1]!="read") commit(0);
 const int count=1000000;
 var cpu=Process.GetCurrentProcess().TotalProcessorTime;
 var alloc=GC.GetAllocatedBytesForCurrentThread();
 var elapsed=Stopwatch.StartNew();
 for(var i=1;i<=count;i++)op(i);
 elapsed.Stop();
 alloc=GC.GetAllocatedBytesForCurrentThread()-alloc;
 cpu=Process.GetCurrentProcess().TotalProcessorTime-cpu;
 var readArgs=new object?[]{null};
 if(!(bool)type.GetMethod("TryRead", flags)!.Invoke(page,readArgs)!)throw new Exception("Invalid publication");
 var status=readArgs[0]!;
 var version=(long)status.GetType().GetProperty("Version",flags)!.GetValue(status)!;
 if(args[1]!="read" && version!=count)throw new Exception("Lost final version");
 Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new{mode=args[1],count,ns=elapsed.Elapsed.TotalMilliseconds*1000000/count,cpuNs=cpu.TotalMilliseconds*1000000/count,allocated=alloc,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(library.Location)))}));
}
finally { Directory.Delete(directory,true); }
static class ReadProbe
{
 private delegate bool Read<T>(out T value);
 public static Action<int> Create<T>(object page)
 {
  var read=(Read<T>)page.GetType().GetMethod("TryRead",BindingFlags.Instance|BindingFlags.NonPublic)!.CreateDelegate(typeof(Read<T>),page);
  return ignored=>{if(!read(out _))throw new Exception("Invalid read");};
 }
}
