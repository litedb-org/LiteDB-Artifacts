import concurrent.futures, json, pathlib, subprocess, sys
run, output = sys.argv[1:]
root = pathlib.Path(output)
root.mkdir(exist_ok=True)
data = json.loads(subprocess.check_output(['gh', 'api', f'repos/litedb-org/LiteDB/actions/runs/{run}/artifacts']))
(root / 'artifact-manifest.json').write_text(json.dumps(data, indent=2) + '\n')
def fetch(item):
    name = item['name']
    target = root / name.removeprefix('shared-slots-').replace('-latest', '')
    if not name.startswith('shared-slots-') or (target / 'paired.jsonl').exists():
        return
    subprocess.run(['gh', 'run', 'download', run, '-n', name, '-D', str(target)], check=True)
    print(name, 'downloaded', flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(fetch, data['artifacts']))
