# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `402947`
- Steps: `30` / requested `30`
- Duration: `0.184s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `Arm64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `6378EED947C6EA816B26B1412FE99C9594E9329219C17125A7D5D73753F4ADC9`
- Trace SHA-256: `AF335D2150EAC8972980F3C12F9389694D5FBCD4A3600B880DB004C6AA8B98C8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143617-bson-s402947-w0-r187fd014/replay.json`

## Metrics

- malformedInputsRejected: `64`
