# LiteDB fuzz result: linq-cache

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,806s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `866F5CF66C38F265FE6E79E24F95FAB8BC1DD8E1A35A853F2598C0BDB2593484`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143824-linq-cache-s102947-w0-r67534f1e/replay.json`

## Metrics

- supportedTranslations: `21`
- cacheEntries: `16`
- concurrencyCases: `32`
