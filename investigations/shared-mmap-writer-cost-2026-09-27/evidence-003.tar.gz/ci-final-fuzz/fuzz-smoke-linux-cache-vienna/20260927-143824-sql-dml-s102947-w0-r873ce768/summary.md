# LiteDB fuzz result: sql-dml

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,630s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `8F7968DF8B4DCB314422F3C1B3F5C46FF0F6D1AB3B7E322316EE1EFF030274F4`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143824-sql-dml-s102947-w0-r873ce768/replay.json`

## Metrics

- novelStates: `17`
- sqlDmlMutations: `7`
