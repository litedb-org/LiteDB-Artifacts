# LiteDB fuzz result: query

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `2.253s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `0B26F8EF4D20D4E6323623FE28117653DD8CF21CE651B05A4E5AC6AE9EEA06A1`
- Trace SHA-256: `3AD0BD21501FC323DA10F9707C4308816BB6F931925B784A7013818D15E341C5`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143652-query-s42947-w0-r1f931b5a/replay.json`

## Metrics

- novelStates: `37`
- assertions: `520`
- operationHits: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- collation: `en-US/IgnoreNonSpace`
