# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `0.210s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `46EAA70E190C82A17C485E8CE8F11CDB75149091665AA05BCF37B3A1E2A5097E`
- Trace SHA-256: `75708160EC5A351C1C8FC72316B97D8A4BF22A7925CE2EF0A236B162A8C8E1EF`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143652-bson-determinism-s42947-w0-ra0e0b1e6/replay.json`

## Metrics

- malformedInputsRejected: `88`
