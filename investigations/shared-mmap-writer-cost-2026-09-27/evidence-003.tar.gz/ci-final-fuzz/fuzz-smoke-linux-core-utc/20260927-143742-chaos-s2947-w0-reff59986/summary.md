# LiteDB fuzz result: chaos

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.974s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `835453CB9CA45A56344CACD6AF256A8EF9083C8ECA27C099444BCA1DE596E6E3`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143742-chaos-s2947-w0-reff59986/replay.json`

## Metrics

- novelStates: `20`
- semanticIndexKeys: `8`
- semanticDocuments: `8`
- semanticIndexes: `3`
- integrityPages: `14`
- integrityPhysicalPages: `14`
- chaosOperationFamilies: `14`
- documents: `2`
- files: `3`
