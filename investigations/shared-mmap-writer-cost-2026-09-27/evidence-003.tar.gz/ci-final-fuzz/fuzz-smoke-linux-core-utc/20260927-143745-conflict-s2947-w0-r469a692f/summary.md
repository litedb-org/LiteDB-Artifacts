# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `3` / requested `3`
- Duration: `0.816s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143745-conflict-s2947-w0-r469a692f/replay.json`

## Metrics

- semanticIndexKeys: `87`
- semanticDocuments: `48`
- semanticIndexes: `12`
- integrityPages: `51`
- integrityPhysicalPages: `51`
- novelStates: `2`
- forcedConflictingOperations: `18`
