# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `4.247s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-143736-conflict-s2947-w0-r994d20c5/replay.json`

## Metrics

- semanticIndexKeys: `868`
- semanticDocuments: `480`
- semanticIndexes: `122`
- integrityPages: `51`
- integrityPhysicalPages: `51`
- novelStates: `2`
- forcedConflictingOperations: `180`
