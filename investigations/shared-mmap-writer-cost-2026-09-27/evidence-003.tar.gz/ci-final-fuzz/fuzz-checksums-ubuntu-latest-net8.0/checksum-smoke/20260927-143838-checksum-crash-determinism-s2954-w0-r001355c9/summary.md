# LiteDB fuzz result: checksum-crash

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `6.626s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `A354CB58CB8F3B384DC35DA7BDD732553011839438EC19E83F1C1111601EFB66`
- Trace SHA-256: `175E63BEAF2D41490DE21E0C8B9565448C74FBC39A25D527BC2B50DAD0D2BCCB`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260927-143838-checksum-crash-determinism-s2954-w0-r001355c9/replay.json`

## Metrics

- novelStates: `23`
- crashEvents: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- crashCases: `28`
