# LiteDB fuzz result: mvcc-checkpoint

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `5.190s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `C44A5179C25405EEB625AD862922B6FD457FD557DB6E0A19D6244E0CD5B47BD2`
- Trace SHA-256: `01B425F8764B1E02AAC3723B7309EEC5EB8754AB69CF3D83A418C10C28F1CFC0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260927-143749-mvcc-checkpoint-s2954-w0-r53e0f473\replay.json`

## Metrics

- novelStates: `23`
