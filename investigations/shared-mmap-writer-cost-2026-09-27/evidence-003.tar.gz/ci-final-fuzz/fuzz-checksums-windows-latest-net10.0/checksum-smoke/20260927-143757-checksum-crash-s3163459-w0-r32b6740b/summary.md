# LiteDB fuzz result: checksum-crash

- Status: **PASS**
- Seed: `3163459`
- Steps: `201` / requested `201`
- Duration: `17.501s`
- Git SHA: `181f88711516145d3bfa5d727985624be1f08592`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `9B8F44BBE4E6A62D0A424BEE719F53E347F5216FD1F1BD583F43CEBF4B638499`
- Trace SHA-256: `ECD2CDDA0F28EF8D481B90AB98AE8E1397C4131C73B98DE9786B1CDC9E85C0D8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260927-143757-checksum-crash-s3163459-w0-r32b6740b\replay.json`

## Metrics

- novelStates: `69`
- crashEvents: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- crashCases: `201`
