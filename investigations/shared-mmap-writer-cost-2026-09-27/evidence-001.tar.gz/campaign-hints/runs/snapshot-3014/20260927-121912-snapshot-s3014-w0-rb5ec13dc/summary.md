# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `39.525s`
- Git SHA: `eea594b79edf6b52342b32fb1840616e6cf948ae`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `4276114A4B6F2426DDA7933A3425B85648476BDE9B9F4F7EAAD8940C15278848`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-hints/runs/snapshot-3014/20260927-121912-snapshot-s3014-w0-rb5ec13dc/replay.json`

## Metrics

- novelStates: `8`
- semanticIndexKeys: `54`
- semanticDocuments: `27`
- semanticIndexes: `2`
- integrityPages: `42`
- integrityPhysicalPages: `42`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `96`
- checkpointsBetweenReaderGenerations: `224`
