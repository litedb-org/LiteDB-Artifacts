# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `53.213s`
- Git SHA: `eea594b79edf6b52342b32fb1840616e6cf948ae`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `4DBA039147BE216FE73FFE3B28EFCB8D9757B5D7184837EC7EEC5A47FCF32D63`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-hints/runs/shared-3014/20260927-121952-shared-s3014-w0-r7dff5e87/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1112`
- semanticDocuments: `1112`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `95`
- acknowledgedRows: `1080`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
