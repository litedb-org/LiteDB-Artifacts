# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `3012`
- Steps: `32` / requested `32`
- Duration: `38.898s`
- Git SHA: `eea594b79edf6b52342b32fb1840616e6cf948ae`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `1F758A7F423B634A392C3121F005C95A58C42604E0B553661045783CE5827C5D`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-hints/runs/snapshot-3012/20260927-121551-snapshot-s3012-w0-rb917e9e1/replay.json`

## Metrics

- novelStates: `8`
- semanticIndexKeys: `50`
- semanticDocuments: `25`
- semanticIndexes: `2`
- integrityPages: `41`
- integrityPhysicalPages: `41`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `96`
- checkpointsBetweenReaderGenerations: `224`
