# LiteDB fuzz result: mvcc-retirement

- Status: **PASS**
- Seed: `3000002`
- Steps: `30` / requested `30`
- Duration: `3.105s`
- Git SHA: `31bbd70f40afbab905087bccf08c30ac4d436633`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `C024CA4380FB6633E03BEEB36DD6BFBCC5B0E3A9EC71AFB0D956F57857A0EC51`
- Trace SHA-256: `B37B4B25941D3C58B7498917A00CC362BFC2C3EEEC357AD0A9E7D2415FB1E19A`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-atomic-frozen/runs/mvcc-retirement-3013/20260927-142156-mvcc-retirement-s3000002-w0-r5a7bb234/replay.json`

## Metrics

- novelStates: `26`
