# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `0.808s`
- Git SHA: `31bbd70f40afbab905087bccf08c30ac4d436633`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `C900265B320C54BB7058AB1A579668D30712B5D7901C9713189C6297D2C57CE8`
- Trace SHA-256: `9A8F87653C140AAB1BB5C9500F93B9AA47A45D28186E094C90AFC5287C536F8E`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-atomic-frozen/runs/index-3014/20260927-142341-index-s3014-w0-rb84e6b53/replay.json`

## Metrics

- semanticIndexKeys: `116`
- semanticDocuments: `27`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `16`
- documents: `12`
- keyMovingUpdates: `4`
- integrityChecks: `2`
