# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `0.748s`
- Git SHA: `e81c28bb864e09f48a2025fe8aad360d65baa27e`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `C900265B320C54BB7058AB1A579668D30712B5D7901C9713189C6297D2C57CE8`
- Trace SHA-256: `9A8F87653C140AAB1BB5C9500F93B9AA47A45D28186E094C90AFC5287C536F8E`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-paced/runs/index-3014/20260927-114751-index-s3014-w0-rd5d44d32/replay.json`

## Metrics

- semanticIndexKeys: `116`
- semanticDocuments: `27`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `16`
- documents: `12`
- keyMovingUpdates: `4`
- integrityChecks: `2`
