# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3012`
- Steps: `32` / requested `32`
- Duration: `55.261s`
- Git SHA: `3e7b8d9b5ce787a828b2b3ca1b760cc6e22b82f2`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `28E3705D07A2AF6FD82B625323C2F02829ADF15578CD65E26EABCB516639AD22`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-revocation/runs/shared-3012/20260927-142805-shared-s3012-w0-r325f363a/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1120`
- semanticDocuments: `1120`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `97`
- acknowledgedRows: `1088`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
