# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `0.748s`
- Git SHA: `3e7b8d9b5ce787a828b2b3ca1b760cc6e22b82f2`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `6027644B152C9094467A9BD2642C30FF2152604764584DA87D3F2C0DE8578256`
- Trace SHA-256: `F81E907B9749F65170E34E31A6635FD0E50871D67BA291D842059986A5663344`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-revocation/runs/index-3013/20260927-143046-index-s3013-w0-r6920266a/replay.json`

## Metrics

- semanticIndexKeys: `72`
- semanticDocuments: `19`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `10`
- documents: `8`
- keyMovingUpdates: `2`
- integrityChecks: `2`
