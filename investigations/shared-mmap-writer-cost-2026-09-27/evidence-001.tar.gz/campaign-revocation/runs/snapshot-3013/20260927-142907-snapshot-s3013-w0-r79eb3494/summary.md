# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `40.027s`
- Git SHA: `3e7b8d9b5ce787a828b2b3ca1b760cc6e22b82f2`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `7D811475C32405AD1883965105FFB32A81F77E98E9DB7D042D273020643A19E2`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-revocation/runs/snapshot-3013/20260927-142907-snapshot-s3013-w0-r79eb3494/replay.json`

## Metrics

- novelStates: `7`
- semanticIndexKeys: `52`
- semanticDocuments: `26`
- semanticIndexes: `2`
- integrityPages: `41`
- integrityPhysicalPages: `41`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `96`
- checkpointsBetweenReaderGenerations: `224`
