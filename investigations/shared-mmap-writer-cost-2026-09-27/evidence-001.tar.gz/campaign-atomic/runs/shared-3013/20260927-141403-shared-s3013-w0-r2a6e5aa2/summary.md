# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `54.680s`
- Git SHA: `31bbd70f40afbab905087bccf08c30ac4d436633`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `CAB56062F0A7599D372068922E93BF568199615F7F0CA4EAC25DD34BCAE1ED0F`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-atomic/runs/shared-3013/20260927-141403-shared-s3013-w0-r2a6e5aa2/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1146`
- semanticDocuments: `1146`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `96`
- acknowledgedRows: `1114`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
