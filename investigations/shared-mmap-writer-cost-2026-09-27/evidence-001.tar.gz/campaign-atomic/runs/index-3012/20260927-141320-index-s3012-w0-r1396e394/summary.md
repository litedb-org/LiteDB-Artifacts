# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `3012`
- Steps: `32` / requested `32`
- Duration: `0.837s`
- Git SHA: `31bbd70f40afbab905087bccf08c30ac4d436633`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `5A122A863A801F6FFEA2E40008E43292DF765B7DB57105EDDBCC9C8EBF7F7442`
- Trace SHA-256: `54A308D1F0FA0757E62EF746D045EEBE1BFCFF894F064869E40E26F37AD08C63`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-atomic/runs/index-3012/20260927-141320-index-s3012-w0-r1396e394/replay.json`

## Metrics

- semanticIndexKeys: `60`
- semanticDocuments: `15`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `8`
- documents: `6`
- keyMovingUpdates: `4`
- integrityChecks: `2`
