; Assembly listing for method LiteDB.Client.Shared.SharedCoordinationPage:TryReadCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 11 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     rbx
       sub      rsp, 48
       lea      rbp, [rsp+0x40]
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x0013
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [r15], ymm0
       vmovdqu  xmmword ptr [r15+0x18], xmm0
       cmp      byte  ptr [rbx+0x3D], 0
       jne      G_M000_IG13
 
G_M000_IG03:                ;; offset=0x002C
       cmp      byte  ptr [rbx+0x3C], 0
       je       G_M000_IG13
       mov      rdi, gword ptr [rbx+0x08]
       call     [LiteDB.Client.Shared.SharedCoordinationRevocation:IsRevoked(System.String):bool]
       test     eax, eax
       jne      G_M000_IG13
       mov      edi, 8
       align    [0 bytes for IG04]
 
G_M000_IG04:                ;; offset=0x004D
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 8
       xor      edx, edx
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      qword ptr [rbp-0x18], rax
       test     al, 1
       jne      G_M000_IG11
 
G_M000_IG05:                ;; offset=0x006A
       mov      rcx, qword ptr [rbx+0x30]
       xor      edx, edx
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      rcx, 0x314452485342444C
       cmp      rax, rcx
       jne      G_M000_IG11
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 16
       xor      edx, edx
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      qword ptr [rbp-0x20], rax
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 24
 
G_M000_IG06:                ;; offset=0x00A7
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      qword ptr [rbp-0x28], rax
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 32
 
G_M000_IG07:                ;; offset=0x00BA
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      qword ptr [rbp-0x30], rax
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 40
 
G_M000_IG08:                ;; offset=0x00CD
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      qword ptr [rbp-0x38], rax
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 48
 
G_M000_IG09:                ;; offset=0x00E0
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       mov      rcx, qword ptr [rbp-0x20]
       mov      qword ptr [r15], rcx
       mov      rcx, qword ptr [rbp-0x28]
       mov      qword ptr [r15+0x08], rcx
       mov      rcx, qword ptr [rbp-0x30]
       mov      qword ptr [r15+0x10], rcx
       mov      rcx, qword ptr [rbp-0x38]
       mov      qword ptr [r15+0x18], rcx
       mov      qword ptr [r15+0x20], rax
       lock     
       or       dword ptr [rsp], 0
       mov      rcx, qword ptr [rbx+0x30]
       add      rcx, 8
 
G_M000_IG10:                ;; offset=0x0117
       xor      eax, eax
       lock     
       cmpxchg  qword ptr [rcx], rdx
       cmp      qword ptr [rbp-0x18], rax
       je       SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0124
       dec      edi
       jne      G_M000_IG04
 
G_M000_IG12:                ;; offset=0x012C
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [r15], ymm0
       vmovdqu  xmmword ptr [r15+0x18], xmm0
 
G_M000_IG13:                ;; offset=0x013B
       xor      eax, eax
 
G_M000_IG14:                ;; offset=0x013D
       add      rsp, 48
       pop      rbx
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG15:                ;; offset=0x0146
       mov      rdi, r15
       call     [LiteDB.Client.Shared.SharedCoordinationStatus:get_Quiet():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rdi, gword ptr [rbx+0x08]
       call     [LiteDB.Client.Shared.SharedCoordinationRevocation:IsRevoked(System.String):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x0165
       add      rsp, 48
       pop      rbx
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 366

