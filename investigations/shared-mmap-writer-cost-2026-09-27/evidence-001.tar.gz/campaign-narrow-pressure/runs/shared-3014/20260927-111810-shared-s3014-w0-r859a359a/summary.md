# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `52.954s`
- Git SHA: `50849afa2cb809167b6df7d69b4ad2fbe190be1f`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `94E0C5F78BF2F3798690F27084784E5EC51B74D6D777824AF4BD08587450DB83`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-narrow-pressure/runs/shared-3014/20260927-111810-shared-s3014-w0-r859a359a/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1112`
- semanticDocuments: `1112`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `95`
- acknowledgedRows: `1080`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
