# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `2905001`
- Steps: `200` / requested `200`
- Duration: `2.011s`
- Git SHA: `c5c54c9cb7782b95d30d17aa8415c1a2a2d34cf3`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `3EC527C8C7EA771CE24858A19379275304454A143EB4D3A3F4A6E3314EEDFF3B`
- Trace SHA-256: `4CF71F5085BE740FD514CE8DC09D764CBFFEE2082C097F27649442111229F867`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-narrow-pressure/runs/index-3012/20260927-111547-index-s2905001-w0-r2c41e92f/replay.json`

## Metrics

- semanticIndexKeys: `1029`
- semanticDocuments: `222`
- semanticIndexes: `32`
- integrityPages: `10`
- integrityPhysicalPages: `10`
- uniqueConflictScenarios: `6`
- novelStates: `46`
- documents: `46`
- keyMovingUpdates: `38`
- integrityChecks: `7`
