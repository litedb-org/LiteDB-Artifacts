# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `53.793s`
- Git SHA: `50849afa2cb809167b6df7d69b4ad2fbe190be1f`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `16C33EB7A921696546D401FD66898C064AE2EA19B421F5AC667113D70916A2F5`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-narrow-pressure/runs/shared-3013/20260927-111630-shared-s3013-w0-r175ea644/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1146`
- semanticDocuments: `1146`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `96`
- acknowledgedRows: `1114`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
