# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3012`
- Steps: `32` / requested `32`
- Duration: `54.012s`
- Git SHA: `c5c54c9cb7782b95d30d17aa8415c1a2a2d34cf3`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `0D5CB838C0B9B79DBF5F526B93A2683DBE3A0F0169845309AF98D9F29648C49E`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-narrow-pressure/runs/shared-3012/20260927-111449-shared-s3012-w0-r8333eae5/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1120`
- semanticDocuments: `1120`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `97`
- acknowledgedRows: `1088`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
