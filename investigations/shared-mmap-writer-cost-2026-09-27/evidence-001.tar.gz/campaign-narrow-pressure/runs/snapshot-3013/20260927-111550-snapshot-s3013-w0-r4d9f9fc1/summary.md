# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `39.615s`
- Git SHA: `c5c54c9cb7782b95d30d17aa8415c1a2a2d34cf3`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `7D811475C32405AD1883965105FFB32A81F77E98E9DB7D042D273020643A19E2`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-narrow-pressure/runs/snapshot-3013/20260927-111550-snapshot-s3013-w0-r4d9f9fc1/replay.json`

## Metrics

- novelStates: `7`
- semanticIndexKeys: `52`
- semanticDocuments: `26`
- semanticIndexes: `2`
- integrityPages: `41`
- integrityPhysicalPages: `41`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `96`
- checkpointsBetweenReaderGenerations: `224`
