#!/usr/bin/env python3
"""Index exact-head safety results by invariant without treating skipped tests as passes."""
import collections,json,pathlib,sys,xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]); ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
groups={
 'control_file_publication':['SharedCoordinationFile_Tests','SharedMappedProcess_Tests.Death_during_control_creation'],
 'admission_and_storage_fences':['SharedCoordinationPage_Tests','SharedCoordinationPublication_Tests','SharedOpeningMutation_Tests','SharedMappedProcess_Tests.Checkpoint_and_reader_death','SharedMappedProcess_Tests.Death_during_partial'],
 'wal_reuse_announcement':['SharedWalReusePublication_Tests','SharedWalBatchPublication_Tests'],
 'snapshot_lifetime_and_ownership':['SharedCoordinatedReads_Tests','SharedCoordinatedResources_Tests','SharedCoordinatedLifecycle_Tests','SharedCachedIdleTimer_Tests'],
 'writer_scheduling_and_disposal':['SharedReadPacer_Tests','SharedWriterPressure_Tests','SharedWriterHintCompletion_Tests','SharedOrdinaryOpen_Tests'],
 'unsupported_participant_fallback':['SharedCoordinationArchitecture_Tests'],
}
rows=[]
for directory in sorted(root.glob('test-results-*')):
 result={name:[] for name in groups};runtime=set()
 for file in directory.rglob('*.trx'):
  tree=ET.parse(file)
  for stdout in tree.findall('.//t:StdOut',ns):
   runtime.update(line.strip() for line in (stdout.text or '').splitlines() if 'Test host:' in line)
  for node in tree.findall('.//t:UnitTestResult',ns):
   test=node.attrib['testName'];outcome=node.attrib['outcome']
   for group,patterns in groups.items():
    if any(p in test for p in patterns):
     assert outcome=='Passed',(directory,test,outcome)
     result[group].append({'name':test,'outcome':outcome})
 assert all(result.values()),(directory,{k:len(v) for k,v in result.items()})
 rows.append({'artifact':directory.name,'runtime':sorted(runtime),'groups':result})
assert rows
out={'run':'36326327744','head':'186cdeec6bbc76d949b77c726c54a492dbc6d3cf','checkout':'181f88711516145d3bfa5d727985624be1f08592','sourceIdentity':'pr3016-source-identity.json','faultModel':'Native process termination and deterministic hook boundaries; bounded persistence fault campaigns are indexed separately. Not a proof of arbitrary power loss or hardware behavior.','artifacts':rows}
(root/'safety-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(len(rows),'native full-suite artifacts; all six invariant groups present and passing')
for name in groups:print(name, sorted({len(r['groups'][name]) for r in rows}))
