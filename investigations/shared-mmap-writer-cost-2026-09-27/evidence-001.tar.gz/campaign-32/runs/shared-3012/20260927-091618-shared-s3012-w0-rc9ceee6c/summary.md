# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3012`
- Steps: `32` / requested `32`
- Duration: `53.977s`
- Git SHA: `d7cb907f512ff2460519e35dc6ddf1fe1fc4cbf8`
- Working tree dirty: `False`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `B15BEA5DC9D8CE38E278B7DD6514157073561C6694828C13159A12818E3C39D9`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-32/runs/shared-3012/20260927-091618-shared-s3012-w0-rc9ceee6c/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1120`
- semanticDocuments: `1120`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `97`
- acknowledgedRows: `1088`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
