# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `53.223s`
- Git SHA: `d7cb907f512ff2460519e35dc6ddf1fe1fc4cbf8`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `53086A5FAEF98F26AF68483DAFE4E3C3613512B18DB38D59924366C65C38619C`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-32/runs/shared-3014/20260927-091938-shared-s3014-w0-rc1f3cbf4/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1112`
- semanticDocuments: `1112`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `95`
- acknowledgedRows: `1080`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
