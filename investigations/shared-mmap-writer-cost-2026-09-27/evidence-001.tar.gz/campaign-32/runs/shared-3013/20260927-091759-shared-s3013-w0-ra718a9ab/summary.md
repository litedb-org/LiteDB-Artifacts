# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `53.374s`
- Git SHA: `d7cb907f512ff2460519e35dc6ddf1fe1fc4cbf8`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `F27857F2FDD45E0C7F6977E2E959DD6277C0ABEE2644EBCBC2231B530B285BC6`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-32/runs/shared-3013/20260927-091759-shared-s3013-w0-ra718a9ab/replay.json`

## Metrics

- novelStates: `32`
- semanticIndexKeys: `1146`
- semanticDocuments: `1146`
- semanticIndexes: `32`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `32`
- processes: `96`
- acknowledgedRows: `1114`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `32`
