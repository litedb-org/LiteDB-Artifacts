# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `3014`
- Steps: `32` / requested `32`
- Duration: `38.916s`
- Git SHA: `d7cb907f512ff2460519e35dc6ddf1fe1fc4cbf8`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `4276114A4B6F2426DDA7933A3425B85648476BDE9B9F4F7EAAD8940C15278848`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-32/runs/snapshot-3014/20260927-091859-snapshot-s3014-w0-rca2a386b/replay.json`

## Metrics

- novelStates: `8`
- semanticIndexKeys: `54`
- semanticDocuments: `27`
- semanticIndexes: `2`
- integrityPages: `42`
- integrityPhysicalPages: `42`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `96`
- checkpointsBetweenReaderGenerations: `224`
