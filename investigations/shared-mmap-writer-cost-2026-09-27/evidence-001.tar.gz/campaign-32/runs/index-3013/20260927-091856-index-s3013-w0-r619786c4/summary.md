# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `3013`
- Steps: `32` / requested `32`
- Duration: `0.707s`
- Git SHA: `d7cb907f512ff2460519e35dc6ddf1fe1fc4cbf8`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.3 LTS`, `.NET 8.0.30`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `6027644B152C9094467A9BD2642C30FF2152604764584DA87D3F2C0DE8578256`
- Trace SHA-256: `F81E907B9749F65170E34E31A6635FD0E50871D67BA291D842059986A5663344`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __WORKSPACE__/artifacts_temp/mmap-writer/campaign-32/runs/index-3013/20260927-091856-index-s3013-w0-r619786c4/replay.json`

## Metrics

- semanticIndexKeys: `72`
- semanticDocuments: `19`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `10`
- documents: `8`
- keyMovingUpdates: `2`
- integrityChecks: `2`
