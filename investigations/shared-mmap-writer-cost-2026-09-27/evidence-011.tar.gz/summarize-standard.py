import json,sys,statistics,random,pathlib
for name in sys.argv[1:]:
 p=pathlib.Path(name); print(p.parent.name)
 rows=[json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.startswith('{')]
 rows=[r for r in rows if 'mode' in r.get('result',{})]
 for scenario in sorted({r['result']['scenario'] for r in rows}):
  pairs={}
  for r in rows:
   if r['result']['scenario']==scenario:pairs.setdefault(r['pair'],{})[r['variant']]=r['result']
  complete=[p for p in pairs.values() if 'baseline' in p and 'candidate' in p]
  print(scenario,len(complete))
  for metric in ['meanMs','p99Ms','cpuMsPerOperation']:
   before=[p['baseline'][metric] for p in complete];after=[p['candidate'][metric] for p in complete]
   diffs=[(b/a-1)*100 for a,b in zip(before,after) if a];rnd=random.Random(9316)
   boot=sorted(statistics.mean(rnd.choices(diffs,k=len(diffs))) for _ in range(10000))
   print(' ',metric,round(statistics.median(before),4),'->',round(statistics.median(after),4),'paired',round(statistics.mean(diffs),2),'[',round(boot[250],2),round(boot[9750],2),']')
