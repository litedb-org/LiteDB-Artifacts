#!/usr/bin/env python3
import json,pathlib,random,statistics,sys
root=pathlib.Path(sys.argv[1]);summaries=[]
for p in sorted(root.glob('*/contention.jsonl')):
 data=[json.loads(l) for l in p.read_text().splitlines()]
 for r in data:assert r['passed'] and r['endWalBytes']==0 and all(x['count']>0 for x in r['results'])
 for n in sorted({r['writers'] for r in data}):
  pairs={}
  for r in data:
   if r['writers']==n:pairs.setdefault(r['pair'],{})[r['variant']]=r
  def scheduled(r):return [x for x in r['results'] if x['interval']>0]
  metrics={'aggregate_ops_s':lambda r:sum(x['count']*1000/x['activeMs'] for x in r['results']),
   'scheduled_completion':lambda r:sum(x['count'] for x in scheduled(r))/sum(x['offered'] for x in scheduled(r)),
   'max_worker_api_p99_ms':lambda r:max(x['apiP99Ms'] for x in r['results']),
   'max_worker_arrival_p99_ms':lambda r:max(x['arrivalP99Ms'] for x in r['results'])}
  for metric,fn in metrics.items():
   before=[fn(p['baseline']) for p in pairs.values()];after=[fn(p['candidate']) for p in pairs.values()]
   diffs=[(b/a-1)*100 for a,b in zip(before,after)];rng=random.Random(9316)
   boot=sorted(sum(rng.choices(diffs,k=len(diffs)))/len(diffs) for _ in range(10000))
   summaries.append(dict(source=str(p),writers=n,metric=metric,pairs=len(pairs),baselineMedian=statistics.median(before),candidateMedian=statistics.median(after),meanPairedPercent=statistics.mean(diffs),exploratory95=[boot[250],boot[9750]]))
for p in root.glob('*/interop.jsonl'):
 for r in [json.loads(l) for l in p.read_text().splitlines()]:assert r['passed'] and r['writer']==r['reader']
(root/'contention-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
for r in summaries:print(pathlib.Path(r['source']).parent.name,r['writers'],r['metric'],round(r['baselineMedian'],3),'->',round(r['candidateMedian'],3),round(r['meanPairedPercent'],2),[round(x,2) for x in r['exploratory95']])
