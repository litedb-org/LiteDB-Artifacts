#!/usr/bin/env python3
"""Reproduce comparison tables from the retained paired reader JSONL."""
import argparse
import csv
import json
from pathlib import Path
import random
import statistics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('root', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()

def readers(row):
    return [x for x in row['results'] if x['role'] not in ('writer', 'checkpoint')]

def writers(row):
    return [x for x in row['results'] if x['role'] in ('writer', 'checkpoint')]

metrics = {
    'read_calls_per_second': lambda r: sum(x['count'] * 1000 / x['activeMs'] for x in readers(r)),
    'writer_transactions_per_second': lambda r: sum(x['count'] * 1000 / x['activeMs'] for x in writers(r)),
    'writer_p99_ms': lambda r: max((x['p99Ms'] for x in writers(r)), default=0),
    'total_active_cpu_ms': lambda r: sum(x['activeCpuMs'] for x in r['results']),
    'read_completion_fraction': lambda r: sum(x['count'] for x in readers(r)) / sum(x['offered'] for x in readers(r)),
    'median_reader_api_p99_ms': lambda r: statistics.median(x['p99Ms'] for x in readers(r)),
    'median_reader_arrival_p99_ms': lambda r: statistics.median(x['arrivalP99Ms'] for x in readers(r)),
}
rows = []
for source in sorted(args.root.glob('hosted-*/*/readers.jsonl')):
    data = [json.loads(line) for line in source.open()]
    groups = {}
    for record in data:
        assert record['passed'] and record['endWalBytes'] == 0, source
        key = (record['scenario'], record['activity'], record['readers'])
        groups.setdefault(key, {}).setdefault(record['pair'], {})[record['variant']] = record
    for (scenario, activity, count), pairs in sorted(groups.items()):
        assert all(set(p) == {'baseline', 'candidate'} for p in pairs.values()), source
        for name, metric in metrics.items():
            before = [metric(p['baseline']) for p in pairs.values()]
            after = [metric(p['candidate']) for p in pairs.values()]
            if not all(before):
                continue
            differences = [(b / a - 1) * 100 for a, b in zip(before, after)]
            rng = random.Random(9316)
            samples = sorted(sum(rng.choices(differences, k=len(differences))) / len(differences) for _ in range(10000))
            rows.append(dict(source=str(source.relative_to(args.root)), scenario=scenario, activity=activity,
                             readers=count, pairs=len(pairs), metric=name,
                             baseline_median=statistics.median(before), candidate_median=statistics.median(after),
                             mean_paired_percent=statistics.mean(differences),
                             exploratory_95_low=samples[250], exploratory_95_high=samples[9750]))
    print(source.parent.parent.name, source.parent.name, len(groups), flush=True)
with args.output.open('w', newline='') as target:
    writer = csv.DictWriter(target, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
