#!/usr/bin/env python3
"""Package evidence copies; originals stay unchanged. Never includes worktrees/binaries."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
args.output.mkdir(parents=True, exist_ok=True)
selected = []
excluded = {'dotnet-manualreset.cs', 'dotnet-memory-model.md', 'dotnet-preallocation-unix.cs',
            'pr3013-comments.json', 'pr3013-inline.json', 'pr3013-reviews.json',
            'pr3016-latest.json', 'pr3016-threads.json', 'source-pr-body.md', 'artifact-pr-body.md',
            'package-preflight.log', 'package-preflight-verification.json',
            'package-final.log', 'package-final-verification.json'}
for entry in sorted(root.iterdir()):
    if entry.is_file():
        if entry.name not in excluded and not entry.name.startswith(('pr3016-inline', 'pr3016-comments', 'pr3016-reviews')):
            selected.append(entry)
    elif not (entry / '.git').exists() and (
        entry.name.startswith(('campaign-', 'hosted-', 'ci-', 'ownership-profile')) or
        entry.name in {'tests', 'hint-completion-tests', 'rescan-tests', 'drain-tests', 'run-metadata',
                       'open-fence-mutant-results', 'coordination-probe'}):
        selected.extend(p for p in sorted(entry.rglob('*')) if p.is_file() and not p.is_symlink()
                        and not any(part in {'bin', 'obj'} for part in p.relative_to(entry).parts)
                        and (not (entry.name.startswith('ci-') and entry.name.endswith('fuzz')) or p.suffix in {'.json', '.jsonl', '.log', '.txt', '.xml', '.trx', '.csv', '.md'}
                             or p.name == 'input.bin'))

workspace = str(root.parents[1])
def sanitize(text):
    text = text.replace(workspace, '__WORKSPACE__')
    text = text.replace('__CI_WORKSPACE__', '__CI_WORKSPACE__')
    text = re.sub(r'/(?:home|Users)/[^/\s"<>\\]+', '__HOME__', text)
    for slashes in ('\\\\', '\\', '/'):
        for drive in ('D:', 'd:', 'C:', 'c:'):
            prefix = drive + slashes + slashes.join(('a', 'LiteDB', 'LiteDB'))
            text = text.replace(prefix, '__CI_WORKSPACE__')
        for user in ('runneradmin', 'runner', 'jonas'):
            prefix = 'C:' + slashes + slashes.join(('Users', user))
            text = text.replace(prefix, '__HOME__')
    text = text.replace('__TMP__/', '__TMP__/')
    text = re.sub(r'(computerName|runUser)="[^"]*"', r'\1="__HOST__"', text)
    return text

def numeric_leaves(value):
    if isinstance(value, dict):
        return [numeric_leaves(v) for v in value.values()]
    if isinstance(value, list):
        return [numeric_leaves(v) for v in value]
    return None if isinstance(value, str) else value

manifest = {'format': 2, 'normalization': 'Only machine-specific path/host text; numeric JSON values checked unchanged.',
            'exclusions': 'Git worktrees, compiled binaries, external source copies, PR comment downloads; bulk hosted fuzz database/dump files (replay inputs and reports retained).',
            'archives': [], 'files': []}
text_extensions = {'.txt', '.md', '.log', '.json', '.jsonl', '.trx', '.xml', '.patch', '.asm', '.py', '.cs', '.csproj', '.tsv', '.csv', '.yml'}
# Bound each uncompressed tar to leave margin below GitHub's 100 MiB blob limit.
# Replay inputs are indivisible; all current files fit individually.
part_limit = 80 * 1024 * 1024
bundle = None
part_size = 0
part_number = 0
archive = None
temporary = None
def finish_part():
    global bundle
    if bundle is None:
        return
    bundle.close()
    bundle = None
    assert temporary.stat().st_size < 100 * 1024 * 1024, temporary
    temporary.replace(archive)
    manifest['archives'].append({'name': archive.name, 'bytes': archive.stat().st_size,
                                 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()})
try:
    for path in selected:
        before = path.read_bytes()
        after = before
        if path.suffix in text_extensions:
            encoding = 'utf-16' if before.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
            decoded = before.decode(encoding)
            normalized = sanitize(decoded)
            after = normalized.encode('utf-8')
            if path.suffix in {'.json', '.jsonl'}:
                old = [json.loads(line) for line in decoded.splitlines() if line] if path.suffix == '.jsonl' else json.loads(decoded)
                new = [json.loads(line) for line in normalized.splitlines() if line] if path.suffix == '.jsonl' else json.loads(normalized)
                assert numeric_leaves(old) == numeric_leaves(new), path
        assert b'__HOME__/' not in after, path
        name = str(path.relative_to(root))
        info = tarfile.TarInfo(name)
        info.size = len(after)
        info.mode = 0o644
        info.mtime = 0
        entry_size = len(info.tobuf(format=tarfile.PAX_FORMAT)) + ((len(after) + 511) // 512) * 512
        assert entry_size + tarfile.RECORDSIZE <= part_limit, (path, entry_size)
        if bundle is None or part_size + entry_size + tarfile.RECORDSIZE > part_limit:
            finish_part()
            part_number += 1
            archive = args.output / f'evidence-{part_number:03d}.tar.gz'
            temporary = archive.with_suffix('.gz.tmp')
            bundle = tarfile.open(temporary, 'w:gz', compresslevel=9)
            part_size = 0
        bundle.addfile(info, io.BytesIO(after))
        part_size += entry_size
        manifest['files'].append({'path': name, 'archive': archive.name, 'originalBytes': len(before), 'publishedBytes': len(after),
                                  'originalSha256': hashlib.sha256(before).hexdigest(),
                                  'publishedSha256': hashlib.sha256(after).hexdigest(), 'normalized': before != after})
    finish_part()
finally:
    if bundle is not None:
        bundle.close()
retained = {entry['name'] for entry in manifest['archives']}
for old in args.output.glob('evidence*.tar.gz'):
    if old.name not in retained:
        old.unlink()
(args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(selected), 'archives': manifest['archives']}))
