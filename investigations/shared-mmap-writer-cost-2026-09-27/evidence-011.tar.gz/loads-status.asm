; Assembly listing for method LiteDB.Client.Shared.SharedCoordinationPage:TryReadCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 11 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     rbx
       lea      rbp, [rsp+0x10]
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x000F
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [r15], ymm0
       vmovdqu  xmmword ptr [r15+0x18], xmm0
       cmp      byte  ptr [rbx+0x3D], 0
       jne      G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0028
       cmp      byte  ptr [rbx+0x3C], 0
       je       G_M000_IG08
       mov      rdi, gword ptr [rbx+0x08]
       call     [LiteDB.Client.Shared.SharedCoordinationRevocation:IsRevoked(System.String):bool]
       test     eax, eax
       jne      G_M000_IG08
       mov      edi, 8
       align    [0 bytes for IG04]
 
G_M000_IG04:                ;; offset=0x0049
       mov      rax, qword ptr [rbx+0x30]
       mov      rax, qword ptr [rax+0x08]
       test     al, 1
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0055
       mov      rcx, qword ptr [rbx+0x30]
       mov      rdx, 0x314452485342444C
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG06
       mov      rcx, qword ptr [rbx+0x30]
       mov      rcx, qword ptr [rcx+0x10]
       mov      rdx, qword ptr [rbx+0x30]
       mov      rdx, qword ptr [rdx+0x18]
       mov      rsi, qword ptr [rbx+0x30]
       mov      rsi, qword ptr [rsi+0x20]
       mov      r8, qword ptr [rbx+0x30]
       mov      r8, qword ptr [r8+0x28]
       mov      r9, qword ptr [rbx+0x30]
       mov      r9, qword ptr [r9+0x30]
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rdx
       mov      qword ptr [r15+0x10], rsi
       mov      qword ptr [r15+0x18], r8
       mov      qword ptr [r15+0x20], r9
       lock     
       or       dword ptr [rsp], 0
       mov      rcx, qword ptr [rbx+0x30]
       cmp      rax, qword ptr [rcx+0x08]
       je       SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x00B2
       dec      edi
       jne      SHORT G_M000_IG04
 
G_M000_IG07:                ;; offset=0x00B6
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [r15], ymm0
       vmovdqu  xmmword ptr [r15+0x18], xmm0
 
G_M000_IG08:                ;; offset=0x00C5
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x00C7
       pop      rbx
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x00CC
       mov      rdi, r15
       call     [LiteDB.Client.Shared.SharedCoordinationStatus:get_Quiet():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rdi, gword ptr [rbx+0x08]
       call     [LiteDB.Client.Shared.SharedCoordinationRevocation:IsRevoked(System.String):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
 
G_M000_IG11:                ;; offset=0x00EB
       pop      rbx
       pop      r15
       pop      rbp
       ret      
 
; Total bytes of code 240

