#!/usr/bin/env python3
"""Render every final archived-prototype cell from the complete generated CSV."""
import csv,pathlib,sys
folder=pathlib.Path(sys.argv[1]);rows=[r for r in csv.DictReader((folder/'reader-comparisons.csv').open()) if r['source'].startswith('hosted-final-archived/')]
groups={}
for row in rows:groups.setdefault((row['source'],row['scenario'],int(row['readers'])),{})[row['metric']]=row
assert len(groups)==36,len(groups)
assert len({k[0] for k in groups})==6
assert all(r['pairs']=='5' for r in rows)
def numbers(r):return f"{float(r['baseline_median']):,.2f} → {float(r['candidate_median']):,.2f}"
def change(r):return f"{float(r['mean_paired_percent']):+.2f}% [{float(r['exploratory_95_low']):+.2f}, {float(r['exploratory_95_high']):+.2f}]"
text='''# Final candidate compared with the archived mmap prototype

[Run 36327591678](https://github.com/litedb-org/LiteDB/actions/runs/36327591678)
compares final `186cdeec6bbc76d949b77c726c54a492dbc6d3cf` with
`16131953114971557b44e9deaa78bd8ce9d45ab1`, a byte-identical library restoration of
archive `130b339523cbe61efcef52b5d67252aee5a6cb53` on the merged stack.

Each cell has five alternating production Release pairs, ten seconds warmup and
ten seconds measurement, on one hosted machine. These are saturated readers;
writers are unthrottled. All 360 records pass logical/index validation and final
WAL cleanup. Absolute values are medians, changes are means of paired percentages,
and brackets are exploratory 95% bootstrap intervals. They are different
statistics, especially with variable timing. Do not pool hosts or treat an
interval containing zero as proof of equivalence. Reader p99, allocation, CPU,
WAL and memory records remain in the raw bundle; additional latency metrics are
in [reader-comparisons.csv](reader-comparisons.csv).
'''
for activity in ['idle','writer','checkpoint']:
 text+=f'\n## {activity.title()}\n\n| Host / read shape / processes | Reader calls/s | Reader change | Writer txn/s | Writer change | Writer p99 change |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
 for (source,shape,count),metrics in sorted(groups.items()):
  read=metrics['read_calls_per_second']
  if read['activity']!=activity:continue
  host='Linux' if '/ubuntu-' in source else 'Windows'
  write=metrics.get('writer_transactions_per_second');tail=metrics.get('writer_p99_ms')
  text+=f'| {host} / {shape} / {count} | {numbers(read)} | {change(read)} | {numbers(write) if write else "—"} | {change(write) if write else "—"} | {change(tail) if tail else "—"} |\n'
(folder/'final-archived-comparison.md').write_text(text)
print('Wrote all 36 final archived comparison cells')
