#!/usr/bin/env python3
"""Tabulate retained complete ordinary-workload pairs without pooling hosts."""
import argparse,csv,json,pathlib,random,statistics
p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);args=p.parse_args();out=[]
for source in sorted(args.root.glob('hosted-*/*/paired.jsonl')):
 data=[json.loads(l) for l in source.read_text(encoding='utf-8-sig').splitlines() if l.startswith('{')]
 groups={}
 for r in data:
  if r.get('returncode')!=0 or 'mode' not in r.get('result',{}):continue
  groups.setdefault(r['result']['scenario'],{}).setdefault(r['pair'],{})[r['variant']]=r['result']
 for scenario,pairs in sorted(groups.items()):
  complete=[v for v in pairs.values() if set(v)=={'baseline','candidate'}]
  if len(complete)<5:continue
  for metric in ('meanMs','p99Ms','cpuMsPerOperation','bytesPerOperation','closeMs','retainedManagedBytes'):
   before=[r['baseline'][metric] for r in complete];after=[r['candidate'][metric] for r in complete]
   if not all(before):continue
   ds=[(b/a-1)*100 for a,b in zip(before,after)];rng=random.Random(9316)
   boot=sorted(sum(rng.choices(ds,k=len(ds)))/len(ds) for _ in range(10000))
   out.append(dict(source=str(source.relative_to(args.root)),diagnostic=(source.parent/'ownership-profile.patch').exists(),scenario=scenario,pairs=len(complete),metric=metric,baseline_median=statistics.median(before),candidate_median=statistics.median(after),mean_paired_percent=statistics.mean(ds),exploratory_95_low=boot[250],exploratory_95_high=boot[9750]))
with args.output.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(len(out),'complete comparison rows')
