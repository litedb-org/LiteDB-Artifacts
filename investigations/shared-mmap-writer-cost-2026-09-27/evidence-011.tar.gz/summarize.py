import json,sys,statistics,random
rows=[json.loads(line) for line in open(sys.argv[1])]
keys=sorted({(r['scenario'],r['activity'],r['readers']) for r in rows})
for key in keys:
 rs=[r for r in rows if (r['scenario'],r['activity'],r['readers'])==key]
 pairs={}
 for r in rs: pairs.setdefault(r['pair'],{})[r['variant']]=r
 print(key)
 def rate(x): return x['count']*1000/x['activeMs']
 metrics={'readOps':lambda r:sum(rate(x) for x in r['results'] if x['role'] not in ('writer','checkpoint')),
 'writeOps':lambda r:sum(rate(x) for x in r['results'] if x['role'] in ('writer','checkpoint')),
 'writerP99':lambda r:max((x['p99Ms'] for x in r['results'] if x['role'] in ('writer','checkpoint')),default=0),
 'cpuMs':lambda r:sum(x['activeCpuMs'] for x in r['results'])}
 for name,f in metrics.items():
  complete=[p for p in pairs.values() if len(p)==2 and f(p['baseline'])]
  if not complete: continue
  before=[f(p['baseline']) for p in complete]; after=[f(p['candidate']) for p in complete]
  diffs=[(b/a-1)*100 for a,b in zip(before,after)]
  rand=random.Random(9316)
  boot=sorted(statistics.mean(rand.choices(diffs,k=len(diffs))) for _ in range(10000))
  print(name,len(diffs),round(statistics.median(before),3),'->',round(statistics.median(after),3),
        'paired',round(statistics.mean(diffs),2),'[',round(boot[250],2),round(boot[9750],2),']')
