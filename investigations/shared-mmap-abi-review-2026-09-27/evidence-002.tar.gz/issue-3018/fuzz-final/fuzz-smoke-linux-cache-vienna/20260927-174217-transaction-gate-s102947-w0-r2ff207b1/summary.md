# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,786s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `D20E48F572B24D99C9302829CA8CC61304721F51CCD9CCF921C0610D694D3499`
- Trace SHA-256: `7726EE8CB7D72903CDF20D1E05EDB18F3C7CB7EFEC521158835403C62CD91C38`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174217-transaction-gate-s102947-w0-r2ff207b1/replay.json`

## Metrics

- novelStates: `20`
- foreignLeasesReleased: `367`
