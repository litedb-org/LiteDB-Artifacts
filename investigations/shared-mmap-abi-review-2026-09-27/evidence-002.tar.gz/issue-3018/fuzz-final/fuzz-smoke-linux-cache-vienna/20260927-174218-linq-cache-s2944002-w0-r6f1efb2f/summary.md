# LiteDB fuzz result: linq-cache

- Status: **PASS**
- Seed: `2944002`
- Steps: `200` / requested `200`
- Duration: `3,189s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `7FF7FAF208CEC3013E8AF65DE6A405A4DDA859D9F34D8CCD880202E15E45911F`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174218-linq-cache-s2944002-w0-r6f1efb2f/replay.json`

## Metrics

- supportedTranslations: `166`
- cacheEntries: `74`
- concurrencyCases: `200`
