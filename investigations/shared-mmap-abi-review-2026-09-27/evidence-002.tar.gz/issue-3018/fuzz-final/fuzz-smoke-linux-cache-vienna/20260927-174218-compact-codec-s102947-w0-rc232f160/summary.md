# LiteDB fuzz result: compact-codec

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,295s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `F43006A5F4034A482DC297FA966DE72FB8DAB8D6670516D36450D93C29826E33`
- Trace SHA-256: `C2F522121E438BFB72FC4CCB9671B2E78371DD1E7F6C7A076C30DFE612887DC0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174218-compact-codec-s102947-w0-rc232f160/replay.json`

## Metrics

- vectorBoundaryCases: `6`
- novelStates: `30`
- decoded: `30`
- projected: `30`
- mutations: `30`
- mutationRejections: `30`
- schemas: `6`
