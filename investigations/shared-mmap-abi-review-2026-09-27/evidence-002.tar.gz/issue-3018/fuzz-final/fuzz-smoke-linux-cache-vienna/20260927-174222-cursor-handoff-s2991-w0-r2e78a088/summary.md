# LiteDB fuzz result: cursor-handoff

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `3,064s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `0A092B10C46DEAB0D2646E0B7FD6406D58309515B8D493822E6123D0D4BD5E6A`
- Trace SHA-256: `038FAF0298AA258346AD02521E4D6C218E907381821F75680023B5CE33257757`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174222-cursor-handoff-s2991-w0-r2e78a088/replay.json`

## Metrics

- novelStates: `12`
- cursorsHandedOff: `190`
- semanticIndexKeys: `12`
- semanticDocuments: `12`
- semanticIndexes: `1`
- integrityPages: `4`
- integrityPhysicalPages: `4`
