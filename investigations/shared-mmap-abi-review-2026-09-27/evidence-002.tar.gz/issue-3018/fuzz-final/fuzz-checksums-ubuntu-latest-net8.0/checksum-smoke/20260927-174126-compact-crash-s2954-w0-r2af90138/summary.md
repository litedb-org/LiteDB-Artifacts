# LiteDB fuzz result: compact-crash

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `1.837s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `A285E67931C1ECF1F97787B8BACFDA511AAD9A56A84062FB46A2171E1455E8F0`
- Trace SHA-256: `FFC84602BBDA9E8A9AB6B721E110DE44D803C084997C70555C715B71E74FBDA8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260927-174126-compact-crash-s2954-w0-r2af90138/replay.json`

## Metrics

- novelStates: `22`
