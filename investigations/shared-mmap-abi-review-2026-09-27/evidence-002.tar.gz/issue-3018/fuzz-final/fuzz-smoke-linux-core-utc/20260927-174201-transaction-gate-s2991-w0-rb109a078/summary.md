# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `0.345s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `2387A6A95F9F18A9812B85A15D50FE5AAE4E0C98B62D58EB7232B6E1E68D6AB5`
- Trace SHA-256: `9FCA76F1DB92F62A1A4B13039394DACB8CC0CE4D5131B81179513875987E2831`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174201-transaction-gate-s2991-w0-rb109a078/replay.json`

## Metrics

- novelStates: `14`
- foreignLeasesReleased: `237`
