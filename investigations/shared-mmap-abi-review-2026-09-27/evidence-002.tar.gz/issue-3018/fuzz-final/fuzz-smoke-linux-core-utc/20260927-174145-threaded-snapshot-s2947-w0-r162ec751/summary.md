# LiteDB fuzz result: threaded-snapshot

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `3.946s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174145-threaded-snapshot-s2947-w0-r162ec751/replay.json`

## Metrics

- novelStates: `19`
- semanticIndexKeys: `120`
- semanticDocuments: `60`
- semanticIndexes: `2`
- integrityPages: `124`
- integrityPhysicalPages: `124`
- forcedSnapshotRounds: `30`
- commitsWhileOldReadersLive: `60`
