# LiteDB fuzz result: read-only

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.980s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `EF2CA7C6748B9F171790C5C1E9E941D384ABE605230F7B4A5B0F2B68CCC6DFEA`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174159-read-only-s2947-w0-r8fc855a8/replay.json`

## Metrics

- forbiddenReadOnlyMutations: `10`
- novelStates: `10`
- semanticIndexKeys: `160`
- semanticDocuments: `80`
- semanticIndexes: `2`
- integrityPages: `5`
- integrityPhysicalPages: `5`
- byteStableReadWorkloads: `30`
