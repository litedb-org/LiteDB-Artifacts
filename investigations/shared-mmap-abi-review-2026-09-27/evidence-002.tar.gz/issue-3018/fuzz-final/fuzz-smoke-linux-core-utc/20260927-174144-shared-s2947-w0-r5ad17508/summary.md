# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `39.091s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `334F05388028524620347905D792C052EB882399D4A5701D6E2C34A0CACAF71A`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174144-shared-s2947-w0-r5ad17508/replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `1000`
- semanticDocuments: `1000`
- semanticIndexes: `30`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `30`
- processes: `90`
- acknowledgedRows: `970`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `30`
