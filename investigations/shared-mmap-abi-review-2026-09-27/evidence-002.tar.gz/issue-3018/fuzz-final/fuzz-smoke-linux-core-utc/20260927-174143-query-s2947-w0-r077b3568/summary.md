# LiteDB fuzz result: query

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `2.308s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `9269EAF31DA97355EB357D9315C8679C7D06FC17B1F2B3E135DC9E0AA5F46800`
- Trace SHA-256: `FD69938C421B556F48E138EB8F8154BC71A78BB5787B3CA013C67F9C8405EB27`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-174143-query-s2947-w0-r077b3568/replay.json`

## Metrics

- novelStates: `30`
- assertions: `390`
- operationHits: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- collation: `en-US/IgnoreNonSpace`
