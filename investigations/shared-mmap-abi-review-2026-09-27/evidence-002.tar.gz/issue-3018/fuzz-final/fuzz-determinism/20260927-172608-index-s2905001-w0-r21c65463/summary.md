# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `2905001`
- Steps: `200` / requested `200`
- Duration: `1.314s`
- Git SHA: `4e74b8d06ffa6d71e36689cb9b1e1271294d0f67`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `3EC527C8C7EA771CE24858A19379275304454A143EB4D3A3F4A6E3314EEDFF3B`
- Trace SHA-256: `4CF71F5085BE740FD514CE8DC09D764CBFFEE2082C097F27649442111229F867`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-172608-index-s2905001-w0-r21c65463/replay.json`

## Metrics

- semanticIndexKeys: `1029`
- semanticDocuments: `222`
- semanticIndexes: `32`
- integrityPages: `10`
- integrityPhysicalPages: `10`
- uniqueConflictScenarios: `6`
- novelStates: `46`
- documents: `46`
- keyMovingUpdates: `38`
- integrityChecks: `7`
