#!/usr/bin/env python3
"""Download completed CI test evidence (excluding binaries and process dumps)."""
import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

run, output = sys.argv[1:]
root = Path(output)
root.mkdir(exist_ok=True)
pages = json.loads(subprocess.check_output(['gh', 'api', '--paginate', '--slurp',
    f'repos/litedb-org/LiteDB/actions/runs/{run}/artifacts?per_page=100']))
data = {'total_count': pages[0]['total_count'], 'artifacts': [item for page in pages for item in page['artifacts']]}
(root / 'artifact-manifest.json').write_text(json.dumps(data, indent=2) + '\n')
items = [a for a in data['artifacts'] if a['name'].startswith(('test-results-', 'crossprocess-test-results-'))]

def fetch(item):
    target = root / item['name'].replace(' ', '_')
    if target.exists():
        return
    subprocess.run(['gh', 'run', 'download', run, '-n', item['name'], '-D', str(target)], check=True)
    print(item['name'], 'downloaded', flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(fetch, items))

ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
summary = []
for directory in sorted(p for p in root.iterdir() if p.is_dir()):
    counts = {'Passed': 0, 'Failed': 0, 'NotExecuted': 0}
    runtime, affected, skipped = set(), [], []
    for file in sorted(directory.rglob('*.trx')):
        tree = ET.parse(file)
        for node in tree.findall('.//t:StdOut', ns):
            for line in (node.text or '').splitlines():
                if 'Test host:' in line:
                    runtime.add(line.strip())
        # The VSTest Counters.notExecuted attribute can be zero despite skipped
        # UnitTestResult entries. Count actual result outcomes instead.
        for result in tree.findall('.//t:UnitTestResult', ns):
            name, outcome = result.attrib.get('testName', ''), result.attrib.get('outcome')
            counts[outcome] = counts.get(outcome, 0) + 1
            if any(k in name for k in ('SharedWriterHintCompletion', 'SharedWriterPressure',
                                      'SharedOpeningMutation', 'SharedCoordinationPublication',
                                      'SharedOrdinaryOpen', 'SharedMappedProcess', 'SharedCoordinationFile', 'SharedCoordinationAbiRegression', 'SharedCoordinationProtocol', 'SharedCoordinationUpgradeProcess')):
                affected.append({'test': name, 'outcome': outcome})
            if outcome == 'NotExecuted':
                skipped.append(name)
    summary.append({'artifact': directory.name, 'outcomes': counts, 'runtime': sorted(runtime),
                    'affectedTests': affected, 'skippedTests': skipped})
    assert counts['Failed'] == 0, directory
    assert all(r['outcome'] == 'Passed' for r in affected), directory
(root / 'test-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Validated', len(summary), 'test artifacts')
