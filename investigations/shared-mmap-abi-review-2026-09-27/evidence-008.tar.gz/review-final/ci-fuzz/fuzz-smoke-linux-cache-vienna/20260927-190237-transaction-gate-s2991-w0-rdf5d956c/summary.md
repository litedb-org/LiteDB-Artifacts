# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `0,737s`
- Git SHA: `44f113be3e6e8e60637c5df8703bde23f368daab`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `2387A6A95F9F18A9812B85A15D50FE5AAE4E0C98B62D58EB7232B6E1E68D6AB5`
- Trace SHA-256: `9FCA76F1DB92F62A1A4B13039394DACB8CC0CE4D5131B81179513875987E2831`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-190237-transaction-gate-s2991-w0-rdf5d956c/replay.json`

## Metrics

- novelStates: `14`
- foreignLeasesReleased: `237`
