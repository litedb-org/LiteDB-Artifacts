# LiteDB fuzz result: mapper

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `0.500s`
- Git SHA: `44f113be3e6e8e60637c5df8703bde23f368daab`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `9DBF7D8456684144D8D8076009603A42A106B9DE0E10FDE6BDABE1CD14D7706A`
- Trace SHA-256: `C5039C89D036DF7D36AE9188A707C033272A74C20897DB06BD9F7B3F2ADE586C`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-192241-mapper-determinism-s42947-w0-r5095db35/replay.json`

## Metrics

- cycleFailures: `4`
- enumAsInteger: `False`
