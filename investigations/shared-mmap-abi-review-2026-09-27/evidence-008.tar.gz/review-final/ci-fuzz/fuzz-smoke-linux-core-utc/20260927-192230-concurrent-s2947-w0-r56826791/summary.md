# LiteDB fuzz result: concurrent

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `2.697s`
- Git SHA: `44f113be3e6e8e60637c5df8703bde23f368daab`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-192230-concurrent-s2947-w0-r56826791/replay.json`

## Metrics

- novelStates: `2`
- semanticIndexKeys: `62`
- semanticDocuments: `31`
- semanticIndexes: `2`
- integrityPages: `5`
- integrityPhysicalPages: `5`
- concurrentCommittedUpdates: `120`
- uniqueContentionWinners: `30`
