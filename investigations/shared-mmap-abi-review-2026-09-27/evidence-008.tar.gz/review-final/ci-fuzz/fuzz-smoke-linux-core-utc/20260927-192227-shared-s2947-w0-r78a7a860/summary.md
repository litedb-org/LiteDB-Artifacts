# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `45.433s`
- Git SHA: `44f113be3e6e8e60637c5df8703bde23f368daab`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `6EB1AD4DADE60E310AB0458C49B00833A704DA8649ACF7E6366F5D660F32C365`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260927-192227-shared-s2947-w0-r78a7a860/replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `1000`
- semanticDocuments: `1000`
- semanticIndexes: `30`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `30`
- processes: `90`
- acknowledgedRows: `970`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `30`
