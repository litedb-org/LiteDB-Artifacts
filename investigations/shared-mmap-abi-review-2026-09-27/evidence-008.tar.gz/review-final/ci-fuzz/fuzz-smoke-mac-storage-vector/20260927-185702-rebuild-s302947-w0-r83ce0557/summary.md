# LiteDB fuzz result: rebuild

- Status: **PASS**
- Seed: `302947`
- Steps: `30` / requested `30`
- Duration: `4.185s`
- Git SHA: `44f113be3e6e8e60637c5df8703bde23f368daab`
- Working tree dirty: `True`
- Environment: `macOS 26.6.2`, `.NET 10.0.12`, `Arm64`
- Culture/timezone: `en-US` / `America/New_York`
- Failure ID: `n/a`
- Input SHA-256: `28B0D9270E5FE6B714B937CEA57EC3051C635B415BF3487618579B84D5DA04A3`
- Trace SHA-256: `806641B7F28DACFCC11EAE6944A669134876C8AA41A31FED73B908E5D27B5470`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __HOME__/work/LiteDB/LiteDB/artifacts/fuzz/20260927-185702-rebuild-s302947-w0-r83ce0557/replay.json`

## Metrics

- semanticIndexKeys: `2180`
- semanticDocuments: `1090`
- semanticIndexes: `60`
- integrityPages: `10`
- integrityPhysicalPages: `10`
- documents: `59`
- encrypted: `False`
- corruptionProbes: `4`
- corruptionRejections: `4`
- integrityChecks: `30`
