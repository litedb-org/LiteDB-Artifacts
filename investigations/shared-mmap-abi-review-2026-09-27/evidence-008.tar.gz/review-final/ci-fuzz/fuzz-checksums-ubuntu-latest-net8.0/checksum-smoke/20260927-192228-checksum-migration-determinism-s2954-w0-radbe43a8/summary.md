# LiteDB fuzz result: checksum-migration

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `7.464s`
- Git SHA: `76604f01fcc1993ab2841dbcdb8878ee1cf56ee3`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `5C56EEA051A5BA9C6E11EEB5315447387A3613A47D6414F6312B9AB876B9F795`
- Trace SHA-256: `2F196A7FA552F862D6C054B721B4CBE37521E71CAC500D2898F6236CD9A9421D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260927-192228-checksum-migration-determinism-s2954-w0-radbe43a8/replay.json`

## Metrics

- novelStates: `7`
- migrationCases: `28`
- transactionBatches: `224`
