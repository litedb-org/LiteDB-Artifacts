import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[2] / 'scripts/collect-retained-fixtures.py'
spec = importlib.util.spec_from_file_location('retained', SCRIPT)
retained = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)


class RetainedFixtureTests(unittest.TestCase):
    def test_actual_child_must_exit_before_database_wal_and_coordination_are_copied(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            sources, manifests = root / 'original-volume', root / 'artifacts'
            sources.mkdir()
            manifests.mkdir()
            stem = 'litedb-' + 'a' * 32
            child = subprocess.Popen([sys.executable, '-u', '-c', '''
import json, os, pathlib, sys
sources, manifests, stem = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
for suffix in ('.db', '-log.db', '-shared-live', '-shared-state'):
    (sources / (stem + suffix)).write_bytes(suffix.encode())
(sources / (stem + '-readers')).mkdir()
(sources / (stem + '-readers/lease')).write_bytes(b'lease')
(sources / ('litedb-' + 'b' * 32 + '.db')).write_bytes(b'unrelated')
held = (sources / (stem + '.db')).open('rb')
(manifests / 'failed.json').write_text(json.dumps({'database': str(sources / (stem + '.db')), 'processId': os.getpid(), 'failure': 'original assertion'}))
print('ready', flush=True)
sys.stdin.readline()
''', str(sources), str(manifests), stem], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
            try:
                self.assertEqual(child.stdout.readline().strip(), 'ready')
                self.assertEqual(retained.collect(manifests), 1)
                self.assertFalse((manifests / 'failed' / (stem + '.db')).exists())
                child.communicate('\n', timeout=10)
                self.assertEqual(child.returncode, 0)
                self.assertEqual(retained.collect(manifests), 0)
                report = json.loads((manifests / 'failed/collection-report.json').read_text())
                self.assertEqual(report['primaryFailure'], 'original assertion')
                self.assertEqual(len(report['files']), 5)
                for source in sources.rglob('*'):
                    if source.is_file() and source.name != 'litedb-' + 'b' * 32 + '.db':
                        copied = manifests / 'failed' / source.relative_to(sources)
                        self.assertEqual(copied.read_bytes(), source.read_bytes())
                self.assertFalse((manifests / 'failed' / ('litedb-' + 'b' * 32 + '.db')).exists())
            finally:
                if child.poll() is None:
                    child.kill()
                    child.communicate()

    def test_copy_failure_is_separate_and_remaining_files_are_collected(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            stem = 'litedb-' + 'a' * 32
            db = root / (stem + '.db')
            db.write_bytes(b'database')
            (root / (stem + '-log.db')).write_bytes(b'wal')
            (root / 'failed.json').write_text(json.dumps({'database': str(db), 'processId': 1, 'failure': 'primary'}))
            original = retained.shutil.copy2
            def copy(source, destination):
                if source == db:
                    raise OSError('copy failure sentinel')
                return original(source, destination)
            with patch.object(retained, 'running', return_value=False), patch.object(retained.shutil, 'copy2', side_effect=copy):
                self.assertEqual(retained.collect(root), 1)
            report = json.loads((root / 'failed/collection-report.json').read_text())
            self.assertEqual(report['primaryFailure'], 'primary')
            self.assertIn('copy failure sentinel', report['errors'][0])
            self.assertEqual(len(report['files']), 1)
            self.assertEqual(db.read_bytes(), b'database')

    @unittest.skipUnless(sys.platform.startswith('linux'), 'Linux zombie process state')
    def test_exited_unreaped_child_has_no_live_handles(self):
        child = subprocess.Popen([sys.executable, '-c', 'pass'])
        try:
            os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOWAIT)
            self.assertFalse(retained.running(child.pid))
        finally:
            child.wait(timeout=10)

    def test_no_failures_is_noop(self):
        with tempfile.TemporaryDirectory() as root:
            self.assertEqual(retained.collect(Path(root)), 0)
