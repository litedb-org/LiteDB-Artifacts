# LiteDB fuzz result: sort

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `2.927s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `7348E169D8FF0326497B3E6F44F52C7DE4C6963F9EA516EFC15AFF7597D74241`
- Trace SHA-256: `3ECB000BF5BEC70E1BE51EEE9A6D763C962E20B04262D8B102211E0E9A87863D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-114451-sort-s202947-w0-r1212188d\replay.json`

## Metrics

- earlySpilledCursorDisposals: `8`
- boundedSortTempBytes: `2457600`
- topNChecks: `60`
- longKeyDocuments: `420`
- documents: `1200`
- collation: `en-US/IgnoreCase`
- observedSortSpills: `28`
