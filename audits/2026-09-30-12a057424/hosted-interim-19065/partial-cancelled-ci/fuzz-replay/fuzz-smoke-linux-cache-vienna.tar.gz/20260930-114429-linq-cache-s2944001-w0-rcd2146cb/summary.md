# LiteDB fuzz result: linq-cache

- Status: **PASS**
- Seed: `2944001`
- Steps: `200` / requested `200`
- Duration: `1,948s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `346B916B1FB76EF98355E63780F3A47ACD5998E64C0725C01A6EB541134B3958`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114429-linq-cache-s2944001-w0-rcd2146cb/replay.json`

## Metrics

- supportedTranslations: `166`
- cacheEntries: `73`
- concurrencyCases: `200`
