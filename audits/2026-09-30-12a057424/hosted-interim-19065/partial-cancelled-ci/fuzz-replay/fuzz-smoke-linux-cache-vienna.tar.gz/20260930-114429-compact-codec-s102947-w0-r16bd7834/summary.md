# LiteDB fuzz result: compact-codec

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,163s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `F43006A5F4034A482DC297FA966DE72FB8DAB8D6670516D36450D93C29826E33`
- Trace SHA-256: `C2F522121E438BFB72FC4CCB9671B2E78371DD1E7F6C7A076C30DFE612887DC0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114429-compact-codec-s102947-w0-r16bd7834/replay.json`

## Metrics

- vectorBoundaryCases: `6`
- novelStates: `30`
- decoded: `30`
- projected: `30`
- mutations: `30`
- mutationRejections: `30`
- schemas: `6`
