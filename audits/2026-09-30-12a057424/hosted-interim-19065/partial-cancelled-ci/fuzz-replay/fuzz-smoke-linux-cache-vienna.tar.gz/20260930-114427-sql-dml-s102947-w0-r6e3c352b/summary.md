# LiteDB fuzz result: sql-dml

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,454s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `8F7968DF8B4DCB314422F3C1B3F5C46FF0F6D1AB3B7E322316EE1EFF030274F4`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114427-sql-dml-s102947-w0-r6e3c352b/replay.json`

## Metrics

- novelStates: `17`
- sqlDmlMutations: `7`
