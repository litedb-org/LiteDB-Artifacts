# LiteDB fuzz result: cursor-handoff

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `2,908s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `0A092B10C46DEAB0D2646E0B7FD6406D58309515B8D493822E6123D0D4BD5E6A`
- Trace SHA-256: `038FAF0298AA258346AD02521E4D6C218E907381821F75680023B5CE33257757`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104621-cursor-handoff-s2991-w0-r78d16bb1/replay.json`

## Metrics

- novelStates: `12`
- cursorsHandedOff: `190`
- semanticIndexKeys: `12`
- semanticDocuments: `12`
- semanticIndexes: `1`
- integrityPages: `4`
- integrityPhysicalPages: `4`
