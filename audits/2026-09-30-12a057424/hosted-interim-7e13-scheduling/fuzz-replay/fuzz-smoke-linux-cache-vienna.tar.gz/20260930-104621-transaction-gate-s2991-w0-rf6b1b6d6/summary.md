# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `0,781s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `2387A6A95F9F18A9812B85A15D50FE5AAE4E0C98B62D58EB7232B6E1E68D6AB5`
- Trace SHA-256: `9FCA76F1DB92F62A1A4B13039394DACB8CC0CE4D5131B81179513875987E2831`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104621-transaction-gate-s2991-w0-rf6b1b6d6/replay.json`

## Metrics

- novelStates: `14`
- foreignLeasesReleased: `237`
