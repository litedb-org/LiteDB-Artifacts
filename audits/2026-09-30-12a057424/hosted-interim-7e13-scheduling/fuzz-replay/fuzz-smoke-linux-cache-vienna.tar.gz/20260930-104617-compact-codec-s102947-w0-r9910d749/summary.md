# LiteDB fuzz result: compact-codec

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,310s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `F43006A5F4034A482DC297FA966DE72FB8DAB8D6670516D36450D93C29826E33`
- Trace SHA-256: `C2F522121E438BFB72FC4CCB9671B2E78371DD1E7F6C7A076C30DFE612887DC0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104617-compact-codec-s102947-w0-r9910d749/replay.json`

## Metrics

- vectorBoundaryCases: `6`
- novelStates: `30`
- decoded: `30`
- projected: `30`
- mutations: `30`
- mutationRejections: `30`
- schemas: `6`
