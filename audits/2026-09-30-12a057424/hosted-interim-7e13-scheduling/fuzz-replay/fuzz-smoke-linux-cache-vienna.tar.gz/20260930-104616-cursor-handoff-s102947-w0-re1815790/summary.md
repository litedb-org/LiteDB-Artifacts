# LiteDB fuzz result: cursor-handoff

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `7,012s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `614D8D6FB3682636CD8F9679DC9F61D49F66123D25219AE98FBAFE91939A99F6`
- Trace SHA-256: `56F734E0943ACE65C33B09063439C1F8C9D01C3DDC19EED9E51E768C026FE4F8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104616-cursor-handoff-s102947-w0-re1815790/replay.json`

## Metrics

- novelStates: `20`
- cursorsHandedOff: `263`
- semanticIndexKeys: `12`
- semanticDocuments: `12`
- semanticIndexes: `1`
- integrityPages: `4`
- integrityPhysicalPages: `4`
