# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,867s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `D20E48F572B24D99C9302829CA8CC61304721F51CCD9CCF921C0610D694D3499`
- Trace SHA-256: `7726EE8CB7D72903CDF20D1E05EDB18F3C7CB7EFEC521158835403C62CD91C38`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104616-transaction-gate-s102947-w0-r18d45e79/replay.json`

## Metrics

- novelStates: `20`
- foreignLeasesReleased: `367`
