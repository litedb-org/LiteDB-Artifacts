# LiteDB fuzz result: value

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `0.338s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `0395E02C99D5AD118CC213FDD6A3B350DDD787290E97014E25C83991A01C85AA`
- Trace SHA-256: `150E7EB5BEAAAD8C68F25A67053E2E06540BA8AADA6EBC658821BD692CF83383`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104856-value-determinism-s42947-w0-rf07cdb94/replay.json`

## Metrics

- autoIds: `40`
- collation: `tr-TR/IgnoreCase`
