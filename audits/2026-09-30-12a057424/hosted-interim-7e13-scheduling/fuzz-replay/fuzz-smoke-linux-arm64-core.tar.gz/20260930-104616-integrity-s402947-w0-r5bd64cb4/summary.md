# LiteDB fuzz result: integrity

- Status: **PASS**
- Seed: `402947`
- Steps: `1` / requested `30`
- Duration: `0.814s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `Arm64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `76A0C5AF7676F97C7D54D1DDDF1CFC0C63B6AB9488E00B4CD4B691FE189BE2F0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104616-integrity-s402947-w0-r5bd64cb4/replay.json`

## Metrics

- semanticIndexKeys: `81`
- semanticDocuments: `35`
- semanticIndexes: `9`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- mutantsDetected: `10`
- preallocatedLayouts: `1`
- encryptedLayouts: `1`
- legacyFiles: `1`
