# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `3` / requested `3`
- Duration: `1.027s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-104633-conflict-s2947-w0-r2a94f1b0/replay.json`

## Metrics

- semanticIndexKeys: `88`
- semanticDocuments: `49`
- semanticIndexes: `13`
- integrityPages: `54`
- integrityPhysicalPages: `54`
- novelStates: `1`
- forcedConflictingOperations: `18`
