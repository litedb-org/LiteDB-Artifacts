# LiteDB fuzz result: linq-cache

- Status: **PASS**
- Seed: `2944001`
- Steps: `200` / requested `200`
- Duration: `2,524s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `346B916B1FB76EF98355E63780F3A47ACD5998E64C0725C01A6EB541134B3958`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090446-linq-cache-s2944001-w0-rcfe1592b/replay.json`

## Metrics

- supportedTranslations: `166`
- cacheEntries: `73`
- concurrencyCases: `200`
