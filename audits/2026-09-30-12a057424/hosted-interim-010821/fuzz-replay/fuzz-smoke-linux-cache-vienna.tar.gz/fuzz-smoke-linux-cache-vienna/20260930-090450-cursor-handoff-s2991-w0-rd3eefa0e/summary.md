# LiteDB fuzz result: cursor-handoff

- Status: **PASS**
- Seed: `2991`
- Steps: `20` / requested `20`
- Duration: `2,482s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `0A092B10C46DEAB0D2646E0B7FD6406D58309515B8D493822E6123D0D4BD5E6A`
- Trace SHA-256: `038FAF0298AA258346AD02521E4D6C218E907381821F75680023B5CE33257757`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090450-cursor-handoff-s2991-w0-rd3eefa0e/replay.json`

## Metrics

- novelStates: `12`
- cursorsHandedOff: `190`
- semanticIndexKeys: `12`
- semanticDocuments: `12`
- semanticIndexes: `1`
- integrityPages: `4`
- integrityPhysicalPages: `4`
