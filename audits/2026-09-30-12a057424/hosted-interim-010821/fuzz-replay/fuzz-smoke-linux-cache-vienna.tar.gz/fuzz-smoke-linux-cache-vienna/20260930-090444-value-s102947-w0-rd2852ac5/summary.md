# LiteDB fuzz result: value

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,375s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `3DB335AAEC616375549DB71832E69DB5CD2A0D82FC487D79EADF47C6117CA9F2`
- Trace SHA-256: `3D259788A4472F78033EC3672E4F2EED05C318E7F65D4AA15AB745D9B763F641`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090444-value-s102947-w0-rd2852ac5/replay.json`

## Metrics

- autoIds: `30`
- collation: `tr-TR/IgnoreCase`
