# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `1,026s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `D20E48F572B24D99C9302829CA8CC61304721F51CCD9CCF921C0610D694D3499`
- Trace SHA-256: `7726EE8CB7D72903CDF20D1E05EDB18F3C7CB7EFEC521158835403C62CD91C38`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090445-transaction-gate-s102947-w0-r3ce2c698/replay.json`

## Metrics

- novelStates: `20`
- foreignLeasesReleased: `367`
