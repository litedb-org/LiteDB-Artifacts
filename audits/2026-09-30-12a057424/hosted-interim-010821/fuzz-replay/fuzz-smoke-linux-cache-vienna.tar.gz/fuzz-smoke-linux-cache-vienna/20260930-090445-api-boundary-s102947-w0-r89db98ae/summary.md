# LiteDB fuzz result: api-boundary

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `5,493s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090445-api-boundary-s102947-w0-r89db98ae/replay.json`

## Metrics

- semanticIndexKeys: `3030`
- semanticDocuments: `3030`
- semanticIndexes: `960`
- integrityPages: `146`
- integrityPhysicalPages: `146`
- novelStates: `12`
- apiBoundaryCases: `30`
