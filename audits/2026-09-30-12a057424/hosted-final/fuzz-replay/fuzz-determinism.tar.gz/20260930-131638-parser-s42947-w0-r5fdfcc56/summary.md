# LiteDB fuzz result: parser

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `1.822s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `B6801AD25E55E24892E368D7FF78B0EAFA302B26CE653AA719A7311635562E6E`
- Trace SHA-256: `B1B808C8F24E37920DEE3FEAB5FEE8CD171C6A94FE6BDEE31E509E2E340244D1`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-131638-parser-s42947-w0-r5fdfcc56/replay.json`

## Metrics

- sqlDifferentialChecks: `40`
- distinctStatements: `34`
