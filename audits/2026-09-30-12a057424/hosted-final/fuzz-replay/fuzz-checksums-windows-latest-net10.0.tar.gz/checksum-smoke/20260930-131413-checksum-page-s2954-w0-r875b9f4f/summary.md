# LiteDB fuzz result: checksum-page

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `2.741s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `633B49487AFAD16221F610373D51405BF1E8A58FCF297A537800679AE9757F1D`
- Trace SHA-256: `7E42BF27B18CB018D343DDBCF78BB88D818FF01198A432ED13CAA388890BD52E`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-131413-checksum-page-s2954-w0-r875b9f4f\replay.json`

## Metrics

- novelStates: `16`
- rejectedProbes: `56`
