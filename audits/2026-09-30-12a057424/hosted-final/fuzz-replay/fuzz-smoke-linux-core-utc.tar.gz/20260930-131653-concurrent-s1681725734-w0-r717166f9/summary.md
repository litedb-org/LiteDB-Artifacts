# LiteDB fuzz result: concurrent

- Status: **PASS**
- Seed: `1681725734`
- Steps: `178` / requested `178`
- Duration: `4.907s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-131653-concurrent-s1681725734-w0-r717166f9/replay.json`

## Metrics

- novelStates: `2`
- semanticIndexKeys: `358`
- semanticDocuments: `179`
- semanticIndexes: `2`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- concurrentCommittedUpdates: `712`
- uniqueContentionWinners: `178`
