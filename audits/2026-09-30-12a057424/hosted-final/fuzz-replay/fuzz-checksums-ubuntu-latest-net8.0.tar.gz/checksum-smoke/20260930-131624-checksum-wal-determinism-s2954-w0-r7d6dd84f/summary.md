# LiteDB fuzz result: checksum-wal

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `5.845s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `7C3B59A6BFFD16578B211FDDB79BE10976CDB9CBB9709BC706546A899E56CA53`
- Trace SHA-256: `28B07E2299CB2AFB945194FEF7D2D453D8855D5A9B7770EA917640B22C466EB1`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-131624-checksum-wal-determinism-s2954-w0-r7d6dd84f/replay.json`

## Metrics

- novelStates: `25`
- recoveredPrefixes: `84`
