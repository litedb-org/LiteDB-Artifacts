# LiteDB fuzz result: parser

- Status: **PASS**
- Seed: `2946001`
- Steps: `100` / requested `100`
- Duration: `3,987s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `176E95080BA300FAD181976C3DA421B325B3E30B9B1681C5E28C8F2D43B0ABA8`
- Trace SHA-256: `3A15F2F77EEC5B3DFD783134BE187009EAC61377C07EE6403DC4CDDA8B46FB41`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-131541-parser-s2946001-w0-r13d7dec4/replay.json`

## Metrics

- sqlDifferentialChecks: `100`
- distinctStatements: `74`
