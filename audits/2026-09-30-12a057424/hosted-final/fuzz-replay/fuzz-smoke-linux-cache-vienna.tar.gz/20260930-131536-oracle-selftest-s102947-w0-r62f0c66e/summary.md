# LiteDB fuzz result: oracle-selftest

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,278s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-131536-oracle-selftest-s102947-w0-r62f0c66e/replay.json`

## Metrics

- novelStates: `30`
- controlledMutationsKilled: `240`
