# LiteDB fuzz result: query

- Status: **PASS**
- Seed: `402947`
- Steps: `30` / requested `30`
- Duration: `1.171s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `Arm64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `B464BA832DCB5F581972A9966991EF238C0DE6E8A4F0943F57B621B3191523D6`
- Trace SHA-256: `CAB811C9B6C7C7BEA31E72781FAFCE1B0CA2975DC3A3BA0DCC7EB77F6D6A4BE9`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-131443-query-s402947-w0-rb34e895b/replay.json`

## Metrics

- novelStates: `28`
- assertions: `390`
- operationHits: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- collation: `en-US/IgnoreNonSpace`
