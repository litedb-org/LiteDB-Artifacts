# LiteDB fuzz result: mapper

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `0.717s`
- Git SHA: `13252320c96e37b6a5edf7c1d8c5c6fddae62b77`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `BBD5B08E66CE2799BA53DB47EC9278ADA334676ECCBCC8A1BFCA6B4C4845792D`
- Trace SHA-256: `C41970A5AE631792BE3CCC4E9F3032DAE799E801C1A9207A04F83804B94E1550`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-131429-mapper-s202947-w0-rdbb446e9\replay.json`

## Metrics

- cycleFailures: `3`
- enumAsInteger: `False`
