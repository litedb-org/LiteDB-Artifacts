# LiteDB fuzz result: value

- Status: **PASS**
- Seed: `402947`
- Steps: `30` / requested `30`
- Duration: `0.366s`
- Git SHA: `3c06aadd78a8ee8be66b8ba42a4cf73bd0098638`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `Arm64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `52656642229A51F1B85ABA77644F0B02E2FA32E7856B02509214F5325A5A4B21`
- Trace SHA-256: `C2C32D959775A35DED07F87B38955059547595ECB02867D289CBD0CD9990278B`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-122109-value-s402947-w0-r4f18a5db/replay.json`

## Metrics

- autoIds: `30`
- collation: `tr-TR/IgnoreCase`
