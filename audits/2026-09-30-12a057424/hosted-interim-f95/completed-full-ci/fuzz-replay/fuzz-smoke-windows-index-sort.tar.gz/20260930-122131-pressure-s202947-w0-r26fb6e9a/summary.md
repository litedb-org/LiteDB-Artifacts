# LiteDB fuzz result: pressure

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `5.229s`
- Git SHA: `3c06aadd78a8ee8be66b8ba42a4cf73bd0098638`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-122131-pressure-s202947-w0-r26fb6e9a\replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `6060`
- semanticDocuments: `3030`
- semanticIndexes: `2`
- integrityPages: `944`
- integrityPhysicalPages: `944`
- observedCacheEvictions: `29954`
