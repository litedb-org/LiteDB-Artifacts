# LiteDB fuzz result: transaction

- Status: **PASS**
- Seed: `700001`
- Steps: `26` / requested `26`
- Duration: `0.772s`
- Git SHA: `3c06aadd78a8ee8be66b8ba42a4cf73bd0098638`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `63E8B7E290B94A1401D72688BA5E92D448A7C0BB0C8F1D56531F4E8D669E01CF`
- Trace SHA-256: `BC4462F3367C09426166445E83DCBFA5FE0A5B42EDFFDCE4A808A621346E756B`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-122257-transaction-s700001-w0-r140a4f9e/replay.json`

## Metrics

- semanticIndexKeys: `10`
- semanticDocuments: `10`
- semanticIndexes: `2`
- integrityPages: `10`
- integrityPhysicalPages: `10`
- documents: `10`
- collections: `2`
- integrityChecks: `1`
- commits: `0`
- rollbacks: `0`
- reopens: `2`
- schemaChanges: `1`
