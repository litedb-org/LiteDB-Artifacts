# LiteDB fuzz result: power-loss

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `2.702s`
- Git SHA: `3c06aadd78a8ee8be66b8ba42a4cf73bd0098638`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `FE432F112CD6A1BAE7D16A76200B9CFA093E2C784F6AFB14DFA59985513FF259`
- Trace SHA-256: `C60B9DECA714E13F1D01094124020AD776AE4492D5188726B41E38AFBDCF11A5`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-122250-power-loss-s2947-w0-rc354dd3e/replay.json`

## Metrics

- semanticIndexKeys: `362`
- semanticDocuments: `211`
- semanticIndexes: `120`
- integrityPages: `14`
- integrityPhysicalPages: `14`
- novelStates: `30`
- powerCuts: `30`
- durablePhases: `14`
