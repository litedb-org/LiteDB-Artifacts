# LiteDB fuzz result: boundary

- Status: **PASS**
- Seed: `2947`
- Steps: `1` / requested `30`
- Duration: `2.774s`
- Git SHA: `3c06aadd78a8ee8be66b8ba42a4cf73bd0098638`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-122254-boundary-s2947-w0-r88ce6c00/replay.json`

## Metrics

- semanticIndexKeys: `295`
- semanticDocuments: `39`
- semanticIndexes: `275`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- novelStates: `1`
- explicitBoundaries: `7`
