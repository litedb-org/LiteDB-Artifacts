# LiteDB fuzz result: mvcc-retirement

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `2.944s`
- Git SHA: `24ef4e73e53fd2b7291e6f3bdf9e2c0e69227f89`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `16468DE330D21332B8607BF57B7FC4BDDF9B2D1221D15ED64A2AB205FF742713`
- Trace SHA-256: `BAF930168673A0AF46344858D15886A5AD0DD55E9DC56DBAA6F8521BF42B5369`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-122103-mvcc-retirement-determinism-s2954-w0-r34b0c9ed/replay.json`

## Metrics

- novelStates: `26`
