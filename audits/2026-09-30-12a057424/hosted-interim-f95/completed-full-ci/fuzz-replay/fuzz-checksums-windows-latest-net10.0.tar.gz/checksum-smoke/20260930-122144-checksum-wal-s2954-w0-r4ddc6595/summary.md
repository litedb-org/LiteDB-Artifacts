# LiteDB fuzz result: checksum-wal

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `1.764s`
- Git SHA: `24ef4e73e53fd2b7291e6f3bdf9e2c0e69227f89`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `7C3B59A6BFFD16578B211FDDB79BE10976CDB9CBB9709BC706546A899E56CA53`
- Trace SHA-256: `28B07E2299CB2AFB945194FEF7D2D453D8855D5A9B7770EA917640B22C466EB1`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-122144-checksum-wal-s2954-w0-r4ddc6595\replay.json`

## Metrics

- novelStates: `25`
- recoveredPrefixes: `84`
