# LiteDB fuzz result: compact-crash

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `1.224s`
- Git SHA: `24ef4e73e53fd2b7291e6f3bdf9e2c0e69227f89`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `A285E67931C1ECF1F97787B8BACFDA511AAD9A56A84062FB46A2171E1455E8F0`
- Trace SHA-256: `FFC84602BBDA9E8A9AB6B721E110DE44D803C084997C70555C715B71E74FBDA8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-122138-compact-crash-determinism-s2954-w0-r33ff32a6\replay.json`

## Metrics

- novelStates: `22`
