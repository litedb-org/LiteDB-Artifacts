# LiteDB fuzz result: checksum-crash

- Status: **PASS**
- Seed: `3163459`
- Steps: `201` / requested `201`
- Duration: `12.781s`
- Git SHA: `24ef4e73e53fd2b7291e6f3bdf9e2c0e69227f89`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `9B8F44BBE4E6A62D0A424BEE719F53E347F5216FD1F1BD583F43CEBF4B638499`
- Trace SHA-256: `ECD2CDDA0F28EF8D481B90AB98AE8E1397C4131C73B98DE9786B1CDC9E85C0D8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-122146-checksum-crash-s3163459-w0-r80533df2\replay.json`

## Metrics

- novelStates: `69`
- crashEvents: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- crashCases: `201`
