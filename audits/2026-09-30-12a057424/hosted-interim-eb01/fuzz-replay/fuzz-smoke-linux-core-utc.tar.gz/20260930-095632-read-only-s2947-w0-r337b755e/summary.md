# LiteDB fuzz result: read-only

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `1.292s`
- Git SHA: `765c90eb37816dd4b9112d8c3f58689efc9b81f5`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `EF2CA7C6748B9F171790C5C1E9E941D384ABE605230F7B4A5B0F2B68CCC6DFEA`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-095632-read-only-s2947-w0-r337b755e/replay.json`

## Metrics

- forbiddenReadOnlyMutations: `10`
- novelStates: `10`
- semanticIndexKeys: `160`
- semanticDocuments: `80`
- semanticIndexes: `2`
- integrityPages: `5`
- integrityPhysicalPages: `5`
- byteStableReadWorkloads: `30`
