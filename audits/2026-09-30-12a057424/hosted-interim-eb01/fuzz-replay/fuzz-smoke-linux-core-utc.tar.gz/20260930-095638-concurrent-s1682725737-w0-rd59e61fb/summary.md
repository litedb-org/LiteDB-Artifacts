# LiteDB fuzz result: concurrent

- Status: **PASS**
- Seed: `1682725737`
- Steps: `67` / requested `67`
- Duration: `10.569s`
- Git SHA: `765c90eb37816dd4b9112d8c3f58689efc9b81f5`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-095638-concurrent-s1682725737-w0-rd59e61fb/replay.json`

## Metrics

- novelStates: `2`
- semanticIndexKeys: `136`
- semanticDocuments: `68`
- semanticIndexes: `2`
- integrityPages: `5`
- integrityPhysicalPages: `5`
- concurrentCommittedUpdates: `268`
- uniqueContentionWinners: `67`
