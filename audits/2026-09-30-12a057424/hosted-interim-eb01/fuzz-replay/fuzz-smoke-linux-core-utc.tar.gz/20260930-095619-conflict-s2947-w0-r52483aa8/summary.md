# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `12.613s`
- Git SHA: `765c90eb37816dd4b9112d8c3f58689efc9b81f5`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-095619-conflict-s2947-w0-r52483aa8/replay.json`

## Metrics

- semanticIndexKeys: `880`
- semanticDocuments: `490`
- semanticIndexes: `130`
- integrityPages: `51`
- integrityPhysicalPages: `51`
- novelStates: `1`
- forcedConflictingOperations: `180`
