using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using static LiteDB.Constants;

namespace LiteDB.Engine
{
    /// <summary>
    /// Header page represent first page on datafile. Engine contains a single instance of HeaderPage and all changes
    /// must be synchronized (using lock).
    /// </summary>
    internal class HeaderPage : BasePage
    {
        /// <summary>
        /// Header info the validate that datafile is a LiteDB file (27 bytes)
        /// </summary>
        public const string HEADER_INFO = "** This is a LiteDB file **";

        /// <summary>
        /// Datafile specification version
        /// </summary>
        public const byte FILE_VERSION = 8;
        public const byte VECTOR_FILE_VERSION = 9;
        public const byte CHECKSUM_FILE_VERSION = 10;
        public const byte INDEX_FILE_VERSION = 11;
        public const byte COMPACT_FILE_VERSION = 12;
        public const byte MVCC_FILE_VERSION = 13;
        public const byte CURRENT_FILE_VERSION = MVCC_FILE_VERSION;
        private volatile byte _fileVersion;
        public byte FileVersion => _fileVersion;

        internal void EnsureVersion(byte version)
        {
            version = Math.Max(_fileVersion, version);
            _buffer.Write(version, P_FILE_VERSION);
            _fileVersion = version;
        }

        #region Buffer Field Positions

        public const int P_HEADER_INFO = 32;  // 32-58 (27 bytes)
        public const int P_FILE_VERSION = 59; // 59-59 (1 byte)
        public const int P_FREE_EMPTY_PAGE_ID = 60; // 60-63 (4 bytes)
        public const int P_LAST_PAGE_ID = 64; // 64-67 (4 bytes)
        public const int P_CREATION_TIME = 68; // 68-75 (8 bytes)

        // private const int P_PRAGMAS = 76; // 76-190 (115 bytes)
        public const int P_INVALID_DATAFILE_STATE = 191; // 191-191 (1 byte)

        public const int P_COLLECTIONS = 192; // 192-8159 (8064 bytes)
        public const int COLLECTIONS_SIZE = 8000; // 250 blocks with 32 bytes each

        #endregion

        /// <summary>
        /// Get/Set the pageID that start sequence with a complete empty pages (can be used as a new page) [4 bytes]
        /// </summary>
        public uint FreeEmptyPageList { get; set; }

        /// <summary>
        /// Last created page - Used when there is no free page inside file [4 bytes]
        /// </summary>
        public uint LastPageID { get; set; }

        /// <summary>
        /// DateTime when database was created [8 bytes]
        /// </summary>
        public DateTime CreationTime { get; }

        /// <summary>
        /// Get database pragmas instance class
        /// </summary>
        public EnginePragmas Pragmas { get; set; }

        /// <summary>
        /// All collections names/link pointers are stored inside this document
        /// </summary>
        private BsonDocument _collections;

        /// <summary>
        /// Guards the collection map, and lets a snapshot pair it with a WAL read version. Writers hold lock(header)
        /// across log I/O; readers take only this lock, which a commit holds solely while it republishes the map.
        /// </summary>
        public object PublicationLock { get; } = new object();

        /// <summary>
        /// Check if collections was changed
        /// </summary>
        private bool _isCollectionsChanged = false;

        /// <summary>
        /// Create new Header Page
        /// </summary>
        public HeaderPage(PageBuffer buffer, uint pageID)
            : base(buffer, 0, PageType.Header)
        {
            // initialize page version
            this.CreationTime = DateTime.UtcNow;
            this.FreeEmptyPageList = uint.MaxValue;
            this.LastPageID = 0;

            // initialize pragmas
            this.Pragmas = new EnginePragmas(this);

            // New comparer ordering requires a downgrade barrier even without vectors.
            _buffer.Write(HEADER_INFO, P_HEADER_INFO);
            this.EnsureVersion(INDEX_FILE_VERSION);
            _buffer.Write(this.CreationTime, P_CREATION_TIME);

            // initialize collections
            _collections = new BsonDocument();
        }

        /// <summary>
        /// Load HeaderPage from buffer page
        /// </summary>
        public HeaderPage(PageBuffer buffer)
            : base(buffer)
        {
            this.CreationTime = this.LoadPage();
        }

        /// <summary>
        /// Load page content based on page buffer
        /// </summary>
        private DateTime LoadPage()
        {
            // check database file format
            var info = _buffer.ReadString(P_HEADER_INFO, HEADER_INFO.Length);
            var ver = _buffer[P_FILE_VERSION];

            if (string.CompareOrdinal(info, HEADER_INFO) != 0)
            {
                throw LiteException.InvalidDatabase();
            }

            if (ver != FILE_VERSION && ver != VECTOR_FILE_VERSION && ver != MVCC_FILE_VERSION && ver != COMPACT_FILE_VERSION && ver != INDEX_FILE_VERSION && ver != CHECKSUM_FILE_VERSION) throw LiteException.UnsupportedFileVersion(ver);
            _fileVersion = Math.Max(_fileVersion, ver); // Loading must not mutate a readable page.

            // CreateTime is readonly
            var creationTime = _buffer.ReadDateTime(P_CREATION_TIME);
            this.FreeEmptyPageList = _buffer.ReadUInt32(P_FREE_EMPTY_PAGE_ID);
            this.LastPageID = _buffer.ReadUInt32(P_LAST_PAGE_ID);

            // initialize engine pragmas
            this.Pragmas = new EnginePragmas(_buffer, this);

            // create new buffer area to store BsonDocument collections
            var area = _buffer.Slice(P_COLLECTIONS, COLLECTIONS_SIZE);

            using (var r = new BufferReader(new[] { area }, false) { AllowZeroLengthDocument = true })
            {
                var collections = r.ReadDocument().GetValue();
                lock (this.PublicationLock) _collections = collections;
            }

            _isCollectionsChanged = false;

            return creationTime;
        }

        public override PageBuffer UpdateBuffer()
        {
            _buffer.Write(_fileVersion, P_FILE_VERSION);
            _buffer.Write(this.FreeEmptyPageList, P_FREE_EMPTY_PAGE_ID);
            _buffer.Write(this.LastPageID, P_LAST_PAGE_ID);

            // update engine pragmas
            this.Pragmas.UpdateBuffer(_buffer);

            // update collection only if needed
            if (_isCollectionsChanged)
            {
                var area = _buffer.Slice(P_COLLECTIONS, COLLECTIONS_SIZE);

                using (var w = new BufferWriter(area))
                {
                    w.WriteDocument(_collections, true);
                }

                _isCollectionsChanged = false;
            }

            return base.UpdateBuffer();
        }

        /// <summary>
        /// Create a save point before do any change on header page (execute UpdateBuffer())
        /// </summary>
        public PageBuffer Savepoint()
        {
            this.UpdateBuffer();

            var savepoint = new PageBuffer(new byte[PAGE_SIZE], 0, 0);

            System.Buffer.BlockCopy(_buffer.Array, _buffer.Offset, savepoint.Array, savepoint.Offset, PAGE_SIZE);

            return savepoint;
        }

        /// <summary>
        /// Restore savepoint content and override on page. Must run in lock(_header)
        /// </summary>
        public void Restore(PageBuffer savepoint)
        {
            System.Buffer.BlockCopy(savepoint.Array, savepoint.Offset, _buffer.Array, _buffer.Offset, PAGE_SIZE);

            this.LoadPage();
            this.EnsureVersion(_fileVersion); // Restore owns this buffer; preserve a durable promotion.
        }

        /// <summary>
        /// Get collection PageID - return uint.MaxValue if not exists
        /// </summary>
        public uint GetCollectionPageID(string collection)
        {
            lock (this.PublicationLock)
            {
                return _collections.TryGetValue(collection, out var pageID) ? (uint)pageID.AsInt32 : uint.MaxValue;
            }
        }

        /// <summary>
        /// Get a snapshot of all collections with pageID, without holding the header lock during enumeration.
        /// </summary>
        public IEnumerable<KeyValuePair<string, uint>> GetCollections()
        {
            lock (this.PublicationLock)
            {
                return _collections.GetElements()
                    .Select(el => new KeyValuePair<string, uint>(el.Key, (uint)el.Value.AsInt32)).ToArray();
            }
        }

        /// <summary>
        /// Insert new collection in header
        /// </summary>
        public void InsertCollection(string name, uint pageID)
        {
            lock (this.PublicationLock) _collections[name] = (int)pageID;

            _isCollectionsChanged = true;
        }

        /// <summary>
        /// Remove existing collection reference in header
        /// </summary>
        public void DeleteCollection(string name)
        {
            lock (this.PublicationLock) _collections.Remove(name);

            _isCollectionsChanged = true;
        }

        /// <summary>
        /// Rename collection with new name
        /// </summary>
        public void RenameCollection(string oldName, string newName)
        {
            lock (this.PublicationLock)
            {
                var pageID = _collections[oldName];

                _collections.Remove(oldName);

                _collections.Add(newName, pageID);
            }

            _isCollectionsChanged = true;
        }

        /// <summary>
        /// Get how many bytes are available in collection to store new collections
        /// </summary>
        public int GetAvailableCollectionSpace()
        {
            lock (this.PublicationLock)
            {
                return COLLECTIONS_SIZE - _collections.GetBytesCount(true) -
                    1 - // for int32 type (0x10)
                    1 - // for new CString ('\0')
                    4 - // for PageID (int32)
                    8; // reserved
            }
        }
    }
}
