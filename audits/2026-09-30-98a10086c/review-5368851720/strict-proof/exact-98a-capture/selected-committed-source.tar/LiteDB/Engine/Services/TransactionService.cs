using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using static LiteDB.Constants;

namespace LiteDB.Engine
{
    /// <summary>
    /// Represent a single transaction service. Need a new instance for each transaction.
    /// Transactions belong to a connection context and managed thread.
    /// </summary>
    internal class TransactionService : IDisposable
    {
        // instances from Engine
        private readonly HeaderPage _header;
        private readonly LockService _locker;
        private readonly DiskService _disk;
        private readonly DiskReader _reader;
        private readonly WalIndexService _walIndex;
        private readonly TransactionMonitor _monitor;

        // transaction controls
        private readonly Dictionary<string, Snapshot> _snapshots = new Dictionary<string, Snapshot>(StringComparer.OrdinalIgnoreCase);
        private readonly List<Snapshot> _cursorSnapshots = new List<Snapshot>();
        private readonly TransactionPages _transPages = new TransactionPages();

        // transaction info
        internal readonly TransactionOwner Owner;
        private readonly DateTime _startTime;
        private long _headerPosition = long.MaxValue;
        private LockMode _mode = LockMode.Read;
        private TransactionState _state = TransactionState.Active;

        // expose (as read only)
        public int ThreadID => Owner.Thread?.ManagedThreadId ?? 0;
        internal Thread OwnerThread => Owner.Thread;
        public uint TransactionID => _transPages.TransactionID;
        public TransactionState State => _state;
        public LockMode Mode => _mode;
        public TransactionPages Pages => _transPages;
        public DateTime StartTime => _startTime;
        public IEnumerable<Snapshot> Snapshots => _snapshots.Values.Concat(_cursorSnapshots);
        public bool QueryOnly { get; }
        internal int MaxObservedTransactionSize { get; private set; }

        // get/set
        public int MaxTransactionSize { get; set; }

        /// <summary>
        /// Get/Set how many open cursor this transaction are running
        /// </summary>
        public List<CursorInfo> OpenCursors { get; } = new List<CursorInfo>();

        /// <summary>
        /// Get/Set if this transaction was opened by BeginTrans() method (not by AutoTransaction/Cursor)
        /// </summary>
        public volatile bool ExplicitTransaction = false;

        public TransactionService(HeaderPage header, LockService locker, DiskService disk, WalIndexService walIndex, int maxTransactionSize, TransactionMonitor monitor, bool queryOnly)
        {
            // retain instances
            _header = header;
            _locker = locker;
            _disk = disk;
            _walIndex = walIndex;
            _monitor = monitor;
            Owner = new TransactionOwner(monitor.CurrentContext);

            this.QueryOnly = queryOnly;
            this.MaxTransactionSize = maxTransactionSize;

            // create new transactionID
            _transPages.TransactionID = walIndex.NextTransactionID();
            _startTime = DateTime.UtcNow;
            _reader = _disk.GetReader();
        }

        /// <summary>
        /// Create (or get from transaction-cache) snapshot and return
        /// </summary>
        public Snapshot CreateSnapshot(LockMode mode, string collection, bool addIfNotExists)
        {
            ENSURE(_state == TransactionState.Active, "transaction must be active to create new snapshot");

            Snapshot create() => new Snapshot(mode, collection, _header, _transPages, _locker, _walIndex, _reader, _disk, addIfNotExists, this.Safepoint);

            if (_snapshots.TryGetValue(collection, out var snapshot))
            {
                // if current snapshot are ReadOnly but request is about Write mode, dispose read and re-create new in WriteMode
                // or if a previous snapshot was opened with addIfNotExists=false
                if ((mode == LockMode.Write && snapshot.Mode == LockMode.Read) || (addIfNotExists && snapshot.CollectionPage == null))
                {
                    // Acquire the replacement before releasing an existing write
                    // lock, including a missing collection's snapshot. Active read
                    // cursors retain their original view until transaction cleanup.
                    var replacement = create();
                    // Includes can hold secondary collection snapshots not named
                    // by CursorInfo.Collection, so retain conservatively for any cursor.
                    if (snapshot.Mode == LockMode.Read && this.OpenCursors.Count > 0)
                    {
                        snapshot.RetainForCursor();
                        _cursorSnapshots.Add(snapshot);
                    }
                    else snapshot.Dispose();
                    _snapshots[collection] = snapshot = replacement;
                }
            }
            else
            {
                // if not exits, let's create here
                _snapshots[collection] = snapshot = create();
            }

            // update transaction mode to write in first write snaphost request
            if (mode == LockMode.Write) _mode = LockMode.Write;

            return snapshot;
        }

        /// <summary>
        /// If current transaction contains too much pages, now is safe to remove clean pages from memory and flush to wal disk dirty pages
        /// </summary>
        public void Safepoint()
        {
            if (_state != TransactionState.Active) throw new LiteException(0, "This transaction are invalid state");

            this.MaxObservedTransactionSize = Math.Max(this.MaxObservedTransactionSize, _transPages.TransactionSize);

            if (_monitor.CheckSafepoint(this))
            {
                LOG($"safepoint flushing transaction pages: {_transPages.TransactionSize}", "TRANSACTION");

                // if any snapshot are writable, persist pages
                if (_mode == LockMode.Write)
                {
                    this.PersistDirtyPages(false);
                }

                // clear local pages in all snapshots (read/write snapshosts)
                foreach (var snapshot in this.Snapshots)
                {
                    snapshot.Clear();
                }

                // there is no local pages in cache and all dirty pages are in log file
                _transPages.TransactionSize = 0;
            }
        }

        /// <summary>
        /// Persist all dirty in-memory pages (in all snapshots) and clear local pages list (even clean pages)
        /// </summary>
        private int PersistDirtyPages(bool commit)
        {
            var dirty = 0;
            var deletedTailLinked = false;

            // inner method to get all dirty pages
            IEnumerable<PageBuffer> source()
            {
                // get all dirty pages from all write snapshots
                // can include (or not) collection pages
                // update DirtyPagesLog inside transPage for all dirty pages was write on disk
                var pages = _snapshots.Values
                    .Where(x => x.Mode == LockMode.Write)
                    .SelectMany(x => x.GetWritablePages(true, commit));

                // mark last dirty page as confirmed only if there is no header change in commit
                var markLastAsConfirmed = commit && _transPages.HeaderChanged == false;

                // neet use "IsLast" method to get when loop are last item
                foreach (var page in pages.IsLast())
                {
                    // update page transactionID
                    page.Item.TransactionID = this.TransactionID;

                    // if last page, mask as confirm (only if a real commit and no header changes)
                    if (page.IsLast)
                    {
                        page.Item.IsConfirmed = markLastAsConfirmed;
                    }

                    // if current page is last deleted page, point this page to last free
                    if (_transPages.LastDeletedPageID == page.Item.PageID && commit)
                    {
                        ENSURE(_transPages.HeaderChanged, "must header be in lock");
                        ENSURE(page.Item.PageType == PageType.Empty, "must be marked as deleted page");

                        // join existing free list pages into new list of deleted pages
                        page.Item.NextPageID = _header.FreeEmptyPageList;

                        // and now, set header free list page to this new list
                        _header.FreeEmptyPageList = _transPages.FirstDeletedPageID;
                        deletedTailLinked = true;
                    }

                    page.Item.UpdateBuffer();

                    // Disk owns each yielded buffer, including failed writes.
                    // Cleanup must skip it even if the frame has been recycled.
                    yield return page.Item.TakeBuffer();

                    dirty++;

                }

                // A safepoint can persist and evict every deleted page before
                // Commit. Re-emit the tail so it links the new deleted-page
                // chain to the previous header free list before publishing the
                // header that points at the chain's head.
                if (commit && _transPages.DeletedPages > 0 && !deletedTailLinked)
                {
                    ENSURE(_transPages.DirtyPages.TryGetValue(_transPages.LastDeletedPageID, out var position),
                        "deleted tail must have a persisted WAL position");
                    var buffer = _reader.ReadPage(position.Position, true, FileOrigin.Log);
                    var tail = BasePage.ReadPage<BasePage>(buffer);
                    ENSURE(tail.PageType == PageType.Empty, "deleted tail must be an empty page");
                    tail.NextPageID = _header.FreeEmptyPageList;
                    tail.TransactionID = this.TransactionID;
                    tail.IsConfirmed = false;
                    _header.FreeEmptyPageList = _transPages.FirstDeletedPageID;
                    tail.UpdateBuffer();
                    yield return tail.TakeBuffer();
                    dirty++;
                }

                // A final safepoint can leave every changed page on disk. Append
                // a confirmed copy so this commit still publishes those slots.
                if (markLastAsConfirmed && dirty == 0 && _transPages.DirtyPages.Count > 0)
                {
                    var position = _transPages.DirtyPages.Values.First().Position;
                    var buffer = _reader.ReadPage(position, true, FileOrigin.Log);
                    buffer.Write(true, BasePage.P_IS_CONFIRMED);
                    yield return buffer;
                }

                // in commit with header page change, last page will be header
                if (commit && _transPages.HeaderChanged)
                {
                    // update this confirm page with current transactionID
                    _header.TransactionID = this.TransactionID;

                    // this header page will be marked as confirmed page in log file
                    _header.IsConfirmed = true;

                    // invoke all header callbacks (new/drop collections)
                    _transPages.OnCommit(_header);

                    // clone header page
                    var buffer = _header.UpdateBuffer();
                    var clone = _disk.NewPage();

                    // mem copy from current header to new header clone
                    Buffer.BlockCopy(buffer.Array, buffer.Offset, clone.Array, clone.Offset, clone.Count);

                    // persist header in log file
                    yield return clone;
                }
            };

            // Reuse this transaction's unconfirmed slots across safepoints.
            // Disk always appends the confirmation page, preserving recovery order.
            var count = _disk.WriteLogDisk(source(), (pageID, position) =>
            {
                if (pageID == 0) _headerPosition = position;
                else _transPages.DirtyPages[pageID] = new PagePosition(pageID, position);
            }, _transPages, _walIndex.NextTransactionID);

            if (_transPages.HeaderChanged)
            {
                _header.TransactionID = this.TransactionID;
            }

            // now, discard all clean pages (because those pages are writable and must be readable)
            // from write snapshots
            _disk.DiscardCleanPages(_snapshots.Values
                    .Where(x => x.Mode == LockMode.Write)
                    .SelectMany(x => x.GetWritablePages(false, commit))
                    .Select(x => x.TakeBuffer()));

            return count;
        }

        /// <summary>
        /// Write pages into disk and confirm transaction in wal-index. Returns true if any dirty page was updated
        /// After commit, all snapshot are closed
        /// </summary>
        public void Commit()
        {
            ENSURE(_state == TransactionState.Active, "transaction must be active to commit (current state: {0})", _state);

            LOG($"commit transaction ({_transPages.TransactionSize} pages)", "TRANSACTION");

            if (_mode == LockMode.Write || _transPages.HeaderChanged)
            {
                lock (_header)
                {
                    // Header callbacks republish the collection map, so only those commits keep new
                    // snapshots out until the WAL index confirms them. No other commit may make
                    // readers wait for the durable log flush.
                    if (_transPages.HasCommitCallbacks)
                    {
                        lock (_header.PublicationLock) this.PersistAndConfirm();
                    }
                    else this.PersistAndConfirm();
                }
            }

            // Record the known durable outcome independently of cleanup state.
            if (Owner.Explicit != null) Owner.Explicit.Outcome = LiteTransactionState.Committed;

            foreach (var snapshot in this.Snapshots)
            {
                snapshot.Dispose();
            }

            _state = TransactionState.Committed;
        }

        private void PersistAndConfirm()
        {
            // persist all dirty page as commit mode (mark last page as IsConfirm)
            var count = this.PersistDirtyPages(true);

            // update wal-index (if any page was added into log disk)
            if (count > 0)
            {
#if DEBUG || TESTING
                _disk.TestCrashPoint("wal-before-index-confirmation");
#endif
                _walIndex.ConfirmTransaction(_transPages.TransactionID, _transPages.DirtyPages.Values, _headerPosition);
#if DEBUG || TESTING
                _disk.TestCrashPoint("wal-after-index-confirmation");
#endif
            }
        }

        /// <summary>
        /// Rollback transaction operation - ignore all modified pages and return new pages into disk
        /// After rollback, all snapshot are closed
        /// </summary>
        public void Rollback()
        {
            ENSURE(_state == TransactionState.Active, "transaction must be active to rollback (current state: {0})", _state);

            LOG($"rollback transaction ({_transPages.TransactionSize} pages with {_transPages.NewPages.Count} returns)", "TRANSACTION");

            // if transaction contains new pages, must return to database in another transaction
            if (_transPages.NewPages.Count > 0)
            {
                this.ReturnNewPages();
            }

            // dispose all snapshots
            foreach (var snapshot in this.Snapshots)
            {
                // but first, if writable, discard changes
                if (snapshot.Mode == LockMode.Write)
                {
                    // discard all dirty pages (only buffers still writable)
                    _disk.DiscardDirtyPages(snapshot
                        .GetWritablePages(true, true)
                        .Select(x => x.TakeBuffer())
                        .Where(x => x.ShareCounter == BUFFER_WRITABLE));

                    // discard all clean pages (only buffers still writable)
                    _disk.DiscardCleanPages(snapshot
                        .GetWritablePages(false, true)
                        .Select(x => x.TakeBuffer())
                        .Where(x => x.ShareCounter == BUFFER_WRITABLE));
                }

                // now, release pages
                snapshot.Dispose();
            }

            _state = TransactionState.Aborted;
            _disk.ForgetWalTransaction(_transPages.TransactionID);
        }

        /// <summary>
        /// Return added pages when occurs an rollback transaction (run this only in rollback). Create new transactionID and add into
        /// Log file all new pages as EmptyPage in a linked order - also, update SharedPage before store
        /// </summary>
        private void ReturnNewPages()
        {
            // create new transaction ID
            var transactionPages = new TransactionPages { TransactionID = _walIndex.NextTransactionID() };

            // now lock header to update LastTransactionID/FreePageList
            lock (_header)
            {
                // persist all empty pages into wal-file
                var pagePositions = new Dictionary<uint, PagePosition>();

                IEnumerable<PageBuffer> source()
                {
                    // create list of empty pages with forward link pointer
                    for (var i = 0; i < _transPages.NewPages.Count; i++)
                    {
                        var pageID = _transPages.NewPages[i];
                        var next = i < _transPages.NewPages.Count - 1 ? _transPages.NewPages[i + 1] : _header.FreeEmptyPageList;

                        var buffer = _disk.NewPage();

                        var page = new BasePage(buffer, pageID, PageType.Empty)
                        {
                            NextPageID = next,
                            TransactionID = transactionPages.TransactionID
                        };

                        yield return page.UpdateBuffer();

                    }

                    // update header page with my new transaction ID
                    _header.TransactionID = transactionPages.TransactionID;
                    _header.FreeEmptyPageList = _transPages.NewPages[0];
                    _header.IsConfirmed = true;

                    // clone header buffer
                    var buf = _header.UpdateBuffer();
                    var clone = _disk.NewPage();

                    Buffer.BlockCopy(buf.Array, buf.Offset, clone.Array, clone.Offset, clone.Count);

                    yield return clone;
                };

                // create a header save point before any change
                var safepoint = _header.Savepoint();

                try
                {
                    // write all pages (including new header)
                    _disk.WriteLogDisk(source(), (pageID, position) =>
                    {
                        pagePositions[pageID] = new PagePosition(pageID, position);
                    }, transactionPages, _walIndex.NextTransactionID);
                    _header.TransactionID = transactionPages.TransactionID;
                }
                catch
                {
                    // must revert all header content if any error occurs during header change
                    _header.Restore(safepoint);
                    throw;
                }

                // now confirm this transaction to wal
                _walIndex.ConfirmTransaction(transactionPages.TransactionID, pagePositions.Values);
            }
        }

        /// <summary>
        /// Public implementation of Dispose pattern.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool dispose)
        {
            // All resources are managed. The monitor retains registered
            // transactions and releases them during explicit engine cleanup.
            if (!dispose || _state == TransactionState.Disposed)
            {
                return;
            }

            List<Exception> errors = null;
            // One damaged lease must not stop the remaining pages and reader
            // from being released during error-close.
            if (_state == TransactionState.Active && (_snapshots.Count > 0 || _cursorSnapshots.Count > 0))
            {
                foreach (var snapshot in this.Snapshots)
                {
                    TransactionPageCleanup.Release(snapshot, _disk.Cache,
                        true, ref errors);
                }
            }

            try
            {
                _reader.Dispose();
            }
            catch (Exception ex)
            {
                errors ??= new List<Exception>();
                errors.Add(ex);
            }
            _state = TransactionState.Disposed;

            if (errors != null) throw new AggregateException(errors);
        }
    }
}
