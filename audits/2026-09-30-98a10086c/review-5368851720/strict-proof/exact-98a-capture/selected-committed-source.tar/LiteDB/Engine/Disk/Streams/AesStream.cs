﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using LiteDB.Utils;
using static LiteDB.Constants;

namespace LiteDB.Engine
{
    /// <summary>
    /// Encrypted AES Stream
    /// </summary>
    public partial class AesStream : Stream
    {
        private readonly Aes _aes;
        private readonly ICryptoTransform _encryptor;
        private readonly ICryptoTransform _decryptor;

        private readonly string _name;
        private readonly Stream _stream;
        private readonly CryptoStream _reader;
        private readonly CryptoStream _writer;
        private int _disposed;

        private readonly byte[] _decryptedZeroes = new byte[16];

        private static readonly byte[] _emptyContent = new byte[PAGE_SIZE - 1 - 16]; // 1 for aes indicator + 16 for salt

        private static readonly ArrayPool<byte> _bufferPool = ArrayPool<byte>.Shared;

        public byte[] Salt { get; }

        public override bool CanRead => _stream.CanRead;

        public override bool CanSeek => _stream.CanSeek;

        public override bool CanWrite => _stream.CanWrite;

        public override long Length => _stream.Length - PAGE_SIZE;

        public override long Position
        {
            get => _stream.Position - PAGE_SIZE;
            set => this.Seek(value, SeekOrigin.Begin);
        }

        public long StreamPosition => _stream.Position;

        public AesStream(string password, Stream stream, bool allowRecovery = true)
        {
            _stream = stream ?? throw new ArgumentNullException(nameof(stream));
            _name = _stream is FileStream fileStream ? Path.GetFileName(Client.Shared.AdmittedFileStream.GetName(fileStream)) : null;
            const int checkBufferSize = 32;
            byte[] checkBuffer = null;
            byte[] msBuffer = null;

            try
            {
                // engine opens never overwrite existing bytes: a short stream is only accepted as an
                // interrupted creation, which is decided below once its salt is known
                if (!allowRecovery) AesPreamble.EnsureMarker(_stream);
                var isNew = allowRecovery ? _stream.Length < PAGE_SIZE : _stream.Length == 0;
                _stream.Position = 0;
                checkBuffer = _bufferPool.Rent(checkBufferSize);
                msBuffer = _bufferPool.Rent(16);
                // new file? create new salt
                if (isNew)
                {
                    this.Salt = NewSalt();

                    // first byte =1 means this datafile is encrypted
                    _stream.WriteByte(1);
                    _stream.Write(this.Salt, 0, ENCRYPTION_SALT_SIZE);
                }
                else
                {
                    this.Salt = new byte[ENCRYPTION_SALT_SIZE];

                    // checks if this datafile are encrypted
                    var isEncrypted = _stream.ReadByte();

                    if (isEncrypted != 1)
                    {
                        throw LiteException.FileNotEncrypted();
                    }

                    _stream.ReadRequired(this.Salt, 0, ENCRYPTION_SALT_SIZE);
                }

                _aes = Aes.Create();
                _aes.Padding = PaddingMode.None;
                _aes.Mode = CipherMode.ECB;

                var pdb = new Rfc2898DeriveBytes(password, this.Salt);

                using (pdb as IDisposable)
                {
                    _aes.Key = pdb.GetBytes(32);
                    _aes.IV = pdb.GetBytes(16);
                }

                _encryptor = _aes.CreateEncryptor();
                _decryptor = _aes.CreateDecryptor();

                _reader = _stream.CanRead ?
                    new CryptoStream(new NonClosingStream(_stream), _decryptor, CryptoStreamMode.Read) :
                    null;

                _writer = _stream.CanWrite ?
                    new CryptoStream(new NonClosingStream(_stream), _encryptor, CryptoStreamMode.Write) :
                    null;

                // set stream to password checking
                _stream.Position = 32;


                if (!isNew && !allowRecovery)
                {
                    isNew = AesPreamble.IsInterruptedCreation(_stream);
                    _stream.Position = 32;
                }
                else if (!isNew)
                {
                    // check whether bytes 32 to 64 is empty. This indicates LiteDb was unable to write encrypted 1s during last attempt.
                    _stream.ReadRequired(checkBuffer, 0, checkBufferSize);
                    isNew = checkBuffer.All(x => x == 0);

                    // reset checkBuffer and stream position
                    Array.Clear(checkBuffer, 0, checkBufferSize);
                    _stream.Position = 32;
                }

                // fill checkBuffer with encrypted 1 to check when open
                if (isNew)
                {
                    checkBuffer.Fill(1, 0, checkBufferSize);

                    _writer.Write(checkBuffer, 0, checkBufferSize);

                    //ensure that the "hidden" page in encrypted files is created correctly
                    _stream.Position = PAGE_SIZE - 1;
                    _stream.WriteByte(0);
                }
                else
                {
                    _reader.ReadRequired(checkBuffer, 0, checkBufferSize);

                    if (!checkBuffer.All(x => x == 1))
                    {
                        throw LiteException.InvalidPassword();
                    }

                    AesPreamble.CompletePage(_stream);
                }

                _stream.Position = PAGE_SIZE;
                _stream.FlushToDisk();
                // Rented buffers are not zero-initialized. Derive the blank-page
                // sentinel from exactly one zero ciphertext block.
                Array.Clear(msBuffer, 0, 16);
                using (var ms = new MemoryStream(msBuffer, 0, 16))
                using (var tempStream = new CryptoStream(ms, _decryptor, CryptoStreamMode.Read))
                {
                    tempStream.ReadRequired(_decryptedZeroes, 0, _decryptedZeroes.Length);
                }
            }
            catch
            {
                // Preserve the initialization error while releasing every resource
                // already created, including cipher handles after a bad password.
                this.DisposeResources();
                throw;
            }
            finally
            {
                if (msBuffer != null) _bufferPool.Return(msBuffer, true);
                if (checkBuffer != null) _bufferPool.Return(checkBuffer, true);
            }
        }

        /// <summary>
        /// Decrypt data from Stream
        /// </summary>
        public override int Read(byte[] array, int offset, int count)
        {
            ENSURE(this.Position % 16 == 0, "AesRead: position must be AES block aligned. Position={0}, File={1}", this.Position, _name);

            var r = _reader.ReadFully(array, offset, count);

            // checks if the first 16 bytes of the page in the original stream are zero
            // this should never happen, but if it does, return a blank page
            // the blank page will be skipped by WalIndexService.CheckpointInternal() and WalIndexService.RestoreIndex()
            if (r >= 16 && this.IsBlank(array, offset))
            {
                array.Fill(0, offset, r);
            }

            return r;
        }

        /// <summary>
        /// Encrypt data to Stream
        /// </summary>
        public override void Write(byte[] array, int offset, int count)
        {
            // WAL frames include a block-aligned checksum trailer after the page.
            ENSURE(count % 16 == 0 || count == 1, "buffer size must be AES block aligned");
            ENSURE(this.Position == HeaderPage.P_INVALID_DATAFILE_STATE || this.Position % 16 == 0, "AesWrite: position must be AES block aligned. Position={0}, File={1}", this.Position, _name);

            _writer.Write(array, offset, count);
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (!disposing || Interlocked.Exchange(ref _disposed, 1) != 0) return;

            var errors = this.DisposeResources();
            if (errors.Count > 0) throw new AggregateException(errors);
        }

        private List<Exception> DisposeResources()
        {
            var cleanup = new TryCatch();
            cleanup.Catch(() => _writer?.Dispose());
            cleanup.Catch(() => _reader?.Dispose());
            cleanup.Catch(() => _encryptor?.Dispose());
            cleanup.Catch(() => _decryptor?.Dispose());
            cleanup.Catch(() => _aes?.Dispose());
            cleanup.Catch(() => _stream.Dispose());
            return cleanup.Exceptions;
        }

        /// <summary>
        /// Get new salt for encryption
        /// </summary>
        public static byte[] NewSalt()
        {
            var salt = new byte[ENCRYPTION_SALT_SIZE];

            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            return salt;
        }

        // Encrypted page writes are complete blocks; preserve durable flush requests at the file boundary.
        internal void FlushToDisk() => _stream.FlushToDisk();

        public override void Flush()
        {
            _stream.Flush();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            long position;
            switch (origin)
            {
                case SeekOrigin.Begin: position = offset; break;
                case SeekOrigin.Current: position = checked(this.Position + offset); break;
                case SeekOrigin.End: position = checked(this.Length + offset); break;
                default: throw new ArgumentException("Invalid seek origin.", nameof(origin));
            }

            if (position < 0) throw new IOException("Cannot seek before the beginning of the encrypted data.");

            return _stream.Seek(checked(position + PAGE_SIZE), SeekOrigin.Begin) - PAGE_SIZE;
        }

        public override void SetLength(long value)
        {
            _stream.SetLength(value + PAGE_SIZE);
        }

        private unsafe bool IsBlank(byte[] array, int offset)
        {
            fixed (byte* arrayPtr = array)
            fixed (void* vPtr = _decryptedZeroes)
            {
                ulong* ptr = (ulong*)(arrayPtr + offset);
                ulong* zeroptr = (ulong*)vPtr;

                return *ptr == *zeroptr && *(ptr + 1) == *(zeroptr + 1);
            }
        }
    }
}
