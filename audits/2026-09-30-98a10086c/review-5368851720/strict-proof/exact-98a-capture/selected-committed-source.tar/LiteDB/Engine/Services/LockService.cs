using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static LiteDB.Constants;

namespace LiteDB.Engine
{
    /// <summary>
    /// Lock service are collection-based locks. Lock will support any threads reading at same time. Writing operations will be locked
    /// based on collection. Eventualy, write operation can change header page that has an exclusive locker for.
    /// [ThreadSafe]
    /// </summary>
    internal class LockService : IDisposable
    {
        private readonly EnginePragmas _pragmas;
        private volatile bool _stopping;

        private readonly TransactionGate _transaction;
        private readonly Func<object> _owner;
        private readonly ConcurrentDictionary<string, CollectionLock> _collections = new ConcurrentDictionary<string, CollectionLock>(StringComparer.OrdinalIgnoreCase);

#if DEBUG || TESTING
        internal Action BeforeTransactionAdmission { get; set; }
        internal Action BeforeExclusiveAdmission { get; set; }
        internal Action AfterExclusiveAdmission { get; set; }
#endif

        internal LockService(EnginePragmas pragmas, Func<object> owner = null)
        {
            _pragmas = pragmas;
            _owner = owner;
            _transaction = new TransactionGate(owner);
        }

        /// <summary>
        /// Return if current thread have open transaction
        /// </summary>
        public bool IsInTransaction => _transaction.IsReadLockHeld || _transaction.IsWriteLockHeld;

        /// <summary>
        /// Return how many transactions are opened
        /// </summary>
        public int TransactionsCount => _transaction.CurrentReadCount;

        /// <summary>
        /// Enter transaction read lock - should be called just before enter a new transaction
        /// </summary>
        public void EnterTransaction() => EnterTransaction(_owner?.Invoke() ?? Thread.CurrentThread);

        internal void EnterTransaction(object owner)
        {
#if DEBUG || TESTING
            BeforeTransactionAdmission?.Invoke();
#endif
            // if current thread already in exclusive mode, just exit
            if (_transaction.IsWriteLockHeld) return;

            try
            {
                if (_transaction.TryEnterReadLock(_pragmas.Timeout, owner) == false)
                    throw LiteException.LockTimeout("transaction", _pragmas.Timeout);
            }
            catch (ObjectDisposedException)
            {
                // Rebuild can dispose the old admission gate while a new operation
                // is queued behind its exclusive lease. Expose the engine contract,
                // not the implementation detail of the retired gate.
                throw LiteException.EngineDisposed();
            }
        }

#if DEBUG || TESTING
        internal Action AfterTransactionRelease;
#endif

        /// <summary>
        /// Exit transaction read lock
        /// </summary>
        public void ExitTransaction(object owner)
        {
            _transaction.ExitReadLock(owner);
#if DEBUG || TESTING
            AfterTransactionRelease?.Invoke();
#endif
        }

        /// <summary>
        /// Enter collection write lock mode (only 1 collection per time can have this lock)
        /// </summary>
        public void EnterLock(string collectionName, object owner)
        {
            ENSURE(_transaction.IsReadLockHeld || _transaction.IsWriteLockHeld, "Use EnterTransaction() before EnterLock(name)");

            // get collection lock from dictionary (or create new if it does not exist)
            var collection = _collections.GetOrAdd(collectionName, (s) => new CollectionLock());

            if (_stopping) throw LiteException.EngineDisposed();
            if (collection.TryEnter(owner, _pragmas.Timeout) == false) throw LiteException.LockTimeout("write", collectionName, _pragmas.Timeout);
        }

        /// <summary>
        /// Exit collection in reserved lock
        /// </summary>
        public void ExitLock(string collectionName, object owner)
        {
            if (_collections.TryGetValue(collectionName, out var collection) == false) throw LiteException.CollectionLockerNotFound(collectionName);

            collection.Exit(owner);
        }

        /// <summary>
        /// Enter all database in exclusive lock. Wait for all transactions finish. In exclusive mode no one can enter in new transaction (for read/write)
        /// If current thread already in exclusive mode, returns false
        /// </summary>
        public bool EnterExclusive()
        {
#if DEBUG || TESTING
            BeforeExclusiveAdmission?.Invoke();
#endif
            // if current thread already in exclusive mode
            if (_transaction.IsWriteLockHeld) return false;

            // wait finish all transactions before enter in reserved mode
            if (_transaction.TryEnterWriteLock(_pragmas.Timeout) == false) throw LiteException.LockTimeout("exclusive", _pragmas.Timeout);

#if DEBUG || TESTING
            AfterExclusiveAdmission?.Invoke();
#endif
            return true;
        }

        /// <summary>
        /// Try exclusive mode, optionally queueing briefly behind readers. Timeout returns false.
        /// If mustExit returns true, must call ExitExclusive after use
        /// </summary>
        public bool TryEnterExclusive(out bool mustExit, bool waitForReaders = false, int milliseconds = 10)
        {
            // if already in exclusive mode return true but "enter" indicator must be false (do not exit)
            if (_transaction.IsWriteLockHeld)
            {
                mustExit = false;
                return true;
            }

            // if there is any open transaction, exit with false
            if (_transaction.IsReadLockHeld || (!waitForReaders && _transaction.CurrentReadCount > 0))
            {
                mustExit = false;
                return false;
            }

            // try enter in exclusive mode - but if not possible, just exit with false
            if (_transaction.TryEnterWriteLock(milliseconds) == false)
            {
                mustExit = false;
                return false;
            }

            ENSURE(_transaction.RecursiveReadCount == 0, "must have no other transaction here");

            // now, current thread are in exclusive mode (must run ExitExclusive to exit)
            mustExit = true;
            return true;
        }

        /// <summary>
        /// Exit exclusive lock
        /// </summary>
        public void ExitExclusive()
        {
            _transaction.ExitWriteLock();
        }

        // Wake operations waiting for an idle transaction owner before close drains
        // active operations. Releasing pages/transactions still happens after the drain.
        internal void StopWaiters()
        {
            _stopping = true;
            foreach (var collection in _collections.Values) collection.StopWaiters();
        }

        public void Dispose()
        {
            try
            {
                _transaction.Dispose();
            }
            catch (SynchronizationLockException)
            {
            }
        }
    }
}
