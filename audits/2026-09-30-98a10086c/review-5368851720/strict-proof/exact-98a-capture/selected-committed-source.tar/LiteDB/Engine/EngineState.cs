using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using static LiteDB.Constants;

namespace LiteDB.Engine
{
    internal class EngineState
    {
        public volatile bool Disposed = false;
        private Exception _exception;
        private readonly LiteEngine _engine; // can be null for unit tests
        private readonly EngineSettings _settings;
        // Readers already own a transaction, even when advanced/disposed on a new thread.
        internal OperationLifetime.Lease EnterOperation() => _engine?.EnterOperation(continuation: true) ?? default;
        internal EngineContext Context => _engine?.CurrentContext;

#if DEBUG || TESTING
        public Action<long, FileOrigin> BeforePageRead;
        public Action<string> CheckpointStage;
        public Action<PageBuffer> SimulateDiskReadFail = null;
        public Action<PageBuffer> SimulateDiskWriteFail = null;
        internal Action<PageBuffer> SimulateDataWriteFail;
        internal static Action<string> SimulateProcessCrash;
        internal static Action<long> ObserveSortSpill;
        internal static Action<PageBuffer> ObserveCacheEviction;
#endif

        public EngineState(LiteEngine engine, EngineSettings settings)
        {
            _engine = engine;
            _settings = settings;
#if DEBUG || TESTING
            CheckpointStage = settings?.CheckpointStage;
#endif
        }

        internal bool IsUnavailable => Disposed || Volatile.Read(ref _exception) != null;
        internal bool IsPublishedFailure(Exception error) => ReferenceEquals(Volatile.Read(ref _exception), error);

        public void Validate()
        {
            var failure = Volatile.Read(ref _exception);
            if (failure != null) throw failure;
            if (this.Disposed) throw Volatile.Read(ref _exception) ?? LiteException.EngineDisposed();
        }

        public bool Handle(Exception ex)
        {
            LOG(ex.Message, "ERROR");

            if ((ex is IOException && !(ex is ReadOnlyContextException)) ||
                (ex is LiteException lex && (lex.ErrorCode == LiteException.INVALID_DATAFILE_STATE || lex.ErrorCode == LiteException.CHECKSUM_MISMATCH)))
            {
                this.Stop(ex);

                return false;
            }

            return true;
        }

#if DEBUG || TESTING
        internal void CrashPoint(string phase)
        {
            SimulateProcessCrash?.Invoke(phase);
        }
#endif

        internal void Stop(Exception ex)
        {
            this.CompleteStop(ex, this.BeginStop(ex));
        }

        /// <summary>
        /// Make the engine immediately unusable without running cleanup that can
        /// acquire unrelated locks. The caller later owns <see cref="CompleteStop"/>.
        /// </summary>
        internal bool BeginStop(Exception ex)
        {
            // A completion that failed because the engine was already closed is not a new fatal cause.
            if (this.Disposed) return false;

            // A later completion/cleanup race must not replace the causal failure.
            return Interlocked.CompareExchange(ref _exception, ClosedEngineFailure(ex), null) == null;
        }

        /// <summary>
        /// Finish teardown for the caller that first published a fatal failure.
        /// </summary>
        internal void CompleteStop(Exception ex, bool ownsFailure)
        {
            if (!ownsFailure) return;
            if (_engine != null) _engine.StopAfterOperations(ex, this);
            else this.Disposed = true;
        }

        /// <summary>
        /// What later calls on the closed instance throw: the cause alone reads as if it were still happening.
        /// INVALID_DATAFILE_STATE stays as is, callers match on its error code.
        /// </summary>
        private static Exception ClosedEngineFailure(Exception ex)
        {
            const string RECOVERY = "Dispose and reopen the database before retrying. ";

            if (ex is IOException) return new IOException("Engine closed after an I/O failure. " + RECOVERY + ex.Message, ex);
            if (ex is LiteException lex && (lex.ErrorCode == LiteException.INVALID_DATAFILE_STATE || lex.ErrorCode == LiteException.CHECKSUM_MISMATCH)) return ex;

            return new LiteException(LiteException.ENGINE_DISPOSED, ex, "Engine closed after a transaction completion failure. " + RECOVERY + "{0}", ex.Message);
        }

        public BsonValue ReadTransform(string collection, BsonValue value)
        {
            var transform = _engine == null ? _settings?.ReadTransform : _engine.CurrentContext.Policy.ReadTransform;
            if (transform is null) return value;

            var result = transform(collection, value);
            if (value is BsonDocument source && result is BsonDocument target)
                target.IsProjectionValue = source.IsProjectionValue;
            return result;
        }
    }
}
