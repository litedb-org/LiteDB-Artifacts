using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading;
using static LiteDB.Constants;

namespace LiteDB.Engine
{
    /// <summary>
    /// Internal class to read all datafile documents - use only Stream - no cache system. Read log file (read commited transtraction)
    /// </summary>
    internal partial class FileReaderV8 : IFileReader
    {
        private struct PageInfo
        {
            public uint PageID;
            public FileOrigin Origin;
            public PageType PageType;
            public long Position;
            public uint ColID;
        }

        private readonly Dictionary<string, uint> _collections = new Dictionary<string, uint>();
        private readonly Dictionary<string, List<IndexInfo>> _indexes = new Dictionary<string, List<IndexInfo>>();
        private readonly Dictionary<uint, List<uint>> _collectionsDataPages = new Dictionary<uint, List<uint>>();
        private readonly Dictionary<string, BsonValue> _pragmas = new Dictionary<string, BsonValue>
        {
            [Pragmas.USER_VERSION] = 0,
            [Pragmas.CHECKPOINT] = 1000,
            [Pragmas.TIMEOUT] = 60,
            [Pragmas.UTC_DATE] = true,
            [Pragmas.LIMIT_SIZE] = long.MaxValue,
        };

        private Stream _dataStream;
        private Stream _logStream;
        private readonly IDictionary<uint, long> _logIndexMap = new Dictionary<uint, long>();
        private uint _maxPageID; // a file-length based max pageID to be tested

        private bool _disposed;

        private readonly EngineSettings _settings;
        private readonly IList<FileReaderError> _errors;

        public FileReaderV8(EngineSettings settings, IList<FileReaderError> errors)
        {
            _settings = settings;
            _errors = errors;
        }

        /// <summary>
        /// Open data file and log file, read header and collection pages
        /// </summary>
        public void Open()
        {
            try
            {
                var dataFactory = _settings.CreateDataFactory();
                var logFactory = _settings.CreateLogFactory();

                // Floor each source independently so partial tails cannot form a page.
                _maxPageID = (uint)(dataFactory.GetLength() / PAGE_SIZE + logFactory.GetLength() / PAGE_SIZE);

                _dataStream = dataFactory.GetStream(true, false);
                if (logFactory.Exists()) _logStream = logFactory.GetStream(false, true);

                this.InitializeChecksums();
                _dataStream.Position = 0;

                if (_logStream != null)
                {
                    _logStream = new ChecksummedWalStream(_logStream, _checksums);
                    if (_checksums.Enabled)
                    {
                        this.LoadChecksummedIndexMap();
                    }
                    else this.LoadIndexMap();
                }

                this.LoadPragmas();

                this.LoadDataPages();

                this.LoadCollections();

                this.LoadIndexes();
            }
            catch (Exception ex)
            {
                this.HandleError(ex, new PageInfo());
            }
        }

        /// <summary>
        /// Read all pragma values
        /// </summary>
        public IDictionary<string, BsonValue> GetPragmas() => _pragmas;

        /// <summary>
        /// Read all collection based on header page
        /// </summary>
        public IEnumerable<string> GetCollections() => _collections.Keys;

        /// <summary>
        /// Read all indexes from all collection pages (except _id index)
        /// </summary>
        public IEnumerable<IndexInfo> GetIndexes(string collection) => _indexes.ContainsKey(collection) ? _indexes[collection] : new List<IndexInfo>();

        /// <summary>
        /// Read all documents from current collection with NO index use - read direct from free lists
        /// There is no document order
        /// </summary>
        /// <summary>
        /// Load all pragmas from header page
        /// </summary>
        private void LoadPragmas()
        {
            var result = this.ReadPage(0, out var pageInfo);

            if (result.Ok)
            {
                var buffer = result.Value.Buffer;

                _pragmas[Pragmas.USER_VERSION] = buffer.ReadInt32(EnginePragmas.P_USER_VERSION);
                _pragmas[Pragmas.CHECKPOINT] = buffer.ReadInt32(EnginePragmas.P_CHECKPOINT);
                _pragmas[Pragmas.TIMEOUT] = buffer.ReadInt32(EnginePragmas.P_TIMEOUT);
                _pragmas[Pragmas.UTC_DATE] = buffer.ReadBool(EnginePragmas.P_UTC_DATE);
                _pragmas[Pragmas.LIMIT_SIZE] = buffer.ReadInt64(EnginePragmas.P_LIMIT_SIZE);
            }
            else
            {
                this.HandleError(result.Exception, pageInfo);
            }
        }

        /// <summary>
        /// Read all file (and log) to find all data pages (and store groupby colPageID)
        /// </summary>
        private void LoadDataPages()
        {
            var header = this.ReadPage(0, out var pageInfo).GetValue();
            var lastPageID = header.Buffer.ReadUInt32(HeaderPage.P_LAST_PAGE_ID); //TOFO: tentar não usar esse valor como referencia (varrer tudo)

            ENSURE(lastPageID <= _maxPageID, "LastPageID {0} should be less or equals to maxPageID {1}", lastPageID, _maxPageID);

            for (uint i = 0; i <= lastPageID; i++)
            {
                var result = this.ReadPage(i, out pageInfo);

                if (result.Ok)
                {
                    var page = result.Value;

                    if (page.PageType == PageType.Data)
                    {
                        if (_collectionsDataPages.TryGetValue(page.ColID, out var list))
                        {
                            list.Add(page.PageID);
                        }
                        else
                        {
                            _collectionsDataPages[page.ColID] = new List<uint> { page.PageID };
                        }
                    }
                }
                else
                {
                    this.HandleError(result.Exception, pageInfo);
                }
            }
        }

        /// <summary>
        /// Load all collections from header OR via all data-pages ColID
        /// </summary>
        private void LoadCollections()
        {
            var header = this.ReadPage(0, out var pageInfo).GetValue();

            var area = header.Buffer.Slice(HeaderPage.P_COLLECTIONS, HeaderPage.COLLECTIONS_SIZE);

            using (var r = new BufferReader(new[] { area }, false) { AllowZeroLengthDocument = true })
            {
                var result = r.ReadDocument();

                // can't be fully read
                var collections = result.Value;

                foreach (var key in collections.Keys)
                {
                    // collections.key = collection name
                    // collections.value = collection PageID
                    var colID = collections[key];

                    if (colID.IsNumber == false)
                    {
                        this.HandleError($"ColID expect a number but get {colID}", pageInfo);
                    }
                    else
                    {
                        _collections[key] = (uint)collections[key].AsInt32;
                    }
                }

                if (result.Fail)
                {
                    this.HandleError(result.Exception, pageInfo);
                }
            }

            // for each collection loaded by datapages, check if exists in _collections
            foreach(var collection in _collectionsDataPages)
            {
                if (!_collections.ContainsValue(collection.Key))
                {
                    _collections["col_" + collection.Key] = collection.Key;
                }
            }
        }

        /// <summary>
        /// Load all indexes for all collections
        /// </summary>
        private void LoadIndexes()
        {
            foreach (var collection in _collections)
            {
                var result = this.ReadPage(collection.Value, out var pageInfo);

                if (result.Fail)
                {
                    this.HandleError(result.Exception, pageInfo);
                    continue;
                }

                try
                {
                    var page = result.Value;
                    var collectionPage = new CollectionPage(page.Buffer);

                    foreach (var index in collectionPage.GetCollectionIndexes())
                    {
                        if (index.Name == "_id") continue;

                        var info = new IndexInfo
                        {
                            Collection = collection.Key,
                            Name = index.Name,
                            Expression = index.Expression,
                            Unique = index.Unique,
                            IndexType = index.IndexType,
                            VectorMetadata = index.IndexType == 1 ? collectionPage.GetVectorIndexMetadata(index.Name) : null
                        };

                        if (_indexes.TryGetValue(collection.Key, out var indexInfos))
                        {
                            indexInfos.Add(info);
                        }
                        else
                        {
                            _indexes[collection.Key] = new List<IndexInfo> { info };
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.HandleError(ex, pageInfo);
                }
            }
        }

        /// <summary>
        /// Check for the shared v8/v9/v10 page layout (vectors and compact document capabilities)
        /// </summary>
        public static bool IsVersion(byte[] buffer)
        {
            var header = Encoding.UTF8.GetString(buffer, HeaderPage.P_HEADER_INFO, HeaderPage.HEADER_INFO.Length);
            var version = buffer[HeaderPage.P_FILE_VERSION];

            // buffer[0] = 1 when datafile is encrypted (this feature was added in v8 only)
            // all other version has this buffer[0] = 0

            return (header == HeaderPage.HEADER_INFO && (version == HeaderPage.FILE_VERSION || version == HeaderPage.VECTOR_FILE_VERSION || version == HeaderPage.MVCC_FILE_VERSION || version == HeaderPage.COMPACT_FILE_VERSION || version == HeaderPage.INDEX_FILE_VERSION || version == HeaderPage.CHECKSUM_FILE_VERSION)) ||
                buffer[0] == 1;
        }

        /// <summary>
        /// Read page from data/log stream (checks in logIndexMap file/position). Capture any exception here, but don't call HandleError
        /// </summary>
        private Result<BasePage> ReadPage(uint pageID, out PageInfo pageInfo)
        {
            pageInfo = new PageInfo { PageID = pageID };

            try
            {
                ENSURE(pageID <= _maxPageID, "PageID: {0} should be less then or equals to maxPageID: {1}", pageID, _maxPageID);

                var pageBuffer = new PageBuffer(new byte[PAGE_SIZE], 0, PAGE_SIZE);
                Stream stream;
                int read;

                // get data from log file or original file
                if (_logIndexMap.TryGetValue(pageID, out pageInfo.Position))
                {
                    pageInfo.Origin = FileOrigin.Log;
                    stream = _logStream;
                }
                else
                {
                    pageInfo.Origin = FileOrigin.Data;
                    pageInfo.Position = BasePage.GetPagePosition(pageID);

                    stream = _dataStream;
                }

                stream.Position = pageInfo.Position;

                read = stream.ReadFully(pageBuffer.Array, pageBuffer.Offset, pageBuffer.Count);
                this.ReadRecoveredHeader(pageBuffer, pageID, pageInfo.Origin);

                ENSURE(read == PAGE_SIZE, "Page position {0} read only than {1} bytes (instead {2})", stream.Position, read, PAGE_SIZE);

                if (_checksums.Enabled && pageInfo.Origin == FileOrigin.Data)
                    _dataChecksums.Validate(pageBuffer, pageInfo.Position);
                var page = new BasePage(pageBuffer);

                pageInfo.ColID = page.ColID;

                ENSURE(page.PageID == pageID, "Expect read pageID: {0} but header contains pageID: {1}", pageID, page.PageID);

                return page;
            }
            catch (Exception ex)
            {
                return new Result<BasePage>(null, ex);
            }
        }

        /// <summary>
        /// Handle any error avoiding throw exceptions during process. If exception must stop process (ioexceptions), throw exception
        /// Add errors to log and continue reading data file
        /// </summary>
        private void HandleError(Exception ex, PageInfo pageInfo)
        {
            var collection = _collections.FirstOrDefault(x => x.Value == pageInfo.ColID).Key;

            _errors.Add(new FileReaderError
            {
                Position = pageInfo.Position,
                Origin = pageInfo.Origin,
                PageID = pageInfo.PageID,
                PageType = pageInfo.PageType,
                Collection = collection,
                Message = ex.Message,
                Exception = ex,
            });

            if (ex is IOException)
            {
                // Código de erros HResult do IOException
                // https://learn.microsoft.com/pt-br/windows/win32/debug/system-error-codes--0-499-

                ExceptionDispatchInfo.Capture(ex).Throw();
            }
        }

        private void HandleError(string message, PageInfo pageInfo) => this.HandleError(new Exception(message), pageInfo);

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                _dataStream?.Dispose();
                _logStream?.Dispose();
                _disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
