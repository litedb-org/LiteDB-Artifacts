using System;
using System.Runtime.ExceptionServices;
using System.Threading;

namespace LiteDB.Client.Shared
{
    /// <summary>
    /// A connection's ownership of its named mutex, independent of the calling thread.
    /// A Mutex can only be released by the thread that acquired it, so a reader or
    /// connection disposed on another thread (an await continuation, a consumer
    /// thread) used to throw and leave the mutex held until the acquiring thread
    /// exited, blocking every process. Here a holder thread acquires and releases the
    /// OS mutex, and one logical owner thread holds it recursively in this process.
    /// Any thread may end the ownership. When the owner thread exits while holding
    /// it, the holder closes the connection's state and releases the mutex, as the
    /// OS would have abandoned it; the connection reports the exit on its next call.
    /// A scoped ownership, which its caller ends on the same thread before returning,
    /// takes the OS mutex directly on that thread instead: nothing but that thread can
    /// end it, so it needs no holder and saves two thread handoffs per operation.
    /// </summary>
    internal sealed class SharedMutexOwner
    {
        private static readonly TimeSpan Poll = TimeSpan.FromMilliseconds(20);
        // A holder that owns nothing exits after this long, so an undisposed
        // connection does not keep a thread (and itself) alive forever.
        private static readonly TimeSpan HolderIdle = TimeSpan.FromSeconds(1);
        private const int SpinCount = 1000;

        private enum Command { None, Acquire, TryAcquire, Release, ReleaseAndOpenGate, ReleaseExitedOwner }

        private readonly Mutex _mutex;
        private readonly SharedMutexScope _scope;
        private readonly SharedMutexTurnstile _turnstile;
        private readonly Action _ownerExited;
        private readonly SemaphoreSlim _gate = new SemaphoreSlim(1, 1);
        private readonly object _send = new object();
        private readonly object _sync = new object();
        // The caller spins before blocking: it stays on its core while the holder
        // takes or releases the OS mutex, which takes microseconds. The holder waits
        // between operations of unknown length, so it only spins briefly.
        private readonly ManualResetEventSlim _posted = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _done = new ManualResetEventSlim(false, SpinCount);
        // Reset while a posted release of this connection is in flight. Until the
        // holder completes it, the gate stays closed and the OS mutex held, although
        // nobody owns the connection any more.
        private readonly ManualResetEventSlim _released = new ManualResetEventSlim(true, SpinCount);
        private Thread _holder;
        private Command _command;
        private CancellationToken _commandClosing;
        private bool _acquired;
        private bool _abandoned;
        private Exception _error;
        private bool _held;
        private Thread _owner;
        private int _recursion;
        private int _generation;

        public SharedMutexOwner(Mutex mutex, SharedMutexTurnstile turnstile, Action ownerExited)
        {
            _mutex = mutex;
            _scope = new SharedMutexScope(mutex, turnstile);
            _turnstile = turnstile;
            _ownerExited = ownerExited;
        }

        public bool OwnsDirectly
        {
            get { lock (_sync) return _owner != null && ReferenceEquals(_scope.Owner, Thread.CurrentThread); }
        }

        private bool TakeDirect(bool block, out bool abandoned, CancellationToken closing = default)
        {
            try
            {
                if (!_scope.Take(block, out abandoned, closing)) { _gate.Release(); return false; }
                lock (_sync)
                {
                    _owner = Thread.CurrentThread;
                    _scope.Owner = _owner;
                    _recursion = 1;
                }
                return true;
            }
            catch { _gate.Release(); throw; }
        }

        public Mutex Mutex => _mutex;

#if DEBUG || TESTING
        /// <summary>Runs on the holder before it performs a release posted by <see cref="Exit"/>.</summary>
        internal Action BeforePostedRelease { get; set; }

        /// <summary>Runs on a caller after it published a command, before it signals the holder.</summary>
        internal Action BeforeNotify { get; set; }

        /// <summary>Holder wake-ups by a signal that carried no command.</summary>
        internal int EmptySignaledWakes;

        /// <summary>Runs on the holder after it found the owner thread exited, before it cleans up.</summary>
        internal Action BeforeOwnerExitedCleanup { get; set; }
#endif

#if DEBUG || TESTING
        /// <summary>Test hook: whether a holder thread was started and has not exited.</summary>
        internal bool HasHolderThread
        {
            get { lock (_sync) return _holder != null; }
        }
#endif

        /// <summary>Changes whenever ownership ends, so a stale release is ignored.</summary>
        public int Generation { get { lock (_sync) return _generation; } }

        public bool IsOwnedByCurrentThread
        {
            get { lock (_sync) return ReferenceEquals(_owner, Thread.CurrentThread); }
        }

        /// <summary>
        /// Acquire, or enter recursively on the owner thread. Returns true when the
        /// OS reported the mutex abandoned by another process.
        /// </summary>
        public bool Enter(bool scoped = false, CancellationToken closing = default)
        {
            if (this.TryRecurse()) return false;
            while (!_gate.Wait(Poll, closing)) this.ReleaseIfOwnerExited();
            bool abandoned;
            if (scoped && SharedMutexScope.CanEnter) this.TakeDirect(block: true, out abandoned, closing);
            else this.TakeGate(Command.Acquire, out abandoned, closing);
            return abandoned;
        }

        /// <summary>
        /// Enter without waiting for another thread or process. Fails when a live
        /// thread of this connection, or another process, owns the mutex.
        /// </summary>
        public bool TryEnter(out bool abandoned, bool scoped = false)
        {
            abandoned = false;
            if (this.TryRecurse()) return true;
            // This connection's own release in flight is not another owner.
            this.WaitForRelease();
            if (!_gate.Wait(0))
            {
                this.ReleaseIfOwnerExited();
                // The poll may already have claimed the exited owner and cleared
                // its identity. Its cleanup is our own release, not a foreign owner.
                this.WaitForRelease();
                if (!_gate.Wait(0)) return false;
            }
            return scoped && SharedMutexScope.CanEnter
                ? this.TakeDirect(block: false, out abandoned)
                : this.TakeGate(Command.TryAcquire, out abandoned);
        }

        /// <summary>
        /// End one recursion on its caller. Cross-thread readers supply their captured
        /// <paramref name="generation"/>; an already-ended ownership is ignored.
        /// </summary>
        public void Exit(int generation = -1)
        {
            Thread direct;
            lock (_sync)
            {
                direct = _scope.Owner;
                // Dispose can end an acquisition before its caller is admitted. Its
                // later error cleanup must not release a subsequent thread's ownership.
                // Cross-thread readers always supply their captured generation.
                if (generation < 0 && _owner != null && !ReferenceEquals(_owner, Thread.CurrentThread)) return;
                if (_owner == null || (generation >= 0 && generation != _generation))
                {
                    // ReleaseAll ended a scoped ownership while its thread still ran the
                    // operation: that thread alone can release the OS mutex, when it ends.
                    if (_owner != null || !ReferenceEquals(direct, Thread.CurrentThread)) return;
                }
                else
                {
                    if (_recursion > 1)
                    {
                        _recursion--;
                        return;
                    }
                    // A scoped ownership that escaped its call is a caller bug. Only its
                    // thread can release the mutex: fail loudly, and leave the ownership
                    // intact for that thread, instead of leaving the mutex held silently.
                    if (direct != null && !ReferenceEquals(direct, Thread.CurrentThread))
                        throw new InvalidOperationException("A scoped shared-mode mutex ownership was ended on another thread.");
                    _recursion = 0;
                    _owner = null;
                    _generation++;
                    if (direct == null) _released.Reset();
                }
                _scope.Owner = null;
            }
            if (direct != null)
            {
                try { _scope.Release(); }
                finally { _gate.Release(); }
                return;
            }
            // The caller need not wait: the holder releases the OS mutex and only then
            // opens the gate, so the next owner in this process still waits for it.
            this.Post(Command.ReleaseAndOpenGate);
        }

        /// <summary>
        /// End any ownership, whichever thread owns it, as disposing the connection
        /// does. Later releases of that ownership are ignored. Never throws.
        /// </summary>
        public void ReleaseAll()
        {
            lock (_sync)
            {
                if (_owner == null) return;
                _owner = null;
                _recursion = 0;
                _generation++;
                // A scoped ownership's thread is still inside its operation. It releases
                // the OS mutex and the gate when that operation ends (see Exit).
                if (_scope.Owner != null) return;
            }
            try { this.Send(Command.Release); }
            catch (Exception) { /* Disposal must not fail; process exit releases the mutex. */ }
            finally { _gate.Release(); }
        }

        /// <summary>
        /// Wait until a release posted by <see cref="Exit"/> completed, so that this
        /// connection holds neither the gate nor the OS mutex on its own account.
        /// The holder completes it without waiting for anything else.
        /// </summary>
        public void WaitForRelease() => _released.Wait();

        private bool TryRecurse()
        {
            lock (_sync)
            {
                if (!ReferenceEquals(_owner, Thread.CurrentThread)) return false;
                _recursion++;
                return true;
            }
        }

        /// <summary>Acquire the OS mutex for the calling thread, which holds the gate.</summary>
        private bool TakeGate(Command command, out bool abandoned, CancellationToken closing = default)
        {
            abandoned = false;
            try
            {
                if (!this.Send(command, closing)) { _gate.Release(); return false; }
                abandoned = _abandoned;
                lock (_sync)
                {
                    _owner = Thread.CurrentThread;
                    _recursion = 1;
                }
                return true;
            }
            catch
            {
                _gate.Release();
                throw;
            }
        }

        /// <summary>
        /// If the owner thread exited while owning the mutex, have the holder close
        /// the connection's state and release it. Returns true when it did.
        /// </summary>
        private bool ReleaseIfOwnerExited()
        {
            Thread owner;
            var direct = false;
            lock (_sync)
            {
                owner = _owner ?? _scope.Owner;
                if (owner == null || owner.IsAlive) return false;
                if (ReferenceEquals(_scope.Owner, owner))
                {
                    // A scoped owner cannot leave its call without unwinding; if its thread
                    // died anyway, the OS abandoned its mutex and the next wait reports it.
                    direct = true;
                    _owner = null;
                    _scope.Owner = null;
                    _recursion = 0;
                    _generation++;
                }
            }
            if (direct)
            {
                try { _ownerExited(); }
                catch (Exception) { /* The next open recovers. */ }
                _gate.Release();
                return true;
            }
            this.Send(Command.ReleaseExitedOwner);
            return true;
        }

        /// <summary>Queue a command whose completion opens the gate; nobody waits for it.</summary>
        private void Post(Command command)
        {
            lock (_send)
            {
                lock (_sync)
                {
                    this.EnsureHolder();
                    _command = command;
                    // Signal under the same lock the holder takes to read and reset:
                    // it must never consume a command before that command's signal.
#if DEBUG || TESTING
                    this.BeforeNotify?.Invoke();
#endif
                    _posted.Set();
                }
            }
        }

        private void EnsureHolder()
        {
            if (_holder != null && _holder.IsAlive) return;
            _holder = new Thread(this.Run) { IsBackground = true, Name = "LiteDB shared mutex owner" };
            _holder.Start();
        }

        /// <summary>
        /// Run a command on the holder thread and wait for it. Only the gate's holder,
        /// or a caller that finds the gate's owner exited, sends; a posted release
        /// opens the gate only after it completed, so one command is pending at most.
        /// </summary>
        private bool Send(Command command, CancellationToken closing = default)
        {
            lock (_send)
            {
                lock (_sync)
                {
                    this.EnsureHolder();
                    _command = command;
                    _commandClosing = closing;
                    _done.Reset();
#if DEBUG || TESTING
                    this.BeforeNotify?.Invoke();
#endif
                    _posted.Set();
                }
                _done.Wait();
                lock (_sync)
                {
                    var error = _error;
                    _error = null;
                    if (error != null) ExceptionDispatchInfo.Capture(error).Throw();
                    return _acquired;
                }
            }
        }

        private void Run()
        {
            var idleSince = DateTime.UtcNow;
            while (true)
            {
                var signaled = _posted.Wait(Poll);
                Command command;
                var ownerExited = false;
                lock (_sync)
                {
                    command = _command;
                    // Publication and signal happen under this lock, so a signal without a
                    // command is stale. Reset it either way, or the next wait would return
                    // immediately and the holder would spin.
                    _posted.Reset();
#if DEBUG || TESTING
                    if (signaled && command == Command.None) Interlocked.Increment(ref EmptySignaledWakes);
#endif
                    if (command == Command.None && _held && _owner != null && !_owner.IsAlive) ownerExited = true;
                    else if (command == Command.None && !_held && DateTime.UtcNow - idleSince > HolderIdle)
                    {
                        _holder = null;
                        return;
                    }
                }

                if (command == Command.None)
                {
                    // Nobody waits for this; a caller's command is taken next round.
                    if (ownerExited)
                    {
                        try { this.ReleaseExitedOwner(); }
                        catch (Exception) { /* Retried by the next caller or poll. */ }
                    }
                    continue;
                }

                var acquired = false;
                var abandoned = false;
                var posted = false;
                Exception error = null;
                try
                {
                    switch (command)
                    {
                        case Command.Acquire: acquired = this.WaitMutex(block: true, out abandoned); break;
                        case Command.TryAcquire: acquired = this.WaitMutex(block: false, out abandoned); break;
                        case Command.Release: this.ReleaseMutex(); break;
                        case Command.ReleaseAndOpenGate:
#if DEBUG || TESTING
                            this.BeforePostedRelease?.Invoke();
#endif
                            this.ReleaseMutex();
                            break;
                        case Command.ReleaseExitedOwner: this.ReleaseExitedOwner(); break;
                    }
                }
                catch (Exception ex) { error = ex; }

                lock (_sync)
                {
                    if (command == Command.Acquire || command == Command.TryAcquire) _held = acquired;
                    idleSince = DateTime.UtcNow;
                    _acquired = acquired;
                    _abandoned = abandoned;
                    _command = Command.None;
                    _commandClosing = default;
                    if (command == Command.ReleaseAndOpenGate) posted = true;
                    else _error = error;
                }
                if (posted)
                {
                    lock (_sync) { _gate.Release(); _released.Set(); }
                }
                else _done.Set();
            }
        }

        private bool WaitMutex(bool block, out bool abandoned)
        {
            abandoned = false;
            try
            {
                // Stay queued at the turnstile throughout the cancellable native wait:
                // a party that just released cannot barge ahead of this connection.
                if (!block) return _turnstile.TryWait(_mutex);
                _turnstile.Wait(_mutex, _commandClosing);
                return true;
            }
            catch (AbandonedMutexException)
            {
                abandoned = true;
                return true;
            }
        }

        private void ReleaseMutex()
        {
            lock (_sync)
            {
                if (!_held) return;
                _held = false;
            }
            _mutex.ReleaseMutex();
        }

        /// <summary>On the holder: the owner thread exited while owning the mutex.</summary>
        private void ReleaseExitedOwner()
        {
            lock (_sync)
            {
                if (!_held || _owner == null || _owner.IsAlive) return;
                // Claim the ending ownership before cleanup. A release of it on another
                // thread (a reader disposed with its generation) then finds it ended; else
                // both would release the mutex and reopen the gate, and the second gate
                // release throws on this thread. The mutex and the gate stay held until
                // the cleanup below finishes, so nobody enters meanwhile.
                _released.Reset();
                _owner = null;
                _recursion = 0;
                _generation++;
            }
#if DEBUG || TESTING
            this.BeforeOwnerExitedCleanup?.Invoke();
#endif
            try { _ownerExited(); }
            catch (Exception) { /* The next open recovers; the mutex must still be released. */ }
            this.ReleaseMutex();
            lock (_sync) { _gate.Release(); _released.Set(); }
        }
    }
}
