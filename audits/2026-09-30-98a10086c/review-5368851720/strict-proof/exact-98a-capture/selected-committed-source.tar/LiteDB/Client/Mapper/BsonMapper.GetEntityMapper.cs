﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace LiteDB;

public partial class BsonMapper
{
    /// <summary>
    /// Mapping cache between Class/BsonDocument
    /// </summary>
    private readonly ConcurrentDictionary<Type, EntityMapper> _entities = new();

    /// <summary>
    /// Get property mapper between typed .NET class and BsonDocument - Cache results
    /// </summary>
    internal EntityMapper GetEntityMapper(Type type)
    {
        if (_entities.TryGetValue(type, out EntityMapper mapper))
        {
            return mapper;
        }

        var cts = new CancellationTokenSource();
        var published = false;
        try
        {
            // We need to add the empty shell, because ``BuildEntityMapper`` may use this method recursively
            var newMapper = new EntityMapper(type, cts.Token);
            mapper = _entities.GetOrAdd(type, newMapper);
            if (ReferenceEquals(mapper, newMapper))
            {
                published = true;
                try
                {
                    this.BuildEntityMapper(mapper);
                    mapper.IsInitialized = true;
                    published = true;
                }
                catch (Exception ex)
                {
                    _entities.TryRemove(type, out _);
                    throw new LiteException(LiteException.MAPPING_ERROR, ex,
                        "Error in '{0}' mapping: {1}", type.FullName, ex.Message);
                }
            }
        }
        finally
        {
            // Allow the Mapper to be used for de-/serialization
            cts.Cancel();
            // A published mapper retains this token. Disposing its source can race
            // with another caller acquiring the token's wait handle.
            if (!published) cts.Dispose();
        }

        return mapper;
    }

    /// <summary>
    /// Use this method to override how your class can be, by default, mapped from entity to Bson document.
    /// Returns an EntityMapper from each requested Type
    /// </summary>
    protected void BuildEntityMapper(EntityMapper mapper)
    {
        var idAttr = typeof(BsonIdAttribute);
        var ignoreAttr = typeof(BsonIgnoreAttribute);
        var fieldAttr = typeof(BsonFieldAttribute);
        var dbrefAttr = typeof(BsonRefAttribute);

        var members = this.GetTypeMembers(mapper.ForType);
        var id = this.GetIdMember(members);
        mapper.UsesCustomIdSelection = HasCustomIdSelection(GetType());

        foreach (var memberInfo in members)
        {
            // checks [BsonIgnore]
            if (CustomAttributeExtensions.IsDefined(memberInfo, ignoreAttr, true)) continue;

            var name = this.ResolveFieldName(memberInfo.Name);

            // check if property has [BsonField]
            var field = (BsonFieldAttribute)CustomAttributeExtensions.GetCustomAttributes(memberInfo, fieldAttr, true)
                .FirstOrDefault();

            // check if property has [BsonField] with a custom field name
            if (field != null && field.Name != null)
            {
                name = field.Name;
            }

            // checks if memberInfo is id field
            if (memberInfo == id)
            {
                name = "_id";
            }

            // create getter/setter function
            var getter = Reflection.CreateGenericGetter(mapper.ForType, memberInfo);
            var setter = Reflection.CreateGenericSetter(mapper.ForType, memberInfo);

            // check if property has [BsonId] to get with was setted AutoId = true
            var autoId = (BsonIdAttribute)CustomAttributeExtensions.GetCustomAttributes(memberInfo, idAttr, true)
                .FirstOrDefault();

            var dataType = memberInfo is PropertyInfo
                ? (memberInfo as PropertyInfo).PropertyType
                : (memberInfo as FieldInfo).FieldType;

            var isEnumerable = Reflection.IsEnumerable(dataType);

            var member = new MemberMapper
            {
                AutoId = autoId == null ? true : autoId.AutoId,
                FieldName = name,
                HasExplicitFieldName = autoId != null || field?.Name != null,
                ReflectedMember = memberInfo,
                MemberName = memberInfo.Name,
                DataType = dataType,
                IsEnumerable = isEnumerable,
                UnderlyingType = isEnumerable ? Reflection.GetListItemType(dataType) : dataType,
                Getter = getter,
                Setter = setter,
                DefaultSetter = setter
            };

            // check if property has [BsonRef]
            var dbRef = (BsonRefAttribute)CustomAttributeExtensions.GetCustomAttributes(memberInfo, dbrefAttr, false)
                .FirstOrDefault();

            if (dbRef != null && memberInfo is PropertyInfo)
            {
                BsonMapper.RegisterDbRef(this, member, _typeNameBinder,
                    dbRef.Collection ?? this.ResolveCollectionName((memberInfo as PropertyInfo).PropertyType));
            }

            // support callback to user modify member mapper
            this.ResolveMember?.Invoke(mapper.ForType, memberInfo, member);

            // test if has name and there is no duplicate field
            // when member is not ignore
            if (member.FieldName != null &&
                mapper.Members.Any(x => x.FieldName.Equals(name, StringComparison.OrdinalIgnoreCase)) == false &&
                !member.IsIgnore)
            {
                mapper.Members.Add(member);
            }
        }
    }

    /// <summary>
    /// Gets MemberInfo that refers to Id from a document object.
    /// </summary>
    protected virtual MemberInfo GetIdMember(IEnumerable<MemberInfo> members)
    {
        return Reflection.SelectMember(members,
            x => CustomAttributeExtensions.IsDefined(x, typeof(BsonIdAttribute), true),
            x => x.Name.Equals("Id", StringComparison.OrdinalIgnoreCase),
            x => x.Name.Equals(x.ReflectedType.Name + "Id", StringComparison.OrdinalIgnoreCase),
            x => x.Name.Equals(x.DeclaringType.Name + "Id", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Returns all member that will be have mapper between POCO class to document
    /// </summary>
    protected virtual IEnumerable<MemberInfo> GetTypeMembers(Type type)
    {
        var members = new List<MemberInfo>();

        var flags = this.IncludeNonPublic
            ? (BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
            : (BindingFlags.Public | BindingFlags.Instance);

        // Reflection does not include inherited interface properties. Visit the
        // most-derived contracts first so a redeclaration owns its member name.
        var contracts = type.IsInterface
            ? new[] { type }.Concat(type.GetInterfaces().OrderByDescending(x => x.GetInterfaces().Length)
                .ThenBy(x => x.FullName, StringComparer.Ordinal))
            : new[] { type };
        var properties = contracts.SelectMany(contract => contract.GetProperties(flags))
            .Where(x => x.CanRead && x.GetIndexParameters().Length == 0);
        if (type.IsInterface)
        {
            var declared = properties.Distinct().ToArray();
            properties = declared.Where(property => !declared.Any(other => other.Name == property.Name &&
                other.DeclaringType != property.DeclaringType &&
                other.DeclaringType.GetInterfaces().Contains(property.DeclaringType)));
        }
        members.AddRange(properties.Select(x => x as MemberInfo));

        var shouldIncludeFields = members.Count == 0
                                  && type.GetTypeInfo().IsValueType;
                                  
        if (shouldIncludeFields || this.IncludeFields)
        {
            members.AddRange(type.GetFields(flags).Where(x => !x.Name.EndsWith("k__BackingField") && x.IsStatic == false)
                .Select(x => x as MemberInfo));
        }

        return members;
    }

    /// <summary>
    /// Get best construtor to use to initialize this entity.
    /// - Look if contains [BsonCtor] attribute
    /// - Look for parameterless ctor
    /// - Look for first contructor with parameter and use BsonDocument to send RawValue
    /// </summary>
    protected virtual CreateObject GetTypeCtor(EntityMapper mapper)
    {
        Type type = mapper.ForType;
        List<CreateObject> Mappings = new List<CreateObject>();
        bool returnZeroParamNull = false;
        bool missingParameterNames = false;
        foreach (ConstructorInfo ctor in type.GetConstructors())
        {
            ParameterInfo[] pars = ctor.GetParameters();
            // For 0 parameters, we can let the Reflection.CreateInstance handle it, unless they've specified a [BsonCtor] attribute on a different constructor.
            if (pars.Length == 0)
            {
                returnZeroParamNull = true;
                continue;
            }

            var paramMap = new MemberMapper[pars.Length];
            if (pars.Any(parameter => string.IsNullOrEmpty(parameter.Name)))
            {
                if (ctor.GetCustomAttribute<BsonCtorAttribute>() != null)
                    throw MissingConstructorParameterNames(type);
                missingParameterNames = true;
                continue;
            }
            int i;
            for (i = 0; i < pars.Length; i++)
            {
                ParameterInfo par = pars[i];
                var mi = mapper.Members.FirstOrDefault(member => member.DataType == par.ParameterType &&
                    member.MemberName.Equals(par.Name, StringComparison.OrdinalIgnoreCase)) ??
                    mapper.Members.FirstOrDefault(member => member.DataType == par.ParameterType &&
                        member.FieldName.Equals(par.Name, StringComparison.OrdinalIgnoreCase));

                if (mi == null)
                {
                    break;
                }

                paramMap[i] = mi;
            }

            if (i < pars.Length)
            {
                continue;
            }

            CreateObject toAdd = new MappedConstructor(this, ctor, paramMap).Create;
            if (ctor.GetCustomAttribute<BsonCtorAttribute>() != null)
            {
                return toAdd;
            }
            else
            {
                Mappings.Add(toAdd);
            }
        }

        if (returnZeroParamNull)
        {
            return null;
        }

        if (Mappings.Count == 0 && missingParameterNames)
            throw MissingConstructorParameterNames(type);
        return Mappings.FirstOrDefault();
    }
}
