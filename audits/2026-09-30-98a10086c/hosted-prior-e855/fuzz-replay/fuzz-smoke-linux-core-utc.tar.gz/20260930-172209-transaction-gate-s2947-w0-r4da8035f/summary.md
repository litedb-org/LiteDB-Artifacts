# LiteDB fuzz result: transaction-gate

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `1.870s`
- Git SHA: `b86a770a120cf551a976bf915a1fbbc4efd004ac`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `AADF824394441D98F67A77EF95CA36DC8D4CD66B2239DAC6FD4C4994A284CFC6`
- Trace SHA-256: `2A50708D4321A37D14708145F90B71ABFCBA1A9159A5A484B7273577B3CACF1D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-172209-transaction-gate-s2947-w0-r4da8035f/replay.json`

## Metrics

- novelStates: `22`
- foreignLeasesReleased: `314`
