# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `4.743s`
- Git SHA: `b86a770a120cf551a976bf915a1fbbc4efd004ac`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-172211-conflict-s2947-w0-r7eda35ea/replay.json`

## Metrics

- semanticIndexKeys: `871`
- semanticDocuments: `481`
- semanticIndexes: `121`
- integrityPages: `51`
- integrityPhysicalPages: `51`
- novelStates: `1`
- forcedConflictingOperations: `180`
