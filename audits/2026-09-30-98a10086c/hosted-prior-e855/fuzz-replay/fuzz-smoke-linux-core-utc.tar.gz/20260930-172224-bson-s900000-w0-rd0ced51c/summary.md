# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `900000`
- Steps: `5` / requested `5`
- Duration: `0.278s`
- Git SHA: `b86a770a120cf551a976bf915a1fbbc4efd004ac`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `C3C1D5B75068BFA8E069CDA6C51E9060AB27358897699A27981257173C07FC1D`
- Trace SHA-256: `183DCCAF3ED735E3041B040AA9E0DC1405E562C076880724FB02CA9438F1BA0D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-172224-bson-s900000-w0-rd0ced51c/replay.json`

## Metrics

- malformedInputsRejected: `12`
