# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `1.226s`
- Git SHA: `b86a770a120cf551a976bf915a1fbbc4efd004ac`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `ED68CAAF54989DA513B79A98FFA1EC9046190553890BB1684AA4B2A600F44448`
- Trace SHA-256: `9B889D9E50A308B2A831F1174D920F85037EDF85559AD09A37F9ED671AFE18A4`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-172543-index-s202947-w0-rde5dd55a\replay.json`

## Metrics

- semanticIndexKeys: `49`
- semanticDocuments: `12`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `12`
- documents: `5`
- keyMovingUpdates: `2`
- integrityChecks: `2`
