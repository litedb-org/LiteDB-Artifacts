# LiteDB fuzz result: oracle-selftest

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `0,171s`
- Git SHA: `b86a770a120cf551a976bf915a1fbbc4efd004ac`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-172204-oracle-selftest-s102947-w0-r453aae2c/replay.json`

## Metrics

- novelStates: `30`
- controlledMutationsKilled: `240`
