# LiteDB fuzz result: recovery

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.948s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-180050-recovery-s2947-w0-r7cba4a83/replay.json`

## Metrics

- semanticIndexKeys: `570`
- semanticDocuments: `285`
- semanticIndexes: `60`
- integrityPages: `14`
- integrityPhysicalPages: `14`
- novelStates: `6`
- recoveryInterruptions: `25`
