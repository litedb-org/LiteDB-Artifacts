# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.274s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `3824388C4D3AD4CB520D36EAA95678184F428BFE1F1E10399A630E34F0E76357`
- Trace SHA-256: `82EF46C85F0600CB43C617AD85B1F6DC7C6C86C505104C1FF6E7ED8799435D6D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-180036-bson-s2947-w0-r6d2ef965/replay.json`

## Metrics

- malformedInputsRejected: `65`
