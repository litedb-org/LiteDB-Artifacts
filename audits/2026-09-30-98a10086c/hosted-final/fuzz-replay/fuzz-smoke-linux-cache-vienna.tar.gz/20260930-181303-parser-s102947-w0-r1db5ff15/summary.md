# LiteDB fuzz result: parser

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `2,096s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `CC58FB41098E6903D85AD6F5963B8B0C7748889B67F56257B8065CD9FFC3B423`
- Trace SHA-256: `9E36D02CECA4D3EFD0589F2A7DEDD165DF6E548D93369FF27F97822DF2A7E668`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-181303-parser-s102947-w0-r1db5ff15/replay.json`

## Metrics

- sqlDifferentialChecks: `30`
- distinctStatements: `27`
