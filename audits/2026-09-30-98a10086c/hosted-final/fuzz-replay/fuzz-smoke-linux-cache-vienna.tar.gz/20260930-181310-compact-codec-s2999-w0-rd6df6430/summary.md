# LiteDB fuzz result: compact-codec

- Status: **PASS**
- Seed: `2999`
- Steps: `64` / requested `64`
- Duration: `0,332s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `222B67FA01E5D9BF86248EAEC4DA5A0C3F27B506C4E050BA913184A08DC80E6A`
- Trace SHA-256: `689EE33F26471CD31DDBFB4ADA2C496B1850645392F0B83CE6AA388F8E9281C3`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-181310-compact-codec-s2999-w0-rd6df6430/replay.json`

## Metrics

- vectorBoundaryCases: `6`
- novelStates: `64`
- decoded: `64`
- projected: `64`
- mutations: `64`
- mutationRejections: `63`
- schemas: `6`
