# LiteDB fuzz result: checksum-crash

- Status: **PASS**
- Seed: `4058733`
- Steps: `111` / requested `111`
- Duration: `18.763s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `76D03C6250BC2CAA506D5545F400D85F01FF55AA788998A35B12C21DD8C84921`
- Trace SHA-256: `A3F383F23429D97C7E24B9D1D59AB6941DCB3B4D48196F3C4EB098AA2826B1B7`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-181350-checksum-crash-s4058733-w0-r408fd7b9/replay.json`

## Metrics

- novelStates: `53`
- crashEvents: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- crashCases: `111`
