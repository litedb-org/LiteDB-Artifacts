# LiteDB fuzz result: mvcc-retirement

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `3.646s`
- Git SHA: `dc5f2ff57e9f2d04c7c9c49d792cc82f5e62bd7d`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `16468DE330D21332B8607BF57B7FC4BDDF9B2D1221D15ED64A2AB205FF742713`
- Trace SHA-256: `BAF930168673A0AF46344858D15886A5AD0DD55E9DC56DBAA6F8521BF42B5369`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-180013-mvcc-retirement-determinism-s2954-w0-r9f779d96\replay.json`

## Metrics

- novelStates: `26`
