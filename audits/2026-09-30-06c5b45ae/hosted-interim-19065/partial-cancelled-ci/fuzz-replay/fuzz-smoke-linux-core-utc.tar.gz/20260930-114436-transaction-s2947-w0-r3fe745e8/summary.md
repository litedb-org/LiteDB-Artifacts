# LiteDB fuzz result: transaction

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.913s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `8311FE715449089AE52BE60A78D957FDA4743588A30EEC7523A60E34D8FB902A`
- Trace SHA-256: `E9738E01A725029D194DDEA9F1D7C971EF6FC6F299F9DD5853BDDBBB500D716D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114436-transaction-s2947-w0-r3fe745e8/replay.json`

## Metrics

- semanticIndexKeys: `4`
- semanticDocuments: `2`
- semanticIndexes: `2`
- integrityPages: `9`
- integrityPhysicalPages: `9`
- documents: `2`
- collections: `2`
- integrityChecks: `1`
- commits: `1`
- rollbacks: `0`
- reopens: `0`
- schemaChanges: `7`
