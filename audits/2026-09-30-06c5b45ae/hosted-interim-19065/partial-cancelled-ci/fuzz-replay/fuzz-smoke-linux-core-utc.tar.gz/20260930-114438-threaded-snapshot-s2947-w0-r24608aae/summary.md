# LiteDB fuzz result: threaded-snapshot

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `4.810s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114438-threaded-snapshot-s2947-w0-r24608aae/replay.json`

## Metrics

- novelStates: `19`
- semanticIndexKeys: `120`
- semanticDocuments: `60`
- semanticIndexes: `2`
- integrityPages: `124`
- integrityPhysicalPages: `124`
- forcedSnapshotRounds: `30`
- commitsWhileOldReadersLive: `60`
