# LiteDB fuzz result: snapshot

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `52.870s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `D85652F6907CB309A043F48120B3D14B0FEF3C3EE0642294560F1E22D80EABC0`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114437-snapshot-s2947-w0-rf02df9c1/replay.json`

## Metrics

- novelStates: `8`
- semanticIndexKeys: `54`
- semanticDocuments: `27`
- semanticIndexes: `2`
- integrityPages: `43`
- integrityPhysicalPages: `43`
- simultaneousSnapshotGenerations: `3`
- snapshotValidations: `90`
- checkpointsBetweenReaderGenerations: `210`
