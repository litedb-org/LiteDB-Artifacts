# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `42947`
- Steps: `31` / requested `31`
- Duration: `0.264s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E35984BDC02CB4F27C7CA8867FE3E7D08DBD3EB39DB9D5DE76FC3C5A2DAFF978`
- Trace SHA-256: `8662EF9952BF6694C6EF56630F7BD1B4A330BB5AD2B5766E579304EC9B8E1402`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114457-bson-s42947-w0-r95287ef8/replay.json`

## Metrics

- malformedInputsRejected: `69`
