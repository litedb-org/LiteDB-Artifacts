# LiteDB fuzz result: page

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `0.146s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `3B3A8328EFEDC4BB38C1108CE4ED6D7F441A576BC7007041F89D16EC6BCAE273`
- Trace SHA-256: `1D060A1EC9A748534A7E6EEA4EE4D28C58D95EE85F83F29F9B678C4F743C5618`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114436-page-s2947-w0-r7896b13a/replay.json`

## Metrics

- operations: `{ inserts = 9, updates = 3, deletes = 7, defrags = 3 }`
- survivingSlots: `2`
- usedBytes: `871`
- freeBytes: `7273`
