# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `51.388s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `7A5EC8FA87EB5FD1427AB8D931E5D89ED54133AD76A64F4A0AFB63C14257E243`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114436-shared-s2947-w0-r777f7167/replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `1000`
- semanticDocuments: `1000`
- semanticIndexes: `30`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `30`
- processes: `90`
- acknowledgedRows: `970`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `30`
