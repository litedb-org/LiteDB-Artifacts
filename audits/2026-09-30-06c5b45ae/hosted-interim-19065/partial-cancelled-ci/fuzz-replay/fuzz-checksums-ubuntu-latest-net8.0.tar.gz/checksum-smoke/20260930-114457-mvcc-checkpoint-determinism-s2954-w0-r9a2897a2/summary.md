# LiteDB fuzz result: mvcc-checkpoint

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `8.092s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `C44A5179C25405EEB625AD862922B6FD457FD557DB6E0A19D6244E0CD5B47BD2`
- Trace SHA-256: `01B425F8764B1E02AAC3723B7309EEC5EB8754AB69CF3D83A418C10C28F1CFC0`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-114457-mvcc-checkpoint-determinism-s2954-w0-r9a2897a2/replay.json`

## Metrics

- novelStates: `23`
