# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `2905001`
- Steps: `200` / requested `200`
- Duration: `1.590s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `3EC527C8C7EA771CE24858A19379275304454A143EB4D3A3F4A6E3314EEDFF3B`
- Trace SHA-256: `4CF71F5085BE740FD514CE8DC09D764CBFFEE2082C097F27649442111229F867`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114442-index-s2905001-w0-ra38b60ff/replay.json`

## Metrics

- semanticIndexKeys: `1029`
- semanticDocuments: `222`
- semanticIndexes: `32`
- integrityPages: `10`
- integrityPhysicalPages: `10`
- uniqueConflictScenarios: `6`
- novelStates: `46`
- documents: `46`
- keyMovingUpdates: `38`
- integrityChecks: `7`
