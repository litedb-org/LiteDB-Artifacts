# LiteDB fuzz result: index

- Status: **PASS**
- Seed: `42947`
- Steps: `40` / requested `40`
- Duration: `0.740s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `0077D6483D2FC18E21EA428AA9BD8DE0F2117EFF7359EBE9E43150F37E0ECA80`
- Trace SHA-256: `C3B7D416DCB40B122CE4CBA80EE06672B3379783C75F841D3303BEB0847884FD`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-114441-index-determinism-s42947-w0-r2e7142fc/replay.json`

## Metrics

- semanticIndexKeys: `77`
- semanticDocuments: `18`
- semanticIndexes: `12`
- integrityPages: `8`
- integrityPhysicalPages: `8`
- uniqueConflictScenarios: `6`
- novelStates: `17`
- documents: `8`
- keyMovingUpdates: `10`
- integrityChecks: `2`
