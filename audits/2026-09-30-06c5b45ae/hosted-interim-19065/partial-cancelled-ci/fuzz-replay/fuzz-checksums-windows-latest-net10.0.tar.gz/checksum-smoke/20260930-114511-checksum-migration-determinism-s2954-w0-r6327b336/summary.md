# LiteDB fuzz result: checksum-migration

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `5.288s`
- Git SHA: `2a15beace59345d1daaa8cdbc887cfe67b5d89ff`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `5C56EEA051A5BA9C6E11EEB5315447387A3613A47D6414F6312B9AB876B9F795`
- Trace SHA-256: `2F196A7FA552F862D6C054B721B4CBE37521E71CAC500D2898F6236CD9A9421D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-114511-checksum-migration-determinism-s2954-w0-r6327b336\replay.json`

## Metrics

- novelStates: `7`
- migrationCases: `28`
- transactionBatches: `224`
