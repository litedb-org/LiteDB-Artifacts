# LiteDB fuzz result: linq-cache

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `1,030s`
- Git SHA: `765c90eb37816dd4b9112d8c3f58689efc9b81f5`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `866F5CF66C38F265FE6E79E24F95FAB8BC1DD8E1A35A853F2598C0BDB2593484`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-095838-linq-cache-s102947-w0-radf2699b/replay.json`

## Metrics

- supportedTranslations: `21`
- cacheEntries: `16`
- concurrencyCases: `32`
