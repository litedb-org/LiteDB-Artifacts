# LiteDB fuzz result: compact-crash

- Status: **PASS**
- Seed: `2937`
- Steps: `64` / requested `64`
- Duration: `3.332s`
- Git SHA: `fc020eae6b6d07f6e43441edf3a39eb81a12421c`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 10.0.12`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `7017F28902BB833CFA10F818398BC6E7ABA13DB433AAE52F2EA1A894BA3A1542`
- Trace SHA-256: `A1F6C22B07E7407B79757E53E19C21AC44D11AD71F2CD9E338347DAC624FDC1D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__\artifacts\checksum-smoke\20260930-090524-compact-crash-s2937-w0-r66144268\replay.json`

## Metrics

- novelStates: `32`
