# LiteDB fuzz result: shared

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `52.054s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `BF66710906B460EDD094265DFCC13C3615F7EC65F7C7BC4C63488A446A45ABB7`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090507-shared-s2947-w0-r1acd0754/replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `1000`
- semanticDocuments: `1000`
- semanticIndexes: `30`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- rounds: `30`
- processes: `90`
- acknowledgedRows: `970`
- observedCrashPositions: `26`
- observedInternalCrashPoints: `14`
- integrityChecks: `30`
