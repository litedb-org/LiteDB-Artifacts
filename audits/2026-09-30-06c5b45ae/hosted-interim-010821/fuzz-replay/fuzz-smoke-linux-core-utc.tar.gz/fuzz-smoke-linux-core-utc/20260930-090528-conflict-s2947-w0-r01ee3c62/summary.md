# LiteDB fuzz result: conflict

- Status: **PASS**
- Seed: `2947`
- Steps: `3` / requested `3`
- Duration: `1.374s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090528-conflict-s2947-w0-r01ee3c62/replay.json`

## Metrics

- semanticIndexKeys: `88`
- semanticDocuments: `49`
- semanticIndexes: `13`
- integrityPages: `51`
- integrityPhysicalPages: `51`
- novelStates: `1`
- forcedConflictingOperations: `18`
