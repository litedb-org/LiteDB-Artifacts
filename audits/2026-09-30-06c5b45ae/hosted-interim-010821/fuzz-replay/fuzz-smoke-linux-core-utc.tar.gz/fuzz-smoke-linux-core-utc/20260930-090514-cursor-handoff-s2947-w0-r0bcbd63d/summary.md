# LiteDB fuzz result: cursor-handoff

- Status: **PASS**
- Seed: `2947`
- Steps: `30` / requested `30`
- Duration: `8.680s`
- Git SHA: `dafa93b84a2ef4b009c7531c6aa11d7d4728f17e`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `780C0134A9D18E22608E9C91F124321634486809F73BB7D6EB7633F92202F19A`
- Trace SHA-256: `CD67CEFE31A4A3E6BE687C10BB1397CA4C746B3A6F151E1A65A8F411A039A032`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-090514-cursor-handoff-s2947-w0-r0bcbd63d/replay.json`

## Metrics

- novelStates: `18`
- cursorsHandedOff: `260`
- semanticIndexKeys: `12`
- semanticDocuments: `12`
- semanticIndexes: `1`
- integrityPages: `4`
- integrityPhysicalPages: `4`
