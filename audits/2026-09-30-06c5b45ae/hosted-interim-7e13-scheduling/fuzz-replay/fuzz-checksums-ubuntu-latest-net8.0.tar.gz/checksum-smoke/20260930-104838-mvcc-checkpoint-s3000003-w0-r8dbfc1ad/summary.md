# LiteDB fuzz result: mvcc-checkpoint

- Status: **PASS**
- Seed: `3000003`
- Steps: `64` / requested `64`
- Duration: `9.900s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `5EE622EAA659938AC8F8BDA43E1E38A31EFCEF2F44B5CCF27C428C3A22A29C38`
- Trace SHA-256: `EA8D2ADB6361BAF9619B26E8E35E29035A77CD74075A63C176D57C9A19419D1C`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-104838-mvcc-checkpoint-s3000003-w0-r8dbfc1ad/replay.json`

## Metrics

- novelStates: `55`
