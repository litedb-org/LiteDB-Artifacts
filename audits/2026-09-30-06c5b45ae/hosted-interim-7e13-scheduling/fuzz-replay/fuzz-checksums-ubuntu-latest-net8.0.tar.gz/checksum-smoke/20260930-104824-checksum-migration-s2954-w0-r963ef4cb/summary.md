# LiteDB fuzz result: checksum-migration

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `5.291s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `5C56EEA051A5BA9C6E11EEB5315447387A3613A47D6414F6312B9AB876B9F795`
- Trace SHA-256: `2F196A7FA552F862D6C054B721B4CBE37521E71CAC500D2898F6236CD9A9421D`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-104824-checksum-migration-s2954-w0-r963ef4cb/replay.json`

## Metrics

- novelStates: `7`
- migrationCases: `28`
- transactionBatches: `224`
