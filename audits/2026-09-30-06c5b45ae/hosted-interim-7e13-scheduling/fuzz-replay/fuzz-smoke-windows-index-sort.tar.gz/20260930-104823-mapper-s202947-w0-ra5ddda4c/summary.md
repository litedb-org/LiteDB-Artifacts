# LiteDB fuzz result: mapper

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `0.973s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `BBD5B08E66CE2799BA53DB47EC9278ADA334676ECCBCC8A1BFCA6B4C4845792D`
- Trace SHA-256: `C41970A5AE631792BE3CCC4E9F3032DAE799E801C1A9207A04F83804B94E1550`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-104823-mapper-s202947-w0-ra5ddda4c\replay.json`

## Metrics

- cycleFailures: `3`
- enumAsInteger: `False`
