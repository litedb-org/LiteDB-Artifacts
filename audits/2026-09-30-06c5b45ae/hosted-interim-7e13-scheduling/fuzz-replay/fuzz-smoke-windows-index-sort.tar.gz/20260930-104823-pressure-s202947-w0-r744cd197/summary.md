# LiteDB fuzz result: pressure

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `4.697s`
- Git SHA: `67fd0a2bb892d86cfd7c06b2f3924a4ca31d81a6`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-104823-pressure-s202947-w0-r744cd197\replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `6060`
- semanticDocuments: `3030`
- semanticIndexes: `2`
- integrityPages: `944`
- integrityPhysicalPages: `944`
- observedCacheEvictions: `29954`
