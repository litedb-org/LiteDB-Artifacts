# LiteDB fuzz result: mapper

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `0.878s`
- Git SHA: `3f614aa69b15771ed1a63b8b8796172fae8b6648`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `BBD5B08E66CE2799BA53DB47EC9278ADA334676ECCBCC8A1BFCA6B4C4845792D`
- Trace SHA-256: `C41970A5AE631792BE3CCC4E9F3032DAE799E801C1A9207A04F83804B94E1550`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-105724-mapper-s202947-w0-r785d8fb2\replay.json`

## Metrics

- cycleFailures: `3`
- enumAsInteger: `False`
