# LiteDB fuzz result: compact-crash

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `3.390s`
- Git SHA: `3f614aa69b15771ed1a63b8b8796172fae8b6648`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `A285E67931C1ECF1F97787B8BACFDA511AAD9A56A84062FB46A2171E1455E8F0`
- Trace SHA-256: `FFC84602BBDA9E8A9AB6B721E110DE44D803C084997C70555C715B71E74FBDA8`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-105552-compact-crash-determinism-s2954-w0-r966cab6b/replay.json`

## Metrics

- novelStates: `22`
