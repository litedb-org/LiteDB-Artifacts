# LiteDB fuzz result: pressure

- Status: **PASS**
- Seed: `202947`
- Steps: `30` / requested `30`
- Duration: `4.536s`
- Git SHA: `446ab85bb38b3a0eee28e34ee609f56d12029354`
- Working tree dirty: `True`
- Environment: `Microsoft Windows 10.0.26100`, `.NET 8.0.31`, `X64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__\artifacts\fuzz\20260930-151940-pressure-s202947-w0-r4d34518d\replay.json`

## Metrics

- novelStates: `30`
- semanticIndexKeys: `6060`
- semanticDocuments: `3030`
- semanticIndexes: `2`
- integrityPages: `944`
- integrityPhysicalPages: `944`
- observedCacheEvictions: `29954`
