# LiteDB fuzz result: checksum-crash

- Status: **PASS**
- Seed: `2954`
- Steps: `28` / requested `28`
- Duration: `7.027s`
- Git SHA: `446ab85bb38b3a0eee28e34ee609f56d12029354`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `A354CB58CB8F3B384DC35DA7BDD732553011839438EC19E83F1C1111601EFB66`
- Trace SHA-256: `175E63BEAF2D41490DE21E0C8B9565448C74FBC39A25D527BC2B50DAD0D2BCCB`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/checksum-smoke/20260930-151924-checksum-crash-determinism-s2954-w0-r64c20482/replay.json`

## Metrics

- novelStates: `23`
- crashEvents: `System.Collections.Generic.Dictionary`2[System.String,System.Int32]`
- crashCases: `28`
