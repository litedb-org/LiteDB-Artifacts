# LiteDB fuzz result: parser

- Status: **PASS**
- Seed: `102947`
- Steps: `30` / requested `30`
- Duration: `2,089s`
- Git SHA: `446ab85bb38b3a0eee28e34ee609f56d12029354`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 10.0.12`, `X64`
- Culture/timezone: `tr-TR` / `Europe/Vienna`
- Failure ID: `n/a`
- Input SHA-256: `CC58FB41098E6903D85AD6F5963B8B0C7748889B67F56257B8065CD9FFC3B423`
- Trace SHA-256: `9E36D02CECA4D3EFD0589F2A7DEDD165DF6E548D93369FF27F97822DF2A7E668`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net10.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-151925-parser-s102947-w0-r46f7bb3a/replay.json`

## Metrics

- sqlDifferentialChecks: `30`
- distinctStatements: `27`
