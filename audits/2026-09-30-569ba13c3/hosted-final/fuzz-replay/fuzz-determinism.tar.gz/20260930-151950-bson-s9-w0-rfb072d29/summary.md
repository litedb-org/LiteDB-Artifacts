# LiteDB fuzz result: bson

- Status: **PASS**
- Seed: `9`
- Steps: `31` / requested `31`
- Duration: `0.209s`
- Git SHA: `446ab85bb38b3a0eee28e34ee609f56d12029354`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `X64`
- Culture/timezone: `` / `Etc/UTC`
- Failure ID: `n/a`
- Input SHA-256: `8E6C63637AB8E13A40DD7B1A7430CB34BA43512022610320AC2D97F3FCC29F42`
- Trace SHA-256: `893B88ADDE6CA897CFF5F237CACA9278EC462527F6CEB67F890C202651E0EEFA`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-151950-bson-s9-w0-rfb072d29/replay.json`

## Metrics

- malformedInputsRejected: `69`
