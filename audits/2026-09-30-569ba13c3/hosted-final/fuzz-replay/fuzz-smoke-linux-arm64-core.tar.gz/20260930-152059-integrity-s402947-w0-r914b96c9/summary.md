# LiteDB fuzz result: integrity

- Status: **PASS**
- Seed: `402947`
- Steps: `1` / requested `30`
- Duration: `0.884s`
- Git SHA: `446ab85bb38b3a0eee28e34ee609f56d12029354`
- Working tree dirty: `True`
- Environment: `Ubuntu 24.04.5 LTS`, `.NET 8.0.31`, `Arm64`
- Culture/timezone: `en-US` / `UTC`
- Failure ID: `n/a`
- Input SHA-256: `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- Trace SHA-256: `FAC4F4EE58C8028E2F411085C906E8706F13C8B5118D0B52AFE52FFDD76F0F79`
- Replay: `dotnet run --project LiteDB.Fuzz -c Release -f net8.0 -- --replay __CI_WORKSPACE__/artifacts/fuzz/20260930-152059-integrity-s402947-w0-r914b96c9/replay.json`

## Metrics

- semanticIndexKeys: `81`
- semanticDocuments: `35`
- semanticIndexes: `9`
- integrityPages: `4`
- integrityPhysicalPages: `4`
- mutantsDetected: `10`
- preallocatedLayouts: `1`
- encryptedLayouts: `1`
- legacyFiles: `1`
