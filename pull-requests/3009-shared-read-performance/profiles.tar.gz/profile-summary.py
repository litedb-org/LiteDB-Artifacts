import collections,json,pathlib
for name in ['point','cached-point','scan','mixed']:
 p=json.load(open(f'artifacts_temp/pr3003/{name}.speedscope.json'))
 frames=[f['name'] for f in p['shared']['frames']]
 c=collections.Counter(); stack=[];last=0
 for e in p['profiles'][0]['events']:
  dt=e['at']-last
  for n in set(stack): c[n]+=dt
  if e['type']=='O': stack.append(e['frame'])
  else: stack.pop()
  last=e['at']
 total=max(c.values()); print(name,'sampled ms',round(total,2))
 for term in ['CollationFingerprint.Compute','SharedEngine.OpenDatabase','TryBufferResult','LiteEngine.Open','RestoreIndex','Crc32C.Update','RebuildRecovery.EnsureAvailable','SharedReaderRegistry','SharedMutexOwner.Enter','TryCloseCheckpoint','NativeFileSync']:
  for n,v in c.items():
   if term in frames[n]: print(f'{v/total*100:.2f}%',frames[n])
 print('top 25')
 for n,v in c.most_common(25): print(f'{v/total*100:.2f}%',frames[n])
