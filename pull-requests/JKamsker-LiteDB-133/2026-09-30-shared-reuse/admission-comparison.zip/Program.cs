using LiteDB;
Console.WriteLine(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(LiteDatabase).Assembly.Location))));
var file = Path.Combine(Path.GetTempPath(), "litedb-handle-admission-" + Guid.NewGuid() + ".db");
using var shared = new LiteDatabase(new ConnectionString { Filename = file, Connection = ConnectionType.Shared });
using (var tx = shared.BeginTransaction()) { tx.GetCollection("rows").Insert(new BsonDocument { ["_id"] = 1, ["value"] = 42 }); tx.Commit(); }
try { using var direct = new LiteDatabase(file); Console.WriteLine("Direct allowed: " + direct.GetCollection("rows").Count()); }
catch (Exception e) { Console.WriteLine("Direct refused: " + e.GetType().Name + " " + e.Message); Environment.ExitCode = 1; }
